<HTML>
<HEAD>
   <META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">
   <META NAME="GENERATOR" CONTENT="Mozilla/4.01 [en] (Win95; I) [Netscape]">
   <META NAME="Author" CONTENT="S. Henahan">
   <META NAME="Classification" CONTENT="keyword">
   <META NAME="Description" CONTENT="Science news article, Alzheimer's">
   <META NAME="KeyWords" CONTENT="Alzheimer's disease, gene, Alzheimer's disease, gene, Alzheimer's disease, gene, Alzheimer's disease, gene, Alzheimer's disease, gene, 

Alzheimer's disease, gene, Alzheimer's disease, gene, Alzheimer's disease, gene, Alzheimer's disease, gene, 

Alzheimer's disease, gene, Alzheimer's disease, gene, Alzheimer's disease, gene, Alzheimer's disease, gene, 

vAlzheimer's disease, gene, Alzheimer's disease, gene,">
   <TITLE>Alzheimer's Gene</title><noindex><!-- Start Quantcast tag -->
<script type="text/javascript" src="http://edge.quantserve.com/quant.js"></script>
<script type="text/javascript">
_qacct="p-00jJ5sUyRZnac";quantserve();</script>
<noscript>
<img src="http://pixel.quantserve.com/pixel/p-00jJ5sUyRZnac.gif" style="display: none" height="1" width="1" alt="Quantcast"/></noscript>
<!-- End Quantcast tag -->

<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
</script>
<script type="text/javascript">
_uacct = "UA-3096596-1";
urchinTracker();
</script>



<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
</script>
<script type="text/javascript">
_uacct = "UA-3096596-1";
urchinTracker();
</script>

</noindex>






<!--plugger-begin-aeWNhead-->

<!--php-begin-aeWNhead-->
<BODY BGCOLOR="#FFFFFF" MARGINWIDTH="0" MARGINHEIGHT="0" LINK="#0047DD" VLINK="#7A7777" ALINK="#FF0000">
<!--php-end-aeWNhead-->
<!--plugger-end-aeWNhead-->
<!--plugger-begin-aeWNSUhead-->


<!--php-begin-aeWNSUhead-->
<link rel="stylesheet" type="text/css" href="/styles.css">
<BR CLEAR=ALL>
<table width="780" border="0" align="center" cellpadding="0">
  <tr>
    <td colspan="2"><!-- #BeginLibraryItem "/Library/leaderboard.lbi" -->	<!-- START AE LEADERBOARD AD CODE -->
              <table cellpadding="0" align="center" cellspacing="0" width="782" border="0">
                <tr>
                  <td bgcolor="#999999"><img border="0" height="1" width="782" src="/graphics/spacer.gif" /></td>
                </tr>
                <tr>

                  <td bgcolor="#999999" align="center"><table cellpadding="0" cellspacing="0" width="780" border="0" bgcolor="#FFFFFF">

                      <tr>
                        <td align="center"><span style="font: 7pt verdana,arial,helvetica,sans-serif; color: #999999;">-Advertisement-</span></td>
                      </tr>
                      <tr>
                        <td><img border="0" height="3" width="1" src="/graphics/spacer.gif" /></td>
                      </tr>
                      <tr>

                        <td align="center"><!-- Ad Sense Media 468x60 and 728x90 Banner CODE for accessexcellence.org -->

                            <script type="text/javascript"><!--
google_ad_client = "pub-2969868737541392";
//728x90, Horizontal
google_ad_slot = "4677513902";
google_ad_width = 728;
google_ad_height = 90;
//--></script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
                            <!-- Ad Sense Media 468x60 and 728x90 Banner CODE for accessexcellence.org -->                        </td>
                      </tr>
                      <tr>
                        <td><img border="0" height="5" width="1" src="/graphics/spacer.gif" /></td>
                      </tr>
                  </table></td>

                </tr>

                <tr>
                  <td bgcolor="#999999"><img border="0" height="1" width="782" src="/graphics/spacer.gif" /></td>
                </tr>
                <tr>
                  <td><img border="0" height="10" width="1" src="/graphics/spacer.gif" /></td>
                </tr>
              </table>

              <!-- END AE LEADERBOARD AD CODE -->
<!-- #EndLibraryItem --></td>
  </tr>
  <tr>
    <td colspan="2">

<table width="789" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td><table cellpadding="0" cellspacing="0" width="789" class="forumhead" border="0" bgcolor="#009999">
      <tr>
        <td colspan="3"><table cellpadding="3" cellspacing="2" width="100%">
            <tr>
              <td>    
              <td class="white">&nbsp; <a class="white" href="/MTC/">About AE</a>
              <td>    
              <td class="white">&nbsp; <a class="white" href="http://www.nationalhealthmuseum.org/">About NHM</a></td>
              <td class="white">&nbsp; <a class="white" href="/MTC/contact.php">Contact Us</a></td>
              <td class="white">&nbsp; <a class="white" href="/MTC/copyright.php">Terms of Use</a></td>
              <td class="white">&nbsp; <a class="white" href="/MTC/copyright.php">Copyright Info</a></td>
              <td class="white">&nbsp; <a class="white" href="/MTC/privacy.php">Privacy Policy</a></td>
              <td class="white">&nbsp; <a class="white" href="/MTC/advertising.php">Advertising Policies</a></td>
              <td class="white">&nbsp; <a class="white" href="/sitemap.php">Site Map</a></td>
            </tr>
        </table>
		
		</td>
      </tr>
      <tr>
        <td align="left" width="*"><img src="/nav_images/WNX.jpg" 
				alt="AE logo" width="350" height="90" border="0" usemap="#navmap"
				class="logo">
          <map name="navmap" id="navmap">
            <area shape="rect" coords="46,18,285,46"
                                href="/" />
            <area shape="rect" coords="47,45,286,78" href="/WN/" />
          </map></td>
        <td align="right" width="*" ><a href="/WN/SU/"><img src="/WN/graphics/WNSU.gif" alt="Factoids" width="90" height="70" border="0" align="right" class="logo" /></a></td>
        <td width="5%">&nbsp; &nbsp; </td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td><table class="searchnav" width="789">
      <tr>
        <td colspan="2" align="left" valign="top" nowrap="nowrap">
	<div class="searchnav-item" style="width: 110px"><a href="/AE/mspot/" class="searchnav">Mystery Spot</a></div>
	<div class="searchnav-item" style="width: 155px"><a href="/AE/" class="searchnav">Activities Collections</a></div>
	<div class="searchnav-item" style="width: 155px"><a href="/HHQ" class="searchnav">Health Headquarters</a></div>
	<div class="searchnav-item" style="width: 100px"><a href="/RC/" class="searchnav">Resources</a></div>
	
	<style type="text/css">
@import url(http://www.google.com/cse/api/branding.css);
      </style>
            <div class="cse-branding-bottom" style="background-color:#FFFFFF;color:#000000">
              <div class="cse-branding-form">
                <form action="http://www.accessexcellence.org/googlesearch.php" id="cse-search-box">
                  <div>
                    <input type="hidden" name="cx" value="partner-pub-2969868737541392:mvpy0v-6nt8" />
                    <input type="hidden" name="cof" value="FORID:9" />
                    <input type="hidden" name="ie" value="ISO-8859-1" />
                    <input type="text" name="q" size="21" />
                    <input type="submit" name="sa" value="Search" />
                  </div>
                </form>
              </div>
              <div class="cse-branding-logo"> <img src="http://www.google.com/images/poweredby_transparent/poweredby_FFFFFF.gif" alt="Google" /> </div>
              <div class="cse-branding-text"> Custom Search of AE Site </div>
            </div>	        <style type="text/css">
@import url(http://www.google.com/cse/api/branding.css);
            </style></td>
        </tr>
      <tr>
        <td align="left" valign="top" nowrap="nowrap"><img src="/graphics/spacer.gif" alt="spacer" width="500" height="1" /></td>
        <td valign="top" align="left"><img src="/graphics/spacer.gif" alt="spacer" width="250" height="1" /></td>
      </tr>
    </table></td>
  </tr>
</table>	
	
	
    </td>
  </tr>
  <tr>
    <td width="620"><TABLE WIDTH="95%" ALIGN="CENTER">
      <TR>
        <TD VALIGN="TOP">
<!--php-end-aeWNSUhead-->

<!--plugger-end-aeWNSUhead-->


<H2>
New Alzheimer's Gene</H2>
By Sean Henahan, Access Excellence
<BR>
<HR SIZE=5 WIDTH="100%">
<BLOCKQUOTE><IMG SRC="images/alzbrain.jpg" HSPACE=10 VSPACE=10 HEIGHT=115 WIDTH=160 ALIGN=RIGHT><B>Pittsburgh,
PA (3/1/98)-</B> When researchers identified a genetic link to Alzheimer's
disease called APOE4 some three years ago, they knew they had an important
piece of the puzzle, but that many pieces remained to be discovered. Now,
the discovery of another susceptibility gene, found in people lacking the
APOE4 gene, adds another important piece.

<P>Researchers at the University of Pittsburgh report that a gene associated
with an enzyme called bleomycin hydrolase, is linked to a four-fold increased
risk of developing Alzheimer's disease. Heretofore, the only known function
of this enzyme was to detoxify a widely used cancer agent.

<P>The investigators studied the bleomycin gene in 357 Alzheimer's disease
patients and 320 controls. The bleomycin gene has two forms, or alleles,
called A and G. The investigators found that individuals with two copies
of the G bleomycin hydrolase allele (G/G) and without APOE4 are four times
more likely to have Alzheimer's. About six percent of the population would
be expected to fit this genetic profile (G/G, -APOE4).

<P>"Our research discovery is significant because it provides the first
susceptibility gene for sporadic, or non-familial, cases of Alzheimer's
disease in people who lack the only other known inherited risk factor,
APOE4, for sporadic disease," noted Susana Montoya, of the University of
Pittsburgh. "The bleomycin hydrolase risk factor also is greater than any
known environmental risk factor for Alzheimer's disease."

<P>More than 90 percent of AD cases are sporadic and of late onset. Previous
research has shown that individuals with the APOE4 form of the apolipoprotein
gene are at higher-than-expected risk of developing sporadic AD.&nbsp;&nbsp;&nbsp;
Apoplipoprotein E is thought to facilitate the deposition of amyloid plaques
within the brains of AD patients. Investigators have long sought risk factors
for members of the population who do not carry APOE4 (about 40 percent)
yet still develop sporadic AD.

<P>"This discovery gives us another significant opportunity to identify
people at risk for Alzheimer's disease. With this information, we can explore
potential mechanisms to intervene early to prevent disease development
or significantly delay its course," noted Steven DeKosky, M.D., professor
of psychiatry, neurology and human genetics, and director of the Alzheimer's
Disease Research Center (ADRC) at the University of Pittsburgh.

<P>"It's obvious that the bleomycin hydrolase protein did not evolve to
counter the effects of a single cancer agent," said Robert Ferrell, Ph.D.,
professor of human genetics and senior author on the paper. "Our research
finding suggests a plausible role for this enzyme in processing the amyloid
precursor proteins that give rise to the plaques characteristic of Alzheimer's
disease."

<P>"This research could be the first step toward designing a therapy in
which we would selectively alter bleomycin hydrolase activity in brain
cells to prevent the generation of disease plaques," added John S. Lazo,
Ph.D., professor and chairman of the department of pharmacology at the
University of Pittsburgh, and co-director of Molecular Therapuetics/Drug
Discovery at the University of Pittsburgh Cancer Institute. "Our group
and others have already explored this approach in treating cancer patients,"
added Dr. Lazo, who first sequenced the bleomycin hydrolase protein and
who has worked for 10 years on novel ways to selectively block the activity
of this enzyme to make bleomycin effective against tumors.

<P>Bleomycin hydrolase comes from a class of enzymes called cysteine proteases,
which have been thought to play a role in neurodegenerative disorders.
A group of Boston University-based investigators purified bleomycin hydrolase
from the brains of Alzheimer's disease patients and had evidence indicating
that this enzyme was involved in processing an amyloid precursor protein.
Abnormal breakdown of the amyloid precursor protein leads to production
of a small fragment of amyloid which piles up in the brains of AD patients.

<P>The genetic sequence for bleomycin hydrolase is well conserved among
organisms. The gene occurs in yeast, bacteria and humans, and the enzyme
is found in cells throughout the body.

<P>"These features strongly suggest that bleomycin hydrolase naturally
has one or more critical functions in the body," said M. Ilyas Kamboh,
Ph.D., professor of human genetics at UP. "The G/G bleomycin hydrolase
profile could be involved in Alzheimer's disease in a number of ways. For
instance, the G/G combination might reduce the&nbsp; life expectancy of
bleomycin hydrolase or somehow otherwise compromise its ability to break
down the amyloid precursor protein. Alternatively, this genetic change
may be associated with another undetected change in the bleomycin hydrolase
gene or with a mutation in a neighboring gene, either of which instead
could be responsible for problems resulting in Alzheimer's disease."

<P><I>The study appears in the March 1998&nbsp; issue of Nature Genetics.</I>
<BR>
<HR size=10>
<CENTER><TABLE COLS=1 WIDTH="300" >
<TR>
<TD>
<CENTER><B><FONT SIZE=+1>Related information on the Internet</FONT></B></CENTER>
</TD>
</TR>

<TR>
<TD>
<CENTER><B><A HREF="/WN/SUA02/alzheimers_gene.php">AE:
APOe4 Research</A></B></CENTER>
</TD>
</TR>

<TR>
<TD>
<CENTER><B><A HREF="/WN/SUA09/motrin397.php">AE:
Motrin for Alzheimer's?</A></B></CENTER>
</TD>
</TR>

<TR>
<TD>
<CENTER><B><A HREF="http://www.alz.org/">Alzheimer's Association</A></B></CENTER>
</TD>
</TR>

<TR>
<TD>
<CENTER>&nbsp;</CENTER>
</TD>
</TR>
</TABLE></CENTER>
<!--plugger-begin-aeWNfoot-->
  <H4> <font face="Times New Roman, Times, serif"><A HREF="http://www.accessexcellence.org/WN/"><IMG SRC="/nav_images/arrowWN.gif" BORDER=0 HEIGHT=13 WIDTH=13 ALIGN=TOP> 
    What's News Index</A></font></H4>
  <H4> <font face="Times New Roman, Times, serif"><A HREF="http://www.accessexcellence.org/captcha/email.cgi"><IMG SRC="/nav_images/arrowWN.gif" BORDER=0 HEIGHT=13 WIDTH=13> 
    Feedback</A></font></H4>
  <font face="Times New Roman, Times, serif">
<!--plugger-end-aeWNfoot--><!--plugger-begin-shell-footer-WN-->
 

<!--php-begin-shell-footer-WN-->

    <td width="160" valign="top"><!-- #BeginLibraryItem "/Library/skyscraper.lbi" -->


	<!-- Ad Sense -->
	<script type="text/javascript"><!--
google_ad_client = "pub-2969868737541392";
//160x600, created 1/20/08
google_ad_slot = "7418012947";
google_ad_width = 160;
google_ad_height = 600;
//--></script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
<!-- Ad Sense --><!-- #EndLibraryItem --></td>
  </tr>
  <tr>
    <td colspan="2"><!-- #BeginLibraryItem "/Library/aesitefoot.lbi" --><!--php-begin-aesitefoot-->
<br>&nbsp;

<!-- WN NAVIGATION ADDED to this include  10.09.09  kl -->      
      <table width="100%" border="1"><tr>
     	<td width="33%" align="center">  <a href="/WN/">Today's Health and <br> BioScience News</a></td>

     	<td width="25%" align="center"> <a href="/WN/su_archives.php">Science Update Archives</a></td>
     	<td width="15%" align="center"> <a href="/WN/Factoids/">Factoids</a></td>
     	<td width="27%" align="center"> <a href="/WN/NM/">Newsmaker Interviews<br> Archive</a></td>
     </tr></table>
 <br>&nbsp;
   <!-- END OF INSERTED WN NAVIGATION   THIS SHOULD REPLACE THE plugger  aeWNSUfoot  AND the plugger aeWNfoot-->
  

<TABLE border="0" align="center" cellpadding="2">
        <TR> 
          <TD valign="top" rowspan="2" align="center"> <A href="http://www.nationalhealthmuseum.org"><IMG src="/graphics/NHMLogo.gif" width="116" height="46" vspace="0" border="0" align="middle"></A></TD>
          <TD colspan="2" valign="middle" nowrap> 
            <DIV align="left"><A href="/captcha/email.cgi"><B><FONT size="-1">Site Feedback</FONT></B></A>&nbsp;&nbsp;
			<A href="/captcha/adfeedback.cgi"><B><FONT size="-1">Ad Content Feedback</FONT></B></A>&nbsp;&nbsp;  
              <A href="/MTC"><B><FONT size="2">About AE</FONT></B></A>&nbsp;&nbsp; 
              <!-- <A href="/ae-bin/webxae.cgi"><B><FONT size="2">Discussions</FONT></B></A>&nbsp;&nbsp; -->
              <A href="/MTC/copyright.html"><B><FONT size="2">Copyright &copy; 
              Info</FONT></B></A>&nbsp;&nbsp;&nbsp;<br><A href="/MTC/privacy.html"><B><FONT size="2">Privacy Policy</FONT></B></A>&nbsp;&nbsp;<B><FONT size="2"></font></B>

              <A href="/sitemap.html"><B><FONT size="2">Sitemap</FONT></B></A>&nbsp;&nbsp;<A href="/captcha/birdcast.cgi"><B><font size="2">Email this Link </font></B></A>&nbsp;&nbsp;<A href="/MTC/contact.html"><B><FONT size="2">Contact 
              </FONT></B></A>&nbsp;&nbsp;<FONT size="2"><B><A href="/index.html">Access 
            Excellence Home</A></B></FONT></DIV>
          </TD>
        </TR>
        <TR> 
          <TD align="left"> 
            			  <style type="text/css">
@import url(http://www.google.com/cse/api/branding.css);
</style>
<div class="cse-branding-right" style="background-color:#FFFFFF;color:#000000">
  <div class="cse-branding-form">
    <form action="http://www.accessexcellence.org/googlesearch.php" id="cse-search-box">
      <div>
        <input type="hidden" name="cx" value="partner-pub-2969868737541392:mvpy0v-6nt8" />
        <input type="hidden" name="cof" value="FORID:9" />
        <input type="hidden" name="ie" value="ISO-8859-1" />
        <input type="text" name="q" size="31" />
        <input type="submit" name="sa" value="Search" />
      </div>
    </form>
  </div>
  <div class="cse-branding-logo">
    <img src="http://www.google.com/images/poweredby_transparent/poweredby_FFFFFF.gif" alt="Google" />
  </div>
  <div class="cse-branding-text">
    Custom Search
  on the AE Site </div>
</div>
          </TD>
        </TR>

</TABLE>
<p>&nbsp;</p>
<!--php-end-aesitefoot--><!-- #EndLibraryItem --></td>
  </tr>
  <tr>
    <td colspan="2"><!-- #BeginLibraryItem "/Library/tailboard.lbi" --><!-- START AE TAILBOARD AD CODE -->
<table cellpadding="0" align="center" cellspacing="0" width="782" border="0">
<tr><td bgcolor="#999999"><IMG border="0" height="1" width="782" src="/b01/en/images/spacer.gif"></td></tr>
<tr><td bgcolor="#999999" align="center">
<table cellpadding="0" cellspacing="0" width="780" border="0" bgcolor="#FFFFFF">
<tr><td align="center"><span style="font: 7pt verdana,arial,helvetica,sans-serif; color: #999999;">-Advertisement-</span></td></tr>
<tr><td><IMG border="0" height="3" width="1" src="/b01/en/images/spacer.gif"></td></tr>
<tr><td align="center">
<!-- AdSense code begin -->

<!-- Ad Sense Media 468x60 and 728x90 Banner CODE for accessexcellence.org -->

                            <script type="text/javascript"><!--
google_ad_client = "pub-2969868737541392";
//728x90, Horizontal
google_ad_slot = "4677513902";
google_ad_width = 728;
google_ad_height = 90;
//--></script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
                            <!-- Ad Sense Media 468x60 and 728x90 Banner CODE for accessexcellence.org -->  

<!-- AdSense code end -->

</td>
</tr>
<tr><td><IMG border="0" height="5" width="1" src="/b01/en/images/spacer.gif"></td></tr>
</table>
</td></tr>
<tr><td bgcolor="#999999"><IMG border="0" height="1" width="782" src="/b01/en/images/spacer.gif"></td></tr>
<tr><td><IMG border="0" height="10" width="1" src="/b01/en/images/spacer.gif"></td></tr>
</table>
<!-- END AE TAILBOARD AD CODE --><!-- #EndLibraryItem --></td>
  </tr>
</table>
<!--php-end-shell-footer-WN--><!--plugger-end-shell-footer-WN-->


<!--php-begin-ae-nhm-survey-->

<!-- BEGIN SURVEY POPUP CODE -->

<!-- END SURVEY POPUP CODE -->

<!--php-end-ae-nhm-survey-->

</body>
</HTML>



