

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

	<head>

		<title>Atkins Diet</title>

		
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta name="description" content="Science examines the Atkins diet." />
<meta name="keywords" content="Atkins diet, low-carb diet, low-carbohydrate diet, fad diet, science" />
<meta name="copyright" content="� Copyright DietPower Calorie Counter Software 1992-2009." />
<meta name="verify-v1" content="bhaLkQyNPSaEC/ZOJh1vJ+HdkZLLBx3bTkuM1iV2bZs=" />

<script src="http://my.dietpower.com/__utm.js" type="text/javascript"></script>
		<link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
		<link rel="stylesheet" href="../stylesheet.css" type="text/css" media="screen, print" />
		<link rel="stylesheet" href="../transmenu.css" type="text/css" media="screen, print" />
        <link rel="stylesheet" type="text/css" href="http://yui.yahooapis.com/2.3.1/build/container/assets/container.css" />

		<script type="text/javascript" src="http://yui.yahooapis.com/2.3.1/build/yahoo-dom-event/yahoo-dom-event.js"></script>
		<script type="text/javascript" src="http://yui.yahooapis.com/2.3.1/build/container/container-min.js"></script>

		<script type="text/javascript" src="../moo.fx/scripts/prototype.lite.js"></script>
		<script type="text/javascript" src="../moo.fx/scripts/moo.fx.js"></script>
		<script type="text/javascript" src="../moo.fx/scripts/moo.fx.pack.js"></script>

		<script type="text/javascript" src="../transMenu.js"></script>
		<script type="text/javascript" src="../buildTransMenu.php"></script>

		<script type="text/javascript" src="../javascript.js"></script>

	</head>

	<body onload="init();">

		<script type="text/javascript">
		<!--
		function checkform (form) {
		  if (form["query"].value == "") {
			alert("Please insert keyword(s) to search for");
			form["query"].focus();
			return false ; }
		 return true; }
		 -->
		</script>
		
<div id="Header">
	<div class="Top">
		<a href="http://www.dietpower.com/how_it_works/whats_new_in_4.4.php"><img src="../images/Main_Header_Starburst.gif" class="Starburst" alt="version 4.4" /></a>		
				
			<form id="googleFrm" method="post" action="../search.php" onsubmit="return checkform(this);">
			<div class="Searchburst">
				<input type="text" name="query" class="txtFrm" />
				<input type="hidden" name="www" value="false" />
				<input type="submit" name="Submit" value="Search" class="btFrm" style="background:url(../images/Main_Nav_BG_Glare.gif) 50% #ccc;
									color:#fff;
									font-weight:bold;
									font-size:9px;
									border:solid 1px #000;
									height:17px;
									cursor:pointer" />
			</div>
			</form>


		<a href="../index.php"><img src="../images/Main_Header_Logo.gif" class="Logo" alt="DietPower Calorie Counter, Diet, Weight Loss Program and Food Diary" /></a>
	</div>
		
		
	<div id="Navigation">
		<div id="content">
			<div id="wrap">
				<div id="menu">
											<a href="../" id="Nav_0">Home</a>
											<a href="../who_we_are/" id="Nav_1">Who We Are</a>
											<a href="../news/" id="Nav_2">News</a>
											<a href="../features/" id="Nav_3">Features</a>
											<a href="../fun/" id="Nav_4">Fun</a>
											<a href="../forums/" id="Nav_5">Forums</a>
											<a href="../tools/" id="Nav_6">Tools</a>
											<a href="../buy_sell_diet_power/" id="Nav_7">Try/Buy/Sell Diet Power</a>
											<a href="../support/" id="Nav_8">Support</a>
											<a href="http://www.dietpower.com/how_it_works/success_stories.php" id="Nav_9">Gallery</a>
									</div>
			</div>
		</div>
	</div>

	<script type="text/javascript">buildTransMenu('../');</script>
	
<!--  Subnavigation  
	<div id="Subnav">
		<div id="content">

			 	
											<a href="../" id="Nav_0">Home</a>
											<a href="../who_we_are/" id="Nav_1">Who We Are</a>
											<a href="../news/" id="Nav_2">News</a>
											<a href="../features/" id="Nav_3">Features</a>
											<a href="../fun/" id="Nav_4">Fun</a>
											<a href="../forums/" id="Nav_5">Forums</a>
											<a href="../tools/" id="Nav_6">Tools</a>
											<a href="../buy_sell_diet_power/" id="Nav_7">Try/Buy/Sell Diet Power</a>
											<a href="../support/" id="Nav_8">Support</a>
											<a href="http://www.dietpower.com/how_it_works/success_stories.php" id="Nav_9">Gallery</a>
									

		</div>
	</div>
-->
	
	
</div>
		<!-- Breadcrumb Navigation

		<div id="Backlink">
			< ? require_once('inc_subnav.php'); ? >
		</div>
		-->
        
        <!-- div id="Ticker">
        	 <marquee style="border-width:0px; border-style:none; font-size:10px; "direction="left" behavior="scroll" scrollamount="4" >             	
            	<a href="http://my.dietpower.com/buy_sell_diet_power/webmasters.php">
                	Got a website? Make $$$ with DietPower's affiliate program.&nbsp;
                    <span style="text-decoration:underline;color:#008000;font-size:10px;">Click here</span></a>.
                    <span style="margin-left:125px;">&nbsp;</span>
                <a href="http://www.dietpower.com/buy/upgrade.php" >
                	Using a competing program? Upgrade to DietPower for $29.99!&nbsp;
                    <span style="text-decoration:underline;color:#008000;font-size:10px;">Click here</span></a>.</marquee>
        </div -->

		<div id="Body">
		<table border="0"><tr><td>
			<table width="100%">
	<tr>
		
		<td>

<div id="Content" style="width:455px; margin-right:20px;">
	<div id="Article">
	<h1>Atkins Diet: Hope or Hype?</h1>
		<h4>By Janet Ford, DietPower Senior Editor</h4>
				<div class="Float_R" style="width:200px">
					<img src="../images/atkinsfoodpyramid180.gif" alt="The Atkins Food Pyramid." /><br />
                	<span class="Caption_Right">The Atkins food pyramid: pile on fats and meat, but eat carbohydrates sparingly.</span>
				</div>
			<p>
				A strange thing has happened over the past couple of years: the whole world seems to think carbohydrates are bad. Restaurants,
				from fast-food to haute-cuisine, are offering low-carb alternatives on menus. America West and Northwest Airlines are handing out low-carb candies to passengers.
				Many hotels feature low-carb programs for guests&#8212;Sheraton even serves low-carb drinks and leaves a low-carb mint on pillows.
				In the supermarket, low-carb products are elbowing others off the shelves. A California company has introduced�the�nation's�first�low-carb�vending machines.
				People on the street and in the media&#8212;even network news anchors&#8212;talk of carbohydrates in the same tones once reserved for PCBs and mercury. What on earth is going on?
			</p>
		<h2>Revolutionary or Quack?</h2>
			<p>
				Robert C. Atkins, M.D., couldn't have known what a dramatic effect he'd have on the nation's eating habits when he introduced his diet back in September 1972.
				With the publication of his 300-page <em>Dr. Atkins' Diet Revolution,</em> he mounted a startling challenge to the medical establishment:
				When everyone else was saying that a low-fat, high-carbohydrate approach was the proper way to lose weight,
				Atkins railed against carbohydrates, insisting that you could lose weight by eating all the fat you wanted.
				What's more,�with Atkins' plan you could�lose weight quickly.�Never mind waiting more than a month to drop 10 pounds; follow Atkins and you could lose that much the first week.
				Helped in part by excerpts that ran in <i>Woman's Day,</i> and <i>Cosmopolitan,</i> the book sold 900,000 copies in the first seven months.
			</p>
			<p>
				A study published the following year in the <i>Journal of the American Medical Association</i> dismissed the diet as junk.
				Atkins had also been accused at various times of quackery, including treating cancer patients with ozone and other alternative therapies.
				The doctor dropped out of the spotlight, and his diet joined a heap of others dismissed as fads.
			</p>
				<div  class="Float_R" style="width:148px; text-align:center">
					<img src="../images/atkins148.jpg" alt="Dr. Robert C. Atkins" /><br />
					<span class="Caption_Right">Dr. Robert Atkins</span>
				</div>			
			<p>
				In 1992 he roared back, however, with the publication of <i>Dr. Atkins' New Diet Revolution.</i>
				Again, the scientific and medical establishment greeted the book either by wagging its finger or ignoring it, hoping it would fade into oblivion.
			</p>
			<p>
				It didn't. Atkins and his book persevered, and the updated version has sold more than 10 million copies.
				By some accounts, 30 million Americans have tried the diet.
			</p>
			<p>
				Meanwhile, the diet has outlived its creator: Robert Atkins died on April 17, 2003, at age 72, days after slipping on an icy Manhattan sidewalk and hitting his head.
				News articles, citing death records, claimed that Atkins was obese at the time of death.
				His defenders were quick to claim that the drugs used to keep him alive in his final days swelled him up like a water balloon.
			</p>
			<p>
				The controversy surrounding the man&#8212;and the diet&#8212;continues. Professional groups such as the American Heart Association,
				the American Medical Association, the American Dietetic Association, and the American Council on Preventive Medicine continue to attack Atkins' theory,
				but no longer dismiss him as a fad. "This has become almost a trend," concedes Dr. Bob Eckel, a spokesman for the Heart Association.
				Even the National Institutes of Health (NIH) has begun some studies looking at the diet's long-term safety and effectiveness.
			</p>
		<h2>Help from the Press</h2>
			<p>
				Why are Atkins and other low-carb diets now at the center of attention? "A lot of things have come together," says Dr. Holly Wyatt,
				an assistant professor of medicine at the University of Colorado's Center for Human Nutrition,�who is studying the Atkins diet for NIH.
				One thing that stands out is the average citizen's girth. "We're now in an obesity epidemic," she says. "America is gaining weight.
				Obesity wasn't on the radar screen twenty years ago."
			</p>			
				<div class="Float_L" style="width:150px;">
					<img src="../images/atkinsbook2.jpg" alt="Atkin's Book, New Diet Revolution" />
				</div>
			<p>
				Figures from the Centers for Disease Control and Prevention (CDC) show that twice as many Americans&#8212;59 million adults&#8212;were obese in 2000 than when Atkins' first book came out. The numbers look even grimmer for children: 9 million, or 15 percent, were overweight in 2000,�three times as many as 20 years earlier. The most recent figures available, from 2003-2004, show that 32 percent of Americans are obese and 66 percent overweight&#8212;and that these will reach 40 percent and 75 percent, respectively, by 2015. Soon,�obesity�will�overtake smoking
				as the top preventable cause of death,�says the CDC.�The stats defy the oft-repeated call for Americans to exercise more,
				adopt a low-fat diet, and eat more of the fruits and vegetables at the base of the Food Pyramid.
			</p>
			<p>
				Also working in Atkins' favor were the publication of both scientific and lay articles that cast favorable light on the diet.
				Atkins dieters indeed lost weight, and in some cases they didn't raise their dangerous cholesterol levels as the alarmist heart doctors had warned&#8212;at least in the short haul. "There are no terrible things that we know of," says Dr. Eric C. Westman, lead author of one
				such study that appeared in the July 2002 <i>American Journal of Medicine.</i> In the same month, a cover article in the
				<i>New York Times Magazine</i> argued that Atkins may have been right all along. That a highly respected mainstream publication
				would run such an article "had some impact," says Eckel, a professor of medicine at the University of Colorado Health Sciences Center.
			</p>
			<p>
				Positive word of mouth doesn't hurt, either, observes Eckel. "When your neighbor has lost ten pounds in seven days, you say, 'Isn't that amazing?'"
			</p>
		<h2>The Four Phases of Atkins</h2>
			<p>
				Okay, what's so "amazing" about the Atkins diet? And is the diet safe and effective? According to Atkins&#8212;and the company he founded, Atkins Nutritionals&#8212;this four-phase eating plan will help you lose weight,
				keep it off, be healthy, and prevent disease. Here's how it works:
			</p>
			<h3><em>Phase 1: Induction</em></h3>
				<p>
					For a minimum of 14 days, Atkins dieters are instructed to eat only what can be found on Atkins' "Acceptable Foods" list.
					This includes liberal amounts of protein and fat,�specifically red meat, poultry, fish, shellfish, eggs, butter, mayonnaise,
					olive oil, safflower, sunflower, and other vegetable oils. Carbohydrate consumption is restricted to 20 grams per day, and
					must be obtained mostly from salad and other non-starchy vegetables. Absolutely no fruit, bread, pasta, grains, starchy vegetables,
					or dairy products (other than cheese, cream, and butter) may be consumed. Nuts and seeds are also banned the first two weeks,
					as are foods that combine protein and carbohydrates, such as chickpeas, kidney beans, and other legumes.
					Any drinks containing caffeine must be avoided.
				</p>
				<p>
					According to Atkins, your body's chemistry changes during this stage, from a carbohydrate-burning metabolism to a fat-burning one.
					Blood sugar stabilizes, and as a result you will feel less fatigued and moody. You will curb your food cravings and break any
					addictions to sugar, wheat, caffeine, and any other food.
				</p>
			<h3><em>Phase 2: Ongoing Weight Loss (OWL)</em></h3>				
					<p><div  class="Float_R" style="width:250px;margin-top:6px;">
						<img src="../images/lowcarblunch.jpg" alt="A typical low-carb lunch." /><br />
						<span class="Caption_Right">This is healthful? A typical low-carb lunch of veggies, protein, and high-fat dressing.</span>
					</div>
				
					During the second phase, you increase your carbohydrate intake�to 25 grams daily the first week, 30 grams daily the next week, etc.,
					until you stop losing weight. Atkins suggests that during the first week of OWL you add either a leafy salad,�half an avocado, a cup
					of cauliflower, six to eight stalks of asparagus, or another vegetable each day. The following week you can try more greens and other
					vegetables, half a cup of cottage cheese, one ounce of sunflower seeds, or a dozen macadamia nuts. You can also eat blueberries,
					strawberries, raspberries, blackberries, and other fruits, depending on whether they trigger cravings.�When�you�stop losing weight,
					you subtract five grams of carbohydrate from your daily allotment, so that slow weight loss continues.
					You stay in this phase until you're within five to ten pounds of your goal.
				</p>
			<h3><em>Phase 3: Pre-Maintenance</em></h3>
				<p>
					Now you increase daily carbohydrate intake by 10-gram increments each week to maintain weight loss of less than a pound a week.
					This phase typically lasts two to three months until you reach your goal.
				</p>
			<h3><em>Phase 4: Lifetime Maintenance</em></h3>
				<p>
					In the final phase, you can select from a wider variety of foods while still controlling your carb intake.
					According to the plan, each person can eat a certain amount of carbs, called the "Atkins Carbohydrate Equilibrium,"
					before he or she begins putting on weight. If you stay at this level, you will not gain weight.
					If you go over it,�your weight will inch upward and you'll need to return to an earlier weight-loss phase.
				</p>
		<h2>What the Critics Say</h2>
			<p>
				It's important to remember that Dr. Atkins was a physician, not a scientist. He based his diet on years of clinical observation,
				not on experiments constructed to rule out any bias. This doesn't mean that his diet is hogwash. A few scientific studies
				performed after the diet became popular have given it a modicum of support. Still, it flies in the face of decades of mainstream
				nutrition research, and this makes it vulnerable to criticism from the scientific community.
			</p>
			<p>
				For many professional groups, the problems with the Atkins diet are obvious. The Mayo Clinic, in its online analysis,
				states that eating a high-protein diet may mean consuming foods high in saturated fat, which raises your cholesterol
				level and increases your risk of heart disease. In its advice to dieters, the Mayo Clinic cautions people to avoid
				any weight-loss program that lists "good" and "bad" foods, reminding people that it's the calories that count in losing weight.
			</p>
			<p>
				Atkins claims that "bad" carbohydrates&#8212;especially refined carbs found in white bread and pasta, jams, desserts,
				other sugary stuff, and�potato chips&#8212;create a rush in insulin, "which tells your body to store fat," says Dr. Mary Vernon,
				a family practitioner in Lawrence, Kansas, and a staunch advocate of the Atkins diet. Other supporters say that the
				human body burns calories from protein-laden foods, which have been around for thousands of years,
				more efficiently than those from refined carbohydrates.
			</p>
			<p>
				Over the past generation, however, these carb-rich foods have become a staple of the American diet.
				If you follow the medical establishment's mantra and try to eat a low-fat diet, staying away from meats and junk food,
				"the rest of the food is kind of boring," says Christopher D. Gardner, an assistant professor at the Stanford
				University School of Medicine who is taking part in one of the new NIH studies.
			</p>
			<p>
				Gardner says that food marketers helped spur the obesity epidemic by relaying the wrong message about consuming less fat.
				Promoting the consumption of more whole grains was "way too complicated," he says, so they went ahead with a simpler approach.
				"They replaced it not with good things, but with low-fat crap," he says. "Low-fat, but not low-calorie."
			</p>
			<p>
				Calories appear to be the key to the success of the Atkins diet. "Something suppresses appetite," Westman says.
				While you may be allowed to eat as much fat and protein as you like, chances are that you won't because you can't.
				"There's no magic," he says.
			</p>
		<h2>Jury's Still Out</h2>
			<p>
				Despite the claims of both sides, there have been no long-term studies to show the benefits and risks of the Atkins diet.
				Most research has looked at the effects of the diet over the course of months, not years. Even Westman and Wyatt,
				who have published favorable studies on the outcomes, say they're not yet ready to give the diet a ringing endorsement over the long haul.
			</p>

			<p>
				Wyatt co-authored an important study published in the <i>New England Journal of Medicine.</i> It found that people on
				Atkins lost weight faster in the first six months, but there was no difference after a year. However,
				Atkins dieters fared better in controlling their cholesterol.
				That "doesn't necessarily mean we know how Atkins works three or four years down the road," she says.
			</p>
				<div class="Float_L" style="width:130px; text-align:center; margin-top:4px;">
					<img src="../images/ornish5.jpg" alt="Dr. Dean Ornish" /><br />
					<span class="Caption_Left">Dr. Dean Ornish</span>
				</div>
			<p>
				"There's no data showing that Atkins produces more weight loss, or that it's safe," Westman adds. "There's really not enough information."
			</p>
			<p>
				"Telling people what they want to believe is part of the reason Atkins has become so popular," writes�Dr. Dean Ornish,
				whose own diet restricts fat consumption. The Atkins dieters' initial weight loss and cholesterol improvement are counterintuitive,
				he says, like watching a dog walking on its hind legs. "It doesn't do it well, but it's amazing that it can do it at all,"
				he writes in the <i>Journal of the American Dietetic Association.</i> Like most authorities, Ornish believes people should cut fat,
				which is twice as rich in calories as carbs and protein are.
			</p>
			<p>
				"Calories are the villain," Eckel continues. Carbohydrates, in his opinion, are "an innocent victim" of the craze.
			</p>
		<h2>Heart Attacks and Bad Breath</h2>
			<p>
				Eckel warns that, over the years, the Atkins diet could cause more heart attacks because of increased fat intake.
				He says it can also create calcium losses that may lead to a decrease in bone mass. In addition, chemical compounds
				called ketones that it releases into the bloodstream may harm people with diabetes and underlying kidney disease.
			</p>
			<p>
				Ketones can also cause bad breath. "You may lose weight and start to attract people to you, but when they get too close,
				it may be counterproductive," Ornish writes with tongue in cheek. Vernon, the Atkins supporter, retorts,
				"Are you willing to brush your teeth more often instead of being obese?"
			</p>
			<p>
				Vernon doesn't see the health risks. "If 30 million Americans are on Atkins, it should be causing an epidemic of problems.
				Where are those?" she wonders. She is on an Atkins maintenance diet, "which for me would be a chicken, a pretty salad,
				squash with butter, fresh strawberries for dessert. Does that sound like an unhealthy diet?"
			</p>
			<p>
				Gardner, who for the NIH is looking at the effects of the diet over the course of a year, calls his work in progress "a stupid study.
				A year isn't long enough. But at least it's longer than others." One reason for the lack of government interest, he says,
				is that "people look at these things and say, 'They're fad diets. By the time you're done, the diet will be gone.'"
			</p>
			<p>
				Eckel, the Heart Association spokesman, agrees that looking at the diet for an extended period is crucial. '
				"We still have no evidence that it's better long-term than at three to six months," he says. "A quick fix for obesity is not the answer."
			</p>
			<div style="clear:right;text-align:right;padding-top:1.5em;">
			
							<strong>To comment on this article, <script type="text/javascript">displayEmail("webmaster","click here","Comment on Atkins article [sent from atkins_diet]");</script>.</strong>
							<br /><br />
					<!--
						<a href="http://digg.com/api/diggthis.php?u=http:///features/atkins_diet.php"><img src="../images/digg-guy.png" alt="digg" style="margin-right: 5px;" /></a>
						<a href="http://del.icio.us/post?v=2&amp;url=http:///features/atkins_diet.php"><img src="../images/del.icio.us.png" alt="del.icio.us" style="margin-right: 5px;" /></a>
						<a href="http://www.netscape.com/submit/?U=http:///features/atkins_diet.php"><img src="../images/netscape.png" alt="netscape" style="margin-right: 5px;" /></a>
						<a href="http://www.newsvine.com/_tools/seed&amp;save?popoff=0&amp;u=http:///features/atkins_diet.php"><img src="../images/newsvine.png" alt="newsvine" style="margin-right: 5px;" /></a>
						<a href="http://furl.net/storeIt.jsp?u=http:///features/atkins_diet.php"><img src="../images/furl.png" alt="furl" style="margin-right: 5px;" /></a>
						-->
						<!-- AddThis Bookmark Button BEGIN -->
						<script type="text/javascript">
							addthis_url    = location.href;   
							addthis_title  = document.title;  
							addthis_pub    = 'bfitzpatrick';     
						</script><script type="text/javascript" src="http://s7.addthis.com/js/addthis_widget.php?v=12" ></script>
						<!-- AddThis Bookmark Button END -->
					</div>



	</div>
</div>

</td>

		<td>
			<div class="Right_Side">
			<style type="text/css">
<!--
.style1 {
	color: #cc0000
}
.style2 {
	font-size: 21px
}
-->
</style>
<div id="Sidebar">
	<div class="Top"></div>
	<div class="Links" >
		<div style="font-size:11px;">
			<h2 class="style1 style2" style="margin-top:6px;">  Upgraded Yet?</h2>
		  <a href="http://www.dietpower.com/buy/upgrade.php" title="How to Upgrade to DietPower 4.4" style="margin-left:19px;"><img src="../images/upgrade_car_ani_2.gif" alt="Find out How to Upgrade to DietPower 4.4"  style="margin-top:0px;margin-bottom:-6px;" /></a>
		  <p style="margin-top:0px;margin-bottom:-2px;font-size:11px;">&nbsp;</p>
			<p style="margin-top:0px;margin-bottom:-2px;font-size:11px;">Don't  miss the  <a href="http://www.dietpower.com/how_it_works/whats_new_in_4.4.php">improvements</a> we've engineered into  new DietPower 4.4, the world's best  weight-loss and nutrition software!</p>
<ul style="font-size:11px;">
			  <li style="margin-left:-24px;margin-bottom:-8px;">			    Updated Food Dictionary</li>
			  <li style="margin-left:-24px;margin-bottom:-8px;">			    Real-Time Eating Coach&#8482;</li>
			  <li style="margin-left:-24px;margin-bottom:-8px;">			    Smarter, faster  Food Log</li>
			  <li style="margin-left:-24px;margin-bottom:-8px;">			    Daily nutrition news</li>
			  <li style="margin-left:-24px;margin-bottom:-8px;">			    Trans Fat monitoring</li>
			  <li style="margin-left:-24px;margin-bottom:-8px;">			    Logging by volume <em>or</em> weight</li>
			  <li style="margin-left:-24px;margin-bottom:-8px;">			    Win7 & Vista compatibility</li>
			  <li style="margin-left:-24px;margin-bottom:-8px;">			    Low upgrade price: $29.95</li>
			  <li style="margin-left:-24px;margin-bottom:-8px;">			    Free updates through 2011</li>
		      <li style="margin-left:-24px;">And  <a href="http://www.dietpower.com/how_it_works/whats_new_in_4.4.php">
            more</a>....          </li>
	      </ul>
	      <p><a href="http://www.dietpower.com/upgrade.php">Click Here to Upgrade</a></p>
	      <h2>Feature Articles</h2>

            <a href="http://my.dietpower.com/features/overweight_risks.php">Is Your Weight Killing You?</a><br />
            <a href="http://my.dietpower.com/features/best_weight_loss_exercise.php">Best Weight-Loss Exercise</a><br />
            <a href="http://my.dietpower.com/features/get_slim_slippers.php">Testing &quot;Get Slim&quot; Slippers&reg;</a><br />
            <a href="http://my.dietpower.com/features/calories_stupid.php">The <em>Only</em> Way to Lose Weight</a><br />
            <a href="http://my.dietpower.com/tools/fast_food_facts.php">Fast-Food Nutrition Facts</a><br />
            <a href="http://my.dietpower.com/features/atkins_diet.php">Atkins Diet: Hope or Hype?</a><br />
            <a href="http://my.dietpower.com/features/south_beach_diet.php">Does South Beach Work?</a><br />
            <a href="http://my.dietpower.com/features/dietary_guidelines.php">Dietary Guidelines Simplified</a><br />
            <a href="http://my.dietpower.com/features/food_myths.php">6 Food Myths (or Are They?)</a><br />
            <a href="http://my.dietpower.com/features/sodium.php">I'd Rather Salt it Myself</a><br />
            <a href="http://my.dietpower.com/features/whole_grains.php">Still Eating White Bread?</a><br />
            <a href="http://my.dietpower.com/features/diabetes.php">Diabetes and Nutrition</a><br />
            <a href="http://my.dietpower.com/features/lose_10_pounds.php">&quot;Lose 10 Pounds in 10 Days!&quot;</a><br />
          <a href="http://my.dietpower.com/features/exercise_health_benefits.php">Getting Enough Vitamin E<sub>10</sub>?</a><br />			
			<h2 style="margin-bottom:-4px;"><b>Weight-Loss Tools</b></h2>
			<h2 align="left"><a href="http://www.dietpower.com/" title="Read about our Calorie Counter"><img src="../images/whistle96.jpg" alt="Calorie counting and nutrition software coach"  style="margin-top:-6px;margin-bottom:-24px;margin-left:34px;" /></a></h2>
			<p><a href="http://www.dietpower.com/" title="Monitor your caloric and nutrient intake with DietPower.">Try Our Eating Coach&#8482; FREE</a></p>
		  <p align="left"><a href="http://my.dietpower.com/tools/how_fat_are_you.php" title="Body Mass Index"><img src="../images/rhino86.jpg" alt="Rhino"  style="margin-top:0px;margin-bottom:-18px;margin-left:38px;" /></a>
		  </p>
		    </p>
			<a href="http://my.dietpower.com/tools/how_fat_are_you.php">Find Your Body Mass Index</a>
		  <p align="left"><a href="http://my.dietpower.com/tools/calorie_counter.php" title="Read about our Calorie Counter"><img src="../images/abacus_closeup_76.jpg" alt="Abacus"  style="margin-top:0px;margin-bottom:-14px;margin-left:43px;" /></a></p>
			<p><a href="http://my.dietpower.com/tools/calorie_counter.php">  Use Online Calorie Counter</a></p>
			<p align="left" style="margin-bottom: 10px"><a href="http://my.dietpower.com/tools/target_heart_rate_calculator.php" title="Heart rate wristwatch"><img src="../images/heart_watch_sidebar.jpg" alt="Heart rate wristwatch"  style="margin-top:0px;margin-bottom:-16px;margin-left:51px;" /></a></p>
		  <p style="margin-bottom: 10px"><a href="http://my.dietpower.com/tools/target_heart_rate_calculator.php">Find Your Target Heart Zone</a></p>
			<p align="left" style="margin-bottom:10px"><a href="http://www.pcworld.com/reviews/article/0,aid,124089,00.asp"><img src="../images/pcworldlogo170.gif" alt="Click to read the review." /></a></p>
	  </div>
  </div>
	<div class="Bottom"></div>
</div>			</div>
		</td>
</tr>
</table>			</td></tr>
		</table>
			<div class="Horizontal_Rule" style="padding-top:0px;"></div>
				<table class="centered-table" border="0" cellpadding="0" cellspacing="0" width="555">
  					<tr>
    					<td valign="top">
							<div><a href="http://www.hon.ch/HONcode/Conduct.html?HONConduct662178">
								<img src="../images/50_Hon_Code_Off.gif" onmouseover="turnOnImage(this)" onmouseout="turnOffImage(this)" alt="Health on the Net principles" />
								</a>
							</div>
					  </td>
    					<td valign="top" style="width:145px; font-weight:normal; font-size:10px">
							We subscribe to the
							<a style="font-weight:normal; font-size:10px" class="link7pt" href="http://www.hon.ch/HONcode/Conduct.html?HONConduct662178">
							HONcode principles of the Health on the Net Foundation</a>.
						</td>
    					<td valign="top" style="width:71px">&nbsp;</td>
    					<td valign="top" style="width:134px">
        					<a href="../who_we_are/science_advisers.php#coulston">
							<img src="../images/50_coulston_Off.jpg" onmouseover="turnOnImage(this)" onmouseout="turnOffImage(this)" alt="Ann Coulston (click for details)" /></a>&nbsp;
							<a href="../who_we_are/science_advisers.php#epstein">
							<img src="../images/50_epstein_Off.jpg" onmouseover="turnOnImage(this)" onmouseout="turnOffImage(this)" alt="Robert Epstein (click for details)"/></a>&nbsp;
							<a href="../who_we_are/science_advisers.php#franklin">
							<img src="../images/50_franklin_Off.jpg" onmouseover="turnOnImage(this)" onmouseout="turnOffImage(this)" alt="Barry Franklin (click for details)"/></a>
						</td>
    					<td valign="top" style="width:150px; font-weight:normal; font-size:10px">
							<a class="link7pt" style="font-weight:normal; font-size:10px" href="../who_we_are/science_advisers.php">
							Click&nbsp; here</a> to see biographies <br />
							of DietPower's scientific <br />
							advisory board members.	</td>
  					</tr>
		  </table>

<p style="font-size:10px; text-align:justify; margin-top:12px; margin-bottom:12px"> SPAM POLICY: DietPower doesn't send emails to people who haven't requested them, nor do we share email addresses with third parties.  If you suspect that someone has subscribed you to our calorie counter mailing list fraudulently, email us at <a style="font-size:10px" href="mailto:webmaster@dietpower.com?subject=[sent from my.dietpower.com homepage]">webmaster@dietpower.com</a>.</p>

		</div>

		<div id="Shadow_Bottom">&nbsp;</div>

		<div id="Footer">
	<a href="../" title="Diet Power Community Home Page">Home</a> |
	<a href="../who_we_are/" title="Diet Power Company Information">Who We Are</a> |
	<a href="../news/" title="Health and Nutrition News">News</a> |
	<a href="../features/" title="Feature Articles Relating to Weight Loss, Weight Related Diseases and Nutrition">Features</a> |
	<a href="../fun/">Fun</a> |
	<a href="../forums/" title="Diet Power Community Forums">Forum</a> |
	<a href="../tools/" title="Free Weight Loss and Motivational Tools">Tools</a> |
	<a href="../buy_sell_diet_power/">Sell</a> |
	<a href="../support/">Support</a> |
	<a href="../who_we_are/contact_us.php">Contact</a> |
	<a href="../sites_we_like/links.htm">Links</a> |
	<a href="http://www.dietpower.com/how_it_works/success_stories.php">Gallery</a> |
	<a href="http://www.dietpower.com/" title="Calorie Counter, Wieght Loss, and Diet Software">DietPower.com</a> |
	<a href="../sitemap.php">Site Map</a><br />
	<div id="Copyright">
		Copyright &copy; 1992-2010 by Diet Power, Inc., 7 Kilian Drive, Danbury, CT 06811. All rights reserved. The name <em>Diet Power</em> and the apple
		and runner symbols are trademarks of Diet Power, Inc. Information on this site is meant to increase your awareness of the importance of
		nutrition to health. It is not meant to substitute for the advice of a health professional.
	</div>
	<div id="Last_Modified">Last modified 13:34 March 14, 2009</div>
</div>

		
		<script type="text/javascript">
			var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
			document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
			</script>
			<script type="text/javascript">
			var pageTracker = _gat._getTracker("UA-379693-2");
			pageTracker._initData();
			pageTracker._trackPageview();
		</script>
        
        <script src="http://www.dietpower.com/gatag.js" type="text/javascript"></script> 
        
        		
	</body>

</html>
