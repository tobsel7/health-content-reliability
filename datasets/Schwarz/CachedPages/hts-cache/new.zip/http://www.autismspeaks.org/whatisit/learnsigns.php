<!-- OpenPad Enterprise v3.8.0.3767 -->
<!-- AUTISM SPEAKS ROOT CREATOR TEMPLATE -->
<!-- PAGE ID: 5853 -->
<!-- PAGE NAME: learnsigns -->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en-US" xml:lang="en-US">
<head>
<title>Autism Speaks, Be Informed, What is Autism, Learn the Signs</title>
<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1" />
<meta name="Keywords" content="autism, autistic, signs of autism, autism symptoms, autism treatment, autism spectrum disorder, autism research, autism speaks, autism information, autism diagnosis, autism" />
<meta name="Description" content="" />
<link rel="stylesheet" type="text/css" media="screen" href="/css/global.css" />
<meta http-equiv="pragma" content="no-cache" />
<meta http-equiv="cache-control" content="no-cache" />
<link rel="stylesheet" type="text/css" media="print" href="/css/cms/print.css" />
<link rel="shortcut icon" href="/favicon.ico" />
<script type="text/javascript" src="/js/gs.js"></script>
<script type="text/javascript" src="/js/ds.js"></script>
<!-- Begin Google Analytics -->
<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-3170412-1']);
  _gaq.push(['_setDomainName', 'none']);
  _gaq.push(['_setAllowLinker', true]);
  _gaq.push(['_trackPageview']);
 (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>
<!-- End Google Analytics -->

</head>
<body onload="init();">
<div id="wrapper" style="background-color:#ffffff; layer-background-color:#ffffff;">
<div id="prop" style="height:1541px;"></div>
<div id="border-top"></div>
<div id="border-right"></div>
<div id="border-left"></div>
<div id="border-bottom"></div>
<div id="layer0" style="position:absolute; left:146px; top:0px; width:634px; height:31px; z-index:99;">
<!-- GLOBAL NAVIGATION SERVER MODULE -->
<!-- V2: Transform Styles based on site section -->
<style type="text/css">
</style>
<!-- WEBTRENDS CONTENT GROUPING TAG -->
<meta name="WT.cg_n" content="Be Informed" />
<!-- SKIP-LINK FOR SCREEN-READERS -->
<a href="#content" title="Click here to skip main navigation links"></a>
<!-- GLOBAL NAV MENU ITEMS: POSITIONING SET IN global.css -->
<script type="text/javascript" src="/js/nav.js"></script>
<script type="text/javascript">
loadImages("/images/nav/gnav2-1-off.gif","/images/nav/gnav2-1-on.gif","/images/nav/gnav2-2-off.gif","/images/nav/gnav2-2-on.gif","/images/nav/gnav2-3-off.gif","/images/nav/gnav2-3-on.gif","/images/nav/gnav2-4-off.gif","/images/nav/gnav2-4-on.gif","/images/nav/gnav2-5-off.gif","/images/nav/gnav2-5-on.gif","/images/nav/gnav2-6-off.gif","/images/nav/gnav2-6-on.gif");
loadImages("/images/nav/menu2-a-01-off.gif","/images/nav/menu2-a-01-on.gif","/images/nav/menu2-a-02-off.gif","/images/nav/menu2-a-02-on.gif","/images/nav/menu2-a-03-off.gif","/images/nav/menu2-a-03-on.gif","/images/nav/menu2-a-04-off.gif","/images/nav/menu2-a-04-on.gif","/images/nav/menu2-a-05-off.gif","/images/nav/menu2-a-05-on.gif","/images/nav/menu2-a-06-off.gif","/images/nav/menu2-a-06-on.gif","/images/nav/menu2-a-08-off.gif","/images/nav/menu2-a-08-on.gif","/images/nav/menu2-a-09-off.gif","/images/nav/menu2-a-09-on.gif");
loadImages("/images/nav/menu2-b-01-off.gif","/images/nav/menu2-b-01-on.gif","/images/nav/menu2-b-02-off.gif","/images/nav/menu2-b-02-on.gif","/images/nav/menu2-b-03-off.gif","/images/nav/menu2-b-03-on.gif","/images/nav/menu2-b-04-off.gif","/images/nav/menu2-b-04-on.gif","/images/nav/menu2-b-05-off.gif","/images/nav/menu2-b-05-on.gif","/images/nav/menu2-b-06-off.gif","/images/nav/menu2-b-06-on.gif");
loadImages("/images/nav/menu2-c-01-off.gif","/images/nav/menu2-c-01-on.gif","/images/nav/menu2-c-02-off.gif","/images/nav/menu2-c-02-on.gif","/images/nav/menu2-c-03-off.gif","/images/nav/menu2-c-03-on.gif","/images/nav/menu2-c-04-off.gif","/images/nav/menu2-c-04-on.gif","/images/nav/menu2-c-05-off.gif","/images/nav/menu2-c-05-on.gif","/images/nav/menu2-c-06-off.gif","/images/nav/menu2-c-06-on.gif","/images/nav/menu2-c-07-off.gif","/images/nav/menu2-c-07-on.gif","/images/nav/menu2-c-08-off.gif","/images/nav/menu2-c-08-on.gif");
loadImages("/images/nav/menu2-e-01-off.gif","/images/nav/menu2-e-01-on.gif","/images/nav/menu2-e-02-off.gif","/images/nav/menu2-e-02-on.gif","/images/nav/menu2-e-03-off.gif","/images/nav/menu2-e-03-on.gif","/images/nav/menu2-e-04-off.gif","/images/nav/menu2-e-04-on.gif","/images/nav/student-clubs-off.gif","/images/nav/student-clubs-on.gif","/images/nav/menu2-e-05-off.gif","/images/nav/menu2-e-05-on.gif","/images/nav/menu2-e-06-off.gif","/images/nav/menu2-e-06-on.gif","/images/nav/menu2-e-07-off.gif","/images/nav/menu2-e-07-on.gif");
loadImages("/images/nav/menu2-f-01-off.gif","/images/nav/menu2-f-01-on.gif","/images/nav/menu2-f-02-off.gif","/images/nav/menu2-f-02-on.gif","/images/nav/menu2-f-03-off.gif","/images/nav/menu2-f-03-on.gif","/images/nav/menu2-f-04-off.gif","/images/nav/menu2-f-04-on.gif","/images/nav/menu2-f-05-off.gif","/images/nav/menu2-f-05-on.gif","/images/nav/menu2-f-06-off.gif","/images/nav/menu2-f-06-on.gif","/images/nav/menu2-f-07-off.gif","/images/nav/menu2-f-07-on.gif");
</script>
<table cellpadding="0" cellspacing="0" border="0" width="540px">


	<tr>
		<td><a href="/about_us.php" onmouseover="changeImages('home','/images/nav/gnav2-1-on.gif','globalNav'); overNav('home');" onmouseout="changeImages('home','/images/nav/gnav2-1-off.gif','globalNav'); outNav('home');"><img name="home" src="/images/nav/gnav2-1-off.gif" width="111" height="31" alt="Autism Speaks" border="0" /></a></td>
		<td><a href="/be_informed.php" onmouseover="overNav('informed');" onmouseout="outNav('informed');"><img name="informed" src="/images/nav/gnav2-2-on.gif" width="129" height="31" alt="Be Informed" border="0" /></a></td>
		<td><a href="/get_involved.php" onmouseover="changeImages('involved','/images/nav/gnav2-3-on.gif','globalNav'); overNav('involved');" onmouseout="changeImages('involved','/images/nav/gnav2-3-off.gif','globalNav'); outNav('involved');"><img name="involved" src="/images/nav/gnav2-3-off.gif" width="104" height="31" alt="Get Involved" border="0" /></a></td>
		<td><a href="/walk_events/index.php" onmouseover="changeImages('walk_events','/images/nav/gnav2-4-on.gif','globalNav');" onmouseout="changeImages('walk_events','/images/nav/gnav2-4-off.gif','globalNav');"><img name="walk_events" src="/images/nav/gnav2-4-off.gif" width="86" height="31" alt="Walk Events" border="0" /></a></td>
		<td><a href="/community/family_services/index.php" onmouseover="changeImages('community','/images/nav/gnav2-5-on.gif','globalNav'); overNav('community');" onmouseout="changeImages('community','/images/nav/gnav2-5-off.gif','globalNav'); outNav('community');"><img name="community" src="/images/nav/gnav2-5-off.gif" width="97" height="31" alt="Community" border="0" /></a></td>
		<td><a href="/science/index.php" onmouseover="changeImages('science','/images/nav/gnav2-6-on.gif','globalNav'); overNav('science');" onmouseout="changeImages('science','/images/nav/gnav2-6-off.gif','globalNav'); outNav('science');"><img name="science" src="/images/nav/gnav2-6-off.gif" width="107" height="31" alt="Science" border="0" /></a></td>
	</tr>

</table>

<!-- MENUS: POSITIONING SET IN global.css -->

<div id="homeMenu" onmouseover="setMenuOver('home');" onmouseout="setMenuOver(null); outMenu('home');">
	<div><a href="/about_us.php" onmouseover="changeImages('about_us','/images/nav/menu2-a-01-on.gif','homeMenu'); " onmouseout="changeImages('about_us','/images/nav/menu2-a-01-off.gif','homeMenu'); "><img name="about_us" src="/images/nav/menu2-a-01-off.gif" width="111" height="19" alt="About Us" border="0" /></a></div>
	<div><a href="/mission.php" onmouseover="changeImages('mission','/images/nav/menu2-a-02-on.gif','homeMenu'); " onmouseout="changeImages('mission','/images/nav/menu2-a-02-off.gif','homeMenu'); "><img name="mission" src="/images/nav/menu2-a-02-off.gif" width="111" height="15" alt="Mission" border="0" /></a></div>
	<div><a href="/science/index.php" onmouseover="changeImages('science_mission','/images/nav/menu2-a-03-on.gif','homeMenu'); " onmouseout="changeImages('science_mission','/images/nav/menu2-a-03-off.gif','homeMenu'); "><img name="science_mission" src="/images/nav/menu2-a-03-off.gif" width="111" height="15" alt="Science" border="0" /></a></div>
    	<div><a href="/awareness/index.php" onmouseover="changeImages('awareness','/images/nav/menu2-a-04-on.gif','homeMenu'); " onmouseout="changeImages('awareness','/images/nav/menu2-a-04-off.gif','homeMenu'); "><img name="awareness" src="/images/nav/menu2-a-04-off.gif" width="111" height="15" alt="Awareness" border="0" /></a></div>
    	<div><a href="http://www.autismvotes.org" target="_blank" onmouseover="changeImages('advocacy','/images/nav/menu2-a-05-on.gif','homeMenu'); " onmouseout="changeImages('advocacy','/images/nav/menu2-a-05-off.gif','homeMenu'); "><img name="advocacy" src="/images/nav/menu2-a-05-off.gif" width="111" height="15" alt="Advocacy" border="0" /></a></div>
    	<div><a href="/community/family_services/index.php" onmouseover="changeImages('family_services','/images/nav/menu2-a-06-on.gif','homeMenu'); " onmouseout="changeImages('family_services','/images/nav/menu2-a-06-off.gif','homeMenu'); "><img name="family_services" src="/images/nav/menu2-a-06-off.gif" width="111" height="15" alt="Family Services" border="0" /></a></div> 
	<div><a href="/inthenews/index.php" onmouseover="changeImages('inthenews','/images/nav/menu2-a-08-on.gif','homeMenu'); " onmouseout="changeImages('inthenews','/images/nav/menu2-a-08-off.gif','homeMenu'); "><img name="inthenews" src="/images/nav/menu2-a-08-off.gif" width="111" height="15" alt="In the News" border="0" /></a></div>
	<div><a href="/press/index.php" onmouseover="changeImages('press','/images/nav/menu2-a-09-on.gif','homeMenu'); " onmouseout="changeImages('press','/images/nav/menu2-a-09-off.gif','homeMenu'); "><img name="press" src="/images/nav/menu2-a-09-off.gif" width="111" height="19" alt="Press Releases" border="0" /></a></div>
</div>


<div id="informedMenu" onmouseover="setMenuOver('informed');" onmouseout="setMenuOver(null); outMenu('informed');">
	<div><a href="/whatisit/index.php" ><img name="whatisit" src='/images/nav/menu2-b-01-on.gif' width="129" height="21" alt="What is Autism" border="0" /></a></div>
	<div><a href="/video/glossary.php" onmouseover="changeImages('video_glossary','/images/nav/menu2-b-02-on.gif','informedMenu'); " onmouseout="changeImages('video_glossary','/images/nav/menu2-b-02-off.gif','informedMenu'); "><img name="video_glossary" src='/images/nav/menu2-b-02-off.gif' width="129" height="15" alt="Video Glossary" border="0" /></a></div>
	<div><a href="/diagnosis/index.php" onmouseover="changeImages('diagnosis','/images/nav/menu2-b-03-on.gif','informedMenu'); " onmouseout="changeImages('diagnosis','/images/nav/menu2-b-03-off.gif','informedMenu'); "><img name="diagnosis" src='/images/nav/menu2-b-03-off.gif' width="129" height="16" alt="Diagnosis" border="0" /></a></div>
	<div><a href="/treatment/index.php" onmouseover="changeImages('treatment','/images/nav/menu2-b-04-on.gif','informedMenu'); " onmouseout="changeImages('treatment','/images/nav/menu2-b-04-off.gif','informedMenu'); "><img name="treatment" src='/images/nav/menu2-b-04-off.gif' width="129" height="16" alt="Treatment" border="0" /></a></div>
	<div><a href="/rights/index.php" onmouseover="changeImages('rights','/images/nav/menu2-b-05-on.gif','informedMenu'); " onmouseout="changeImages('rights','/images/nav/menu2-b-05-off.gif','informedMenu'); "><img name="rights" src='/images/nav/menu2-b-05-off.gif' width="129" height="16" alt="Your Child's Rights" border="0" /></a></div>
	<div><a href="/family/index.php" onmouseover="changeImages('family','/images/nav/menu2-b-06-on.gif','informedMenu'); " onmouseout="changeImages('family','/images/nav/menu2-b-06-off.gif','informedMenu'); "><img name="family" src='/images/nav/menu2-b-06-off.gif' width="129" height="20" alt="Autism and Your Family" border="0" /></a></div>
</div>

<div id="involvedMenu" onmouseover="setMenuOver('involved');" onmouseout="setMenuOver(null); outMenu('involved');">
	<div><a href="/donate/index.php" onclick="pageTracker._trackEvent('Donation Links', 'Global Nav');"onmouseover="changeImages('donate','/images/nav/menu2-c-01-on.gif','involvedMenu'); " onmouseout="changeImages('donate','/images/nav/menu2-c-01-off.gif','involvedMenu'); "><img name="donate" src='/images/nav/menu2-c-01-off.gif' width="104" height="21" alt="Donate" border="0" /></a></div>
	<div><a href="http://action.autismspeaks.org/hope" onclick="pageTracker._trackEvent('Donation Links', 'Global Nav');" onmouseover="changeImages('donatenow','/images/nav/menu2-c-02-on.gif','involvedMenu'); " onmouseout="changeImages('donatenow','/images/nav/menu2-c-02-off.gif','involvedMenu'); "><img name="donatenow" src='/images/nav/menu2-c-02-off.gif' width="104" height="15" alt="Donate Now" border="0" /></a></div>
	<div><a href="http://store.autismspeaks.org/" target="_blank" onmouseover="changeImages('onlinestore','/images/nav/menu2-c-03-on.gif','involvedMenu'); " onmouseout="changeImages('onlinestore','/images/nav/menu2-c-03-off.gif','involvedMenu'); "><img name="onlinestore" src='/images/nav/menu2-c-03-off.gif' width="104" height="15" alt="Online Store" border="0" /></a></div>
	<div><a href="http://events.autismspeaks.org/tributes" target="_blank" onmouseover="changeImages('tributes','/images/nav/menu2-c-04-on.gif','involvedMenu'); " onmouseout="changeImages('tributes','/images/nav/menu2-c-04-off.gif','involvedMenu'); "><img name="tributes" src='/images/nav/menu2-c-04-off.gif' width="104" height="16" alt="Tributes" border="0" /></a></div>
	<div><a href="/sponsoredevents/index.php" onmouseover="changeImages('sponsoredevents','/images/nav/menu2-c-05-on.gif','involvedMenu'); " onmouseout="changeImages('sponsoredevents','/images/nav/menu2-c-05-off.gif','involvedMenu'); "><img name="sponsoredevents" src='/images/nav/menu2-c-05-off.gif' width="104" height="16" alt="Our Events" border="0" /></a></div>
	<div><a href="http://events.autismspeaks.org/calendar" onmouseover="changeImages('calendar','/images/nav/menu2-c-06-on.gif','involvedMenu'); " onmouseout="changeImages('calendar','/images/nav/menu2-c-06-off.gif','involvedMenu'); "><img name="calendar" src='/images/nav/menu2-c-06-off.gif' width="104" height="16" alt="Calendar" border="0" /></a></div>
	<div><a href="/government_affairs/index.php" onmouseover="changeImages('supportlegislation','/images/nav/menu2-c-07-on.gif','involvedMenu'); " onmouseout="changeImages('supportlegislation','/images/nav/menu2-c-07-off.gif','involvedMenu'); "><img name="supportlegislation" src='/images/nav/menu2-c-07-off.gif' width="104" height="16" alt="Government Relations" border="0" /></a></div>
	<div><a href="/corporate_partners/index.php" onmouseover="changeImages('partners','/images/nav/menu2-c-08-on.gif','involvedMenu'); " onmouseout="changeImages('partners','/images/nav/menu2-c-08-off.gif','involvedMenu'); "><img name="partners" src='/images/nav/menu2-c-08-off.gif' width="104" height="20" alt="Corporate Partners" border="0" /></a></div>
</div>

<div id="communityMenu" onmouseover="setMenuOver('community');" onmouseout="setMenuOver(null); outMenu('community');">
	<div><a href="/community/family_services/index.php" onmouseover="changeImages('familyservices','/images/nav/menu2-e-01-on.gif','communityMenu'); " onmouseout="changeImages('familyservices','/images/nav/menu2-e-01-off.gif','communityMenu'); "><img name="familyservices" src='/images/nav/menu2-e-01-off.gif' width="97" height="21" alt="Family Services" border="0" /></a></div>
	<div><a href="/community/resources/index.php" onmouseover="changeImages('resources','/images/nav/menu2-e-02-on.gif','communityMenu'); " onmouseout="changeImages('resources','/images/nav/menu2-e-02-off.gif','communityMenu'); "><img name="resources" src='/images/nav/menu2-e-02-off.gif' width="97" height="16" alt="Resources" border="0" /></a></div>
	<div><a href="/community/outreach/index.php" onmouseover="changeImages('outreach','/images/nav/menu2-e-03-on.gif','communityMenu'); " onmouseout="changeImages('outreach','/images/nav/menu2-e-03-off.gif','communityMenu'); "><img name="outreach" src='/images/nav/menu2-e-03-off.gif' width="97" height="16" alt="Outreach" border="0" /></a></div>
	<div><a href="/community/chapters/index.php" onmouseover="changeImages('chapters','/images/nav/menu2-e-04-on.gif','communityMenu'); " onmouseout="changeImages('chapters','/images/nav/menu2-e-04-off.gif','communityMenu'); "><img name="chapters" src='/images/nav/menu2-e-04-off.gif' width="97" height="16" alt="Chapters" border="0" /></a></div>	
	<div><a href="/studentclubs" onmouseover="changeImages('studentclubs','/images/nav/student-clubs-on.gif','communityMenu'); " onmouseout="changeImages('studentclubs','/images/nav/student-clubs-off.gif','communityMenu'); "><img name="studentclubs" src='/images/nav/student-clubs-off.gif' width="97" height="16" alt="Student Clubs" border="0" /></a></div>
	<div><a href="/community/family_services/grants.php" onmouseover="changeImages('community_grants','/images/nav/menu2-e-05-on.gif','communityMenu'); " onmouseout="changeImages('community_grants','/images/nav/menu2-e-05-off.gif','communityMenu'); "><img name="community_grants" src='/images/nav/menu2-e-05-off.gif' width="97" height="16" alt="Community Grants" border="0" /></a></div>
	<div><a href="/community/forums/splash.php" onmouseover="changeImages('forums','/images/nav/menu2-e-06-on.gif','communityMenu'); " onmouseout="changeImages('forums','/images/nav/menu2-e-06-off.gif','communityMenu'); "><img name="forums" src='/images/nav/menu2-e-06-off.gif' width="97" height="16" alt="Social Networks" border="0" /></a></div>
	<div><a href="/community/conferences/index.php" onmouseover="changeImages('conferences','/images/nav/menu2-e-07-on.gif','communityMenu'); " onmouseout="changeImages('conferences','/images/nav/menu2-e-07-off.gif','communityMenu'); "><img name="conferences" src='/images/nav/menu2-e-07-off.gif' width="97" height="20" alt="Conferences" border="0" /></a></div>
</div>

<div id="scienceMenu" onmouseover="setMenuOver('science');" onmouseout="setMenuOver(null); outMenu('science');">
	<div><a href="/science/overview.php" onmouseover="changeImages('gn_mission','/images/nav/menu2-f-01-on.gif','scienceMenu'); " onmouseout="changeImages('gn_mission','/images/nav/menu2-f-01-off.gif','scienceMenu'); "><img name="gn_mission" src='/images/nav/menu2-f-01-off.gif' width="107" height="21" alt="Overview" border="0" /></a></div>
	<div><a href="/science/science_news/index.php" onmouseover="changeImages('gn_science_news','/images/nav/menu2-f-02-on.gif','scienceMenu'); " onmouseout="changeImages('gn_science_news','/images/nav/menu2-f-02-off.gif','scienceMenu'); "><img name="gn_science_news" src='/images/nav/menu2-f-02-off.gif' width="107" height="16" alt="Science News" border="0" /></a></div>
	<div><a href="/science/research/portfolios/index.php" onmouseover="changeImages('gn_portfolios','/images/nav/menu2-f-03-on.gif','scienceMenu'); " onmouseout="changeImages('gn_portfolios','/images/nav/menu2-f-03-off.gif','scienceMenu'); "><img name="gn_portfolios" src='/images/nav/menu2-f-03-off.gif' width="107" height="16" alt="Portfolios" border="0" /></a></div>
	<div><a href="/science/programs/index.php" onmouseover="changeImages('gn_research','/images/nav/menu2-f-04-on.gif','scienceMenu'); " onmouseout="changeImages('gn_research','/images/nav/menu2-f-04-off.gif','scienceMenu'); "><img name="gn_research" src='/images/nav/menu2-f-04-off.gif' width="107" height="16" alt="Clinical Programs" border="0" /></a></div>
	<div><a href="/science/research/initiatives/index.php" onmouseover="changeImages('gn_initiatives','/images/nav/menu2-f-05-on.gif','scienceMenu'); " onmouseout="changeImages('gn_initiatives','/images/nav/menu2-f-05-off.gif','scienceMenu'); "><img name="gn_initiatives" src='/images/nav/menu2-f-05-off.gif' width="107" height="16" alt="Initiatives" border="0" /></a></div>	
	<div><a href="/science/scientificmeetings/index.php" onmouseover="changeImages('gn_meetings','/images/nav/menu2-f-06-on.gif','scienceMenu'); " onmouseout="changeImages('gn_meetings','/images/nav/menu2-f-06-off.gif','scienceMenu'); "><img name="gn_meetings" src='/images/nav/menu2-f-06-off.gif' width="107" height="15" alt="Scientific Meetings" border="0" /></a></div>
    	<div><a href="/science/research/grants/index.php" onmouseover="changeImages('gn_grants_program','/images/nav/menu2-f-07-on.gif','scienceMenu'); " onmouseout="changeImages('gn_grants_program','/images/nav/menu2-f-07-off.gif','scienceMenu'); "><img name="gn_grants_program" src='/images/nav/menu2-f-07-off.gif' width="107" height="20" alt="Grants" border="0" /></a></div>
	
</div>

<a name="content" style="display:none;">&nbsp;</a></div>
<div id="layer1" style="position:absolute; left:31px; top:0px; width:79px; height:153px; z-index:99;">
<a href="/index.php"><img name="image5981127" src="/images/templates/d_200704_logo-interior.gif"  width="79" height="153" alt="" border="0" /></a>
</div>
<div id="layer13" style="position:absolute; left:765px; top:0px; width:15px; height:1358px; z-index:11; background-color:#F8F8D9; layer-background-color:#F8F8D9;">
</div>
<div id="layer17" style="position:absolute; left:0px; top:0px; width:25px; height:10px; z-index:19;">
<a name="top"></a>
</div>
<div id="layer3" style="position:absolute; left:240px; top:30px; width:500px; height:50px; z-index:98;">
<img name="image5981125" src="/images/be_informed/d_200506_b2-need-to-know.gif"   width="500" height="50" alt="" border="0" />
</div>
<div id="layer8" style="position:absolute; left:735px; top:30px; width:45px; height:270px; z-index:10;">
<img name="image5981121" src="/images/templates/d_200507_curve-1-top.gif"   width="45" height="270" alt="" border="0" />
</div>
<div id="layer11" style="position:absolute; left:240px; top:80px; width:499px; height:40px; z-index:13;">
<!-- CMS PAGE ID: 6205 -->
<!-- MODULE NAME: bi_whatisit_sub_nav -->
<!-- CREATED BY module_root.jsp -->
<div id="layer9"  style="position:absolute; left:300px; top:20px; width:100px; height:20px; z-index:11; background-color:transparent; layer-background-color:transparent;overflow:visible;">
<a href="/video/glossary.php" onmouseover="changeImages('subsection6','/images/modules/d_200507_nav2-2-1-1-on.gif','layer11');" onmouseout="changeImages('subsection6','/images/modules/d_200507_nav2-2-1-1-off.gif','layer11');"><img name="subsection6" src="/images/modules/d_200507_nav2-2-1-1-off.gif" onload="loadImages('/images/modules/d_200507_nav2-2-1-1-off.gif','/images/modules/d_200507_nav2-2-1-1-on.gif');"  width="100" height="20" alt="Video Glossary" border="0" /></a>
</div>
<div id="layer0"  style="position:absolute; left:0px; top:20px; width:100px; height:20px; z-index:2; background-color:transparent; layer-background-color:transparent;overflow:visible;">
<a href="/whatisit/index.php" onmouseover="changeImages('subsection1','/images/modules/d_200507_nav2-2-1-5-on.gif','layer11');" onmouseout="changeImages('subsection1','/images/modules/d_200507_nav2-2-1-5-off.gif','layer11');"><img name="subsection1" src="/images/modules/d_200507_nav2-2-1-5-off.gif" onload="loadImages('/images/modules/d_200507_nav2-2-1-5-off.gif','/images/modules/d_200507_nav2-2-1-5-on.gif');"  width="100" height="20" alt="About Autism" border="0" /></a>
</div>
<div id="layer1"  style="position:absolute; left:200px; top:20px; width:100px; height:20px; z-index:3; background-color:transparent; layer-background-color:transparent;overflow:visible;">
<a href="/whatisit/learnsigns.php" ><img name="subsection4" src="/images/modules/d_200507_nav2-2-1-8-on.gif" onload="loadImages('/images/modules/d_200507_nav2-2-1-8-off.gif','/images/modules/d_200507_nav2-2-1-8-on.gif');"  width="100" height="20" alt="Learn the Signs" border="0" /></a>
</div>
<div id="layer2"  style="position:absolute; left:100px; top:20px; width:100px; height:20px; z-index:4; background-color:transparent; layer-background-color:transparent;overflow:visible;">
<a href="/whatisit/symptoms.php" onmouseover="changeImages('subsection2','/images/modules/d_200904_symptoms_on.gif','layer11');" onmouseout="changeImages('subsection2','/images/modules/d_200904_symptoms_off.gif','layer11');"><img name="subsection2" src="/images/modules/d_200904_symptoms_off.gif" onload="loadImages('/images/modules/d_200904_symptoms_off.gif','/images/modules/d_200904_symptoms_on.gif');"  width="100" height="20" alt="Facts" border="0" /></a>
</div>
<div id="layer7"  style="position:absolute; left:400px; top:20px; width:100px; height:20px; z-index:9; background-color:transparent; layer-background-color:transparent;overflow:visible;">
<a href="/resources.php" onmouseover="changeImages('subsection8','/images/modules/d_200507_nav2-2-1-3-on.gif','layer11');" onmouseout="changeImages('subsection8','/images/modules/d_200507_nav2-2-1-3-off.gif','layer11');"><img name="subsection8" src="/images/modules/d_200507_nav2-2-1-3-off.gif" onload="loadImages('/images/modules/d_200507_nav2-2-1-3-off.gif','/images/modules/d_200507_nav2-2-1-3-on.gif');"  width="100" height="20" alt="Resources" border="0" /></a>
</div>
<div id="layer1248804626124"  style="position:absolute; left:1px; top:0px; width:100px; height:20px; z-index:2; background-color:transparent; layer-background-color:transparent;overflow:visible;">
<a href="/whatisit/faq.php" onmouseover="changeImages('subsection6','/images/modules/d_200507_nav2-2-1-7-on.gif','layer11');" onmouseout="changeImages('subsection6','/images/modules/d_200507_nav2-2-1-7-off.gif','layer11');"><img name="subsection6" src="/images/modules/d_200507_nav2-2-1-7-off.gif" onload="loadImages('/images/modules/d_200507_nav2-2-1-7-off.gif','/images/modules/d_200507_nav2-2-1-7-on.gif');"  width="100" height="20" alt="FAQ" border="0" /></a>
</div>
<div id="layer1248804710904"  style="position:absolute; left:100px; top:0px; width:100px; height:20px; z-index:2; background-color:transparent; layer-background-color:transparent;overflow:visible;">
<a href="/whatisit/facts.php" onmouseover="changeImages('subsection7','/images/modules/d_200507_nav2-2-1-6-on.gif','layer11');" onmouseout="changeImages('subsection7','/images/modules/d_200507_nav2-2-1-6-off.gif','layer11');"><img name="subsection7" src="/images/modules/d_200507_nav2-2-1-6-off.gif" onload="loadImages('/images/modules/d_200507_nav2-2-1-6-off.gif','/images/modules/d_200507_nav2-2-1-6-on.gif');"  width="100" height="20" alt="Facts" border="0" /></a>
</div>
</div>
<div id="layer4" style="position:absolute; left:240px; top:120px; width:540px; height:40px; z-index:98;">
<img name="image5981124" src="/images/be_informed/d_200506_nav-2-1-line.gif"   width="540" height="40" alt="" border="0" />
</div>
<div id="layer2" style="position:absolute; left:0px; top:160px; width:210px; height:190px; z-index:99;">
<!-- CMS PAGE ID: 6280 -->
<!-- MODULE NAME: be_informed_local_nav -->
<!-- CREATED BY module_root.jsp -->
<div id="layer0"  style="position:absolute; left:0px; top:0px; width:210px; height:40px; z-index:2; background-color:transparent; layer-background-color:transparent;overflow:visible;">
<a href="/whatisit/index.php" ><img name="section1" src="/images/modules/d_200704_nav2-2-1-on.gif" onload="loadImages('/images/modules/d_200704_nav2-2-1-off.gif','/images/modules/d_200704_nav2-2-1-on.gif');"  width="210" height="40" alt="What is Autism" border="0" /></a>
</div>
<div id="layer1"  style="position:absolute; left:0px; top:40px; width:210px; height:40px; z-index:3; background-color:transparent; layer-background-color:transparent;overflow:visible;">
<a href="/diagnosis/index.php" onmouseover="changeImages('section2','/images/modules/d_200905_diagnosis_on.gif','layer2');" onmouseout="changeImages('section2','/images/modules/d_200905_diagnosis_off.gif','layer2');"><img name="section2" src="/images/modules/d_200905_diagnosis_off.gif" onload="loadImages('/images/modules/d_200905_diagnosis_off.gif','/images/modules/d_200905_diagnosis_on.gif');"  width="210" height="40" alt="Diagnosis" border="0" /></a>
</div>
<div id="layer2"  style="position:absolute; left:0px; top:80px; width:210px; height:40px; z-index:4; background-color:transparent; layer-background-color:transparent;overflow:visible;">
<a href="/treatment/index.php" onmouseover="changeImages('section3','/images/modules/d_200908_treatment_on.gif','layer2');" onmouseout="changeImages('section3','/images/modules/d_200908_treatment_off.gif','layer2');"><img name="section3" src="/images/modules/d_200908_treatment_off.gif" onload="loadImages('/images/modules/d_200908_treatment_off.gif','/images/modules/d_200908_treatment_on.gif');"  width="210" height="40" alt="Treatment" border="0" /></a>
</div>
<div id="layer3"  style="position:absolute; left:0px; top:120px; width:210px; height:40px; z-index:5; background-color:transparent; layer-background-color:transparent;overflow:visible;">
<a href="/rights/index.php" onmouseover="changeImages('section4','/images/modules/d_200905_your_childs_rights_on.gif','layer2');" onmouseout="changeImages('section4','/images/modules/d_200905_your_childs_rights_off.gif','layer2');"><img name="section4" src="/images/modules/d_200905_your_childs_rights_off.gif" onload="loadImages('/images/modules/d_200905_your_childs_rights_off.gif','/images/modules/d_200905_your_childs_rights_on.gif');"  width="210" height="40" alt="Your Child's Rights" border="0" /></a>
</div>
<div id="layer4"  style="position:absolute; left:0px; top:160px; width:210px; height:40px; z-index:6; background-color:transparent; layer-background-color:transparent;overflow:visible;">
<a href="/family/index.php" onmouseover="changeImages('section5','/images/modules/d_200905_your_family_and_autism_on.gif','layer2');" onmouseout="changeImages('section5','/images/modules/d_200905_your_family_and_autism_off.gif','layer2');"><img name="section5" src="/images/modules/d_200905_your_family_and_autism_off.gif" onload="loadImages('/images/modules/d_200905_your_family_and_autism_off.gif','/images/modules/d_200905_your_family_and_autism_on.gif');"  width="210" height="40" alt="Your Family and Autism" border="0" /></a>
</div>
</div>
<div id="layer16" style="position:absolute; left:240px; top:165px; width:297px; height:36px; z-index:18;">
<span class="headline-orange">
Learn the Signs of Autism<br />
</span><a class="bodycopy-orange" href="/espanol/los_signos.php"><strong>En Espa&#241;ol</strong></a>
</div>
<div id="layer29" style="position:absolute; left:240px; top:218px; width:387px; height:230px; z-index:31;">
<img name="image5981102" src="/images/whatisit/d_200904_ernie_els_and_ben.jpg"   width="387" height="230" alt="Early Intervention can make a lifetime of difference" border="0" />
</div>
<div id="layer9" style="position:absolute; left:635px; top:260px; width:97px; height:215px; z-index:98;">
<!-- CMS PAGE ID: 2428 -->
<!-- MODULE NAME: bi_whatisit_puzzle_nav -->
<!-- CREATED BY module_root.jsp -->
<div id="layer0"  style="position:absolute; left:20px; top:130px; width:70px; height:67px; z-index:2; background-color:transparent; layer-background-color:transparent;overflow:null;">
<a href="http://store.autismspeaks.org/" target="_blank" onmouseover="changeImages('puzzlesection3','/images/modules/d_200704_puzzle-2-3-on.gif','layer9');" onmouseout="changeImages('puzzlesection3','/images/modules/d_200704_puzzle-2-1-3-off.gif','layer9');"><img name="puzzlesection3" src="/images/modules/d_200704_puzzle-2-1-3-off.gif" onload="loadImages('/images/modules/d_200704_puzzle-2-1-3-off.gif','/images/modules/d_200704_puzzle-2-3-on.gif');"  width="70" height="67" alt="Online Store" border="0" /></a>
</div>
<div id="layer1"  style="position:absolute; left:20px; top:65px; width:70px; height:70px; z-index:3; background-color:transparent; layer-background-color:transparent;overflow:visible;">
<a href="https://secure.autismspeaks.org/page/contribute/donate1?utm_source=internal_link&utm_medium=web&utm_campaign=puzzle_piece" onmouseover="changeImages('puzzlesection2','/images/modules/d_200704_puzzle-2-2-on.gif','layer9');" onmouseout="changeImages('puzzlesection2','/images/modules/d_200704_puzzle-2-1-2-off.gif','layer9');"><img name="puzzlesection2" src="/images/modules/d_200704_puzzle-2-1-2-off.gif" onload="loadImages('/images/modules/d_200704_puzzle-2-1-2-off.gif','/images/modules/d_200704_puzzle-2-2-on.gif');"  width="70" height="70" alt="Donate" border="0" /></a>
</div>
<div id="layer2"  style="position:absolute; left:20px; top:0px; width:70px; height:70px; z-index:4; background-color:transparent; layer-background-color:transparent;overflow:visible;">
<a href="http://www.autismspeaks.org/video/glossary.php?utm_source=internal_link&utm_medium=web&utm_campaign=puzzle_piece" onmouseover="changeImages('puzzlesection1','/images/modules/d_200704_puzzle-2-1-on.gif','layer9');" onmouseout="changeImages('puzzlesection1','/images/modules/d_200704_puzzle-2-1-1-off.gif','layer9');"><img name="puzzlesection1" src="/images/modules/d_200704_puzzle-2-1-1-off.gif" onload="loadImages('/images/modules/d_200704_puzzle-2-1-1-off.gif','/images/modules/d_200704_puzzle-2-1-on.gif');"  width="70" height="70" alt="Video Glossary" border="0" /></a>
</div>
</div>
<div id="layer14" style="position:absolute; left:0px; top:370px; width:218px; height:175px; z-index:16;">
<!-- CMS PAGE ID: 307 -->
<!-- MODULE NAME: flash_6_bobby -->
<!-- CREATED BY module_root.jsp -->
<div id="layer0"  style="position:absolute; left:0px; top:0px; width:218px; height:175px; z-index:2; background-color:transparent; layer-background-color:transparent;">
<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://active.macromedia.com/flash/cabs/swflash.cab" id=flash62174 width=100% height=175>
<param name=movie value="/flash/d_200509_flash-6-bobby.swf">
<param name=quality value=high>
<param name=wmode value=transparent>
<embed src="/flash/d_200509_flash-6-bobby.swf" width=100% height=175 quality=high wmode="transparent" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash"></embed>
</object>
</div>
</div>
<div id="layer20" style="position:absolute; left:503px; top:456px; width:125px; height:36px; z-index:20; background-color:#df772e; layer-background-color:#df772e;">
</div>
<div id="layer24" style="position:absolute; left:239px; top:456px; width:125px; height:36px; z-index:20; background-color:#df772e; layer-background-color:#df772e;">
<p />
</div>
<div id="layer19" style="position:absolute; left:371px; top:457px; width:125px; height:36px; z-index:20; background-color:#df772e; layer-background-color:#df772e;">
</div>
<div id="layer22" style="position:absolute; left:381px; top:459px; width:107px; height:26px; z-index:23;">
<a class="bodycopy-links-black-noul" href="/whatisit/milestones.php"><strong>Developmental Milestones by Age</strong></a>
</div>
<div id="layer27" style="position:absolute; left:250px; top:459px; width:93px; height:38px; z-index:29;">
<a class="bodycopy-links-black-noul" href="#redflags"><strong>Red Flags for Autism</strong></a>
</div>
<div id="layer32" style="position:absolute; left:512px; top:460px; width:112px; height:29px; z-index:34;">
<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
<script language="JavaScript">
function popup_window() {
window.open('http://autismspeaks.avasio.com/index.asp', 'popup', 'width=600, height=500, menubar=no, scrollbars=no, toolbar=no, location=no, resizable=no, top=50, left=50');
}
</script>
<body bgcolor="#ffffff">
<a class="bodycopy-links-black-noul"  href="http://autismspeaks.avasio.com/index.asp" onclick="popup_window(''); return false;"><strong>Interactive Learn the Signs Quiz</strong></a>
</div>
<div id="layer31" style="position:absolute; left:240px; top:498px; width:125px; height:36px; z-index:20; background-color:#df772e; layer-background-color:#df772e;">
<p />
</div>
<div id="layer32" style="position:absolute; left:371px; top:498px; width:125px; height:36px; z-index:20; background-color:#df772e; layer-background-color:#df772e;">
<p />
</div>
<div id="layer33" style="position:absolute; left:504px; top:498px; width:125px; height:36px; z-index:12; background-color:#df772e; layer-background-color:#df772e;">
</div>
<div id="layer35" style="position:absolute; left:512px; top:501px; width:106px; height:24px; z-index:29;">
<a class="bodycopy-links-black-noul"  href="/whatisit/ad_council_campaign.php"><strong>The Ad Campaign</strong></a>
</div>
<div id="layer38" style="position:absolute; left:250px; top:501px; width:100px; height:25px; z-index:40;">
<a class="bodycopy-links-black-noul" href="/whatisit/talking_to_parents_action_kit.php"><strong>Talking to Parents About Autism Kit</strong></a>
</div>
<div id="layer36" style="position:absolute; left:381px; top:501px; width:106px; height:24px; z-index:35;">
<a class="bodycopy-links-black-noul" href="mailto:familyservices@autismspeaks.org?subject=Learn the Signs"><strong>Email Us Your Thoughts</strong></a>
</div>
<div id="layer7" style="position:absolute; left:312px; top:552px; width:316px; height:71px; z-index:9;">
<span class="bodycopy">
Autism Speaks' multi-year Ad Council public service advertising campaign stresses the importance of recognizing the early signs of autism and seeking early intervention services.
</span>
</div>
<div id="layer30" style="position:absolute; left:240px; top:553px; width:60px; height:59px; z-index:32;">
<a href="http://www.adcouncil.org  " target="_blank"><img name="image5981101" src="/images/whatisit/d_200604_Ad_Council_logo_sm.jpg"  width="60" height="59" alt="" border="0" /></a>
</div>
<div id="layer31" style="position:absolute; left:240px; top:630px; width:387px; height:775px; z-index:9;">
<span class="bodycopy">
Research now suggests that children as young as 1 year old can show signs of autism. The most important thing you can do as a parent or caregiver is to learn the early signs of autism and understand the typical developmental milestones your child should be reaching at different ages. Please look over the following list. If you have any concerns about your child's development, <em>don't wait</em>. Speak to your doctor about screening your child for autism. While validated screening for autism starts only as young as 16 months, the best bet for younger children is to have their development screened at every well visit with a highly validated developmental screening tool. If your child <em>does</em> have autism, early intervention may be his or her best hope. <br /><br /><strong><span class="bodycopy-orange">
<strong>Watch for the <a name="redflags">Red Flags</a> of Autism<br /></strong><br /><em><strong>(The following red flags may indicate a child is at risk for atypical development, and is in need of an immediate evaluation.)</strong></em>
</span></strong><br /><br />In clinical terms, there are a few &#8220;absolute indicators,&#8221; often referred to as &#8220;red flags,&#8221; that indicate that a child should be evaluated. For a parent, these are the &#8220;red flags&#8221; that your child should be screened to ensure that he/she is on the right developmental path<strong>.<em> If your baby shows any of these signs, please ask your pediatrician or family practitioner for an immediate evaluation:</em></strong> <br /><br /><ul><li>No big smiles or other warm, joyful expressions by six months or thereafter</li></ul><ul><li>No back-and-forth sharing of sounds, smiles, or other facial expressions by nine months or thereafter</li></ul><ul><li>No babbling by 12 months</li></ul><ul><li>No back-and-forth gestures, such as pointing, showing, reaching, or waving by 12 months</li></ul><ul><li>No words by 16 months</li></ul><ul><li>No two-word meaningful phrases (without imitating or repeating) by 24 months</li></ul><ul><li>Any loss of speech or babbling or social skills at any age</li></ul>*This information has been provided by <em>First Signs</em>, Inc. &#169;2001-2005. Reprinted with permission. For more information about recognizing the early signs of developmental and behavioral disorders, please visit <a class="bodycopy-links-orange" href="http://www.firstsigns.org">http://www.firstsigns.org</a> or the Centers for Disease Control at <a class="bodycopy-links-orange" href="http://www.cdc.gov/actearly" target="_blank">www.cdc.gov/actearly</a>.<br /><br />
</span>
</div>
<div id="footer" style="position:absolute; left:735px; top:1271px; width:45px; height:270px; z-index:2;">
<img name="image5981123" src="/images/templates/d_200507_curve-1-bottom.gif"   width="45" height="270" alt="" border="0" />
</div>
<div id="layer15" style="position:absolute; left:568px; top:1467px; width:59px; height:15px; z-index:17;">
<span class="bodycopy">
back to <a class="bodycopy-links-orange" href="#top">top</a>
</span>
</div>
<div id="globalfooter">
<!-- CMS PAGE ID: 7103 -->
<!-- MODULE NAME: global_footer -->
<!-- CREATED BY module_root.jsp -->
<table cellpadding="0" cellspacing="0" border="0"  width="100%" height="75px" >
<tr >
<td width="15px" bgcolor="#567eb9" align="left" valign="top" rowspan="3"></td>
<td bgcolor="#567eb9" align="left" valign="top" rowspan="3">
<img name="image6198702" src="/images/modules/d_201002_5-year-logo.png"   width="70" height="70" alt="Autism Speaks 5th Anniversary" border="0" />
</td>
<td width="200px" bgcolor="#567eb9" align="right" valign="middle" rowspan="3"></td>
<td bgcolor="#567eb9" align="left" valign="top" colspan="3">
</td>
<td width="20px" bgcolor="#567eb9" align="right" valign="top">
<a href="http://www.autismspeaks.ca" target="_blank"><img name="image6198708" src="/images/modules/d_200508_canada.gif"  width="16" height="16" alt="Canada" border="0" /></a>
</td>
<td class="padding-top-2" width="60px" height="16px" bgcolor="#567eb9" align="center" valign="top"><span class="homepage-footer">
<a class="homepage-footer" href="http://www.autismspeaks.ca" target="_blank">Canada</a>
</span></td>
<td class="padding-top-2" width="20px" bgcolor="#567eb9" align="left" valign="top">
<img name="image6198712" src="/images/modules/d_200811_footer-spacerCAENQDCF.gif"   width="20" height="16" alt="" border="0" />
</td>
<td width="20px" bgcolor="#567eb9" align="left" valign="top">
<a href="http://www.shafallah.org.qa/" target="_blank"><img name="image6198714" src="/images/modules/d_200811_qatar.gif"  width="16" height="16" alt="Middle East" border="0" /></a>
</td>
<td class="padding-top-2" width="80px" bgcolor="#567eb9" align="center" valign="top"><span class="homepage-footer">
<a class="homepage-footer" href="http://www.shafallah.org.qa/" target="_blank">Middle East</a>
</span></td>
<td class="padding-top-2" width="20px" bgcolor="#567eb9" align="left" valign="top">
<img name="image6198718" src="/images/modules/d_200811_footer-spacerCAENQDCF.gif"   width="20" height="16" alt="" border="0" />
</td>
<td class="padding-top-2" width="70px" height="16px" bgcolor="#567eb9" align="center" valign="top"><span class="homepage-footer">
<a class="homepage-footer" href="/espanol/informacion_en_espanol.php">En Espa&#241;ol</a>
</span></td>
<td bgcolor="#567eb9" align="left" valign="top">
<img name="image6198722" src="/images/modules/d_200811_footer-spacerCAENQDCF.gif"   width="20" height="16" alt="" border="0" />
</td>
<td class="padding-top-2" width="44px" height="16px" bgcolor="#567eb9" align="center" valign="top"><span class="homepage-footer">
<a class="homepage-footer" href="/info/privacy.php">Privacy</a>
</span></td>
<td class="padding-top-2" width="20px" height="16px" bgcolor="#567eb9" align="left" valign="top">
<img name="image6198726" src="/images/modules/d_200811_footer-spacerCAENQDCF.gif"   width="20" height="16" alt="" border="0" />
</td>
<td class="padding-top-2" width="120px" height="16px" bgcolor="#567eb9" align="center" valign="top"><span class="homepage-footer">
<a class="homepage-footer" href="/info/terms.php">Terms of Service</a>
</span></td>
<td class="padding-top-2" width="20px" height="16px" bgcolor="#567eb9" align="left" valign="top">
<img name="image6198730" src="/images/modules/d_200811_footer-spacerCAENQDCF.gif"   width="20" height="16" alt="" border="0" />
</td>
<td class="padding-top-2" width="65px" height="16px" bgcolor="#567eb9" align="center" valign="top"><span class="homepage-footer">
<a class="homepage-footer" href="/contact/index.php">Contact Us</a>
</span></td>
</tr>
<tr >
<td bgcolor="#567eb9" align="left" valign="top"></td>
<td height="10px" bgcolor="#567eb9" align="left" valign="top" colspan="1"></td>
<td bgcolor="#567eb9" align="left" valign="top"></td>
<td bgcolor="#567eb9" align="left" valign="top"></td>
<td height="10px" bgcolor="#567eb9" align="left" valign="top" colspan="1"></td>
<td bgcolor="#567eb9" align="left" valign="top"></td>
<td bgcolor="#567eb9" align="left" valign="top"></td>
<td bgcolor="#567eb9" align="left" valign="top"></td>
<td bgcolor="#567eb9" align="left" valign="top"></td>
<td bgcolor="#567eb9" align="left" valign="top"></td>
<td bgcolor="#567eb9" align="left" valign="top"></td>
<td bgcolor="#567eb9" align="left" valign="top"></td>
<td bgcolor="#567eb9" align="left" valign="top"></td>
<td bgcolor="#567eb9" align="left" valign="top"></td>
<td bgcolor="#567eb9" align="left" valign="top"></td>
<td bgcolor="#567eb9" align="left" valign="top"></td>
</tr>
<tr >
<td bgcolor="#567eb9" align="right" valign="top" colspan="16"><span class="homepage-footer">
&#169; 2005 - 2010 Autism Speaks Inc.<br />Autism Speaks and Autism Speaks It's Time To Listen &amp; Design<br />are trademarks owned by Autism Speaks Inc. All rights reserved.
</span><p><span class="homepage-footer">
</span></p></td>
</tr>
</table>
</div>

				<div id="searchbox">
				<form action="/search/index.php" method="post">
				<table cellpadding="0" cellspacing="0"><tr><td><label class="hidden" for="search">search</label><input class="search_interior" type="text" name="q"></td><td><input name="search" type="image" src="/images/button_search_B.gif" alt="Search" /></td></tr></table>
				</form>
			</div>
			








<div id="newsletter_signup">

<div align="right" width:528px; height:20px; margin-left:auto; margin-right:auto;"><form id="join-us" class="header-form" target="_top" method="post" action="http://action.autismspeaks.org/page/s/splashsignup">
<table cellpadding="0" cellspacing="0" border="0"><tr><td valign="top"><img src="/images/espeaks_signup.gif" /></td>
               <td cellpadding="10" valign="top">
               <input type="text" name="email" id="lightbox-email" class="lightbox-email" value="Email" style=" border:1px solid #df772e; width:90px;" />
				<input type="text" name="zip" id="lightbox-zip" class="lightbox-zip" value="Zip Code" style=" border:1px solid #df772e; width:76px;	" />
				</td>
                <td valign="top"><input type="image" src="/images/asmainsubmit1.gif" class="lightbox-button"/></td></tr>
                </table></form></div>



</div>


<!-- START Nielsen Online SiteCensus V5.3 Compact -->
<!-- COPYRIGHT 2009 Nielsen Online -->
<script type="text/javascript">
	var _rsCI="us-ade";
	var _rsCG="12096AUT";
	var _rsIMG=new Image(1,1);
	_rsIMG.src="//secure-us.imrworldwide.com/cgi-bin/m?rn="+(new Date()).getTime()+"&ci="+_rsCI+"&cg="+_rsCG+"&si="+escape(window.location.href)+"&rp="+escape(document.referrer) + "&cc=1";
</script>
<noscript>
	<div><img src="//secure-us.imrworldwide.com/cgi-bin/m?ci=us-ade&amp;cg=12096&amp;cc=1" alt=""/></div>
</noscript>
<!-- END Nielsen Online SiteCensus V5.3 Compact -->



<!-- Start Quantcast tag -->
<script type="text/javascript">
_qoptions={
qacct:"p-a5PYzfpky1Prc"
};
</script>
<script type="text/javascript" src="http://edge.quantserve.com/quant.js"></script>
<noscript>
<img src="http://pixel.quantserve.com/pixel/p-a5PYzfpky1Prc.gif" style="display: none;" border="0" height="1" width="1" alt="Quantcast"/>
</noscript>
<!-- End Quantcast tag -->

<!--- start of Fetchback pixel tag --->
<iframe src='http://pixel.fetchback.com/serve/fb/pdc?cat=&name=landing&sid=3042' scrolling='no' width='1' height='1' marginheight='0' marginwidth='0' frameborder='0'></iframe> 
<!--- end of Fetchback pixel tag --->

 




</div>
</body>
</html>
