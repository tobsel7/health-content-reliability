<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html dir="ltr">
<head>
<base href="http://brokencontrollers.com/">
<meta name="description" content="This page provides information about 'Autism Symptoms - Look for the Warning Signs of Autism | Th' on Broken Controllers.">
<meta name="keywords" content="Autism Symptoms - Look for the Warning Signs of Autism | Th">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="Content-Style-Type" content="text/css">

<title>Autism Symptoms - Look for the Warning Signs of Autism | Th | BrokenControllers.com</title>

<link rel="stylesheet" href="templates/iCGstation/iCGstation.css" type="text/css" -->

<!-- start mod : Resize Posted Images Based on Max Width -->
<script type="text/javascript">
//<![CDATA[
<!--

var rmw_max_width = 500; // you can change this number, this is the max width in pixels for posted images
var rmw_border_1 = '3px solid #006699';
var rmw_border_2 = '3px solid #006699';
var rmw_image_title = 'Click To View Full Size';

//-->
//]]>
</script>
<script type="text/javascript" src="./templates/rmw_jslib.js"></script>
<!-- fin mod : Resize Posted Images Based on Max Width -->

<link rel="alternate" title="Broken Controllers Topic RSS Feed" href="rss.php?t=8899082" type="application/rss+xml">

<link rel="Shortcut Icon" href="/images/favicon.ico">

<link rel="stylesheet" type="text/css" href="templates/iCGstation/report_hack.css" />

<!-- Prillian - Begin Code Additions -->
<!-- Prillian - End Code Additions -->

<script type="text/javascript" src="http://brokencontrollers.com/forums/ajaxsearch/ajax_framework.js"></script>

<style type="text/css">
#results{width:300px; border:solid 1px #C5C5C5; display:none;}
#results ul, #results li{padding:0; margin:0; border:0; list-style:none;}
#results li {border-top:solid 1px #C5C5C5;}
#results li a{display:block; padding:4px; text-decoration:none; color:#000000; font-weight:bold;}
#results li a small{display:block; text-decoration:none; color:#999999; font-weight:normal;}
#results li a:hover{background:#FFFFCC;}
#results ul {padding:6px;}
#results2{width:300px; border:solid 1px #C5C5C5; display:none;}
#results2 ul, #results2 li{padding:0; margin:0; border:0; list-style:none;}
#results2 li {border-top:solid 1px #C5C5C5;}
#results2 li a{display:block; padding:4px; text-decoration:none; color:#445588; font-weight:bold;}
#results2 li a small{display:block; text-decoration:none; color:#999999; font-weight:normal;}
#results2 li a:hover{background:#FFFFCC;}
#results2 ul {padding:6px;}
</style>

<script type="text/javascript">

var zcFeedConfig = {

        param          : '2e4f726e348291029aac758805b9417ce37f402000bf9fe33905d37c00f726a6ef1859706adc3f18e03661c9614388191faf976e7c3dc8ea8a9296445a8dc404bdfeb2dfeb6c74640f4567bace75a1055b6155cff262b023a9:d35d00265e247c6a7980e426e257c19f',

        paramContent: '06be454b7b6ecb04073737911a7e9ab1e767ce9ec6afe030e89a55529d648530b99041b632fc40b6b98a466ea28aee691dcc85b475342a7427e57d6ca553df8c876dedfca494f4c28a86e1ed2fa9332b8debc269769b37ced85d:66ce22f8efea1c7638a374d039ba94f0'

}

</script>

<script type="text/javascript" src="http://static.pinballpublishernetwork.com/js/release/gpl_lp.js"></script>

</head>
<body>

<a name="top"></a>


<table width="100%" cellpadding="0" cellspacing="0" border="0" align="center">

  <tr>

	<td width="10" nowrap="nowrap" class="lefttd"></td>

	<td>

<table border="0" cellpadding="0" cellspacing="0" class="tbl"><tr><td class="tbll"><img src="images/spacer.gif" alt="" width="0" height="0" /></td><td class="tblbot"><img src="images/spacer.gif" alt="" width="0" height="0" /></td><td class="tblr"><img src="images/spacer.gif" alt="" width="0" height="0" /></td></tr></table>

		<table width="100%" cellpadding="0" cellspacing="1" border="0" class="forumline">

	<tr>

<th width="50px"><input type="radio" checked="checked" /><input type="radio" checked="checked" /></th>

<th align="center" valign="middle" colspan="9">

<form method="get" action="viewforum.php"><table cellspacing="1" cellpadding="0" border="0">
	<tr>
		<td nowrap="nowrap"><span class="gensmall"><img src="http://brokencontrollers.com/images/jumperimg.gif">&nbsp;<select name="f" onchange="if(this.options[this.selectedIndex].value != -1){ forms['jumpbox'].submit() }"><option value="-1">Select A Message Board</option><option value="-1">&nbsp;</option><option value="-1">Special Discussions</option><option value="-1">----------------</option><option value="55">Content Database</option><option value="8">Newcomers Discussion</option><option value="67">Site Usage Support Discussion</option><option value="-1">&nbsp;</option><option value="-1">General Discussions</option><option value="-1">----------------</option><option value="73">Anime & Manga Club</option><option value="23">Arts & Graphics Club</option><option value="75">Books & Literature Club</option><option value="78">Business, Finance & Economics Club</option><option value="16">Club Message Boards</option><option value="69">Computer Hardware & Software Club</option><option value="77">Consumers Club</option><option value="63">Discover Learning Club</option><option value="80">Educational Topics Club</option><option value="62">Encyclopedia Club</option><option value="72">Fashion & Clothing Club</option><option value="61">File Downloads Club</option><option value="74">Flash Animations Club</option><option value="57">Flash Games Club</option><option value="71">Food & Drink Club</option><option value="82">Foreign Languages Club</option><option value="3">General Gaming Discussion</option><option value="83">Handy Guides Club</option><option value="64">Health & Fitness Club</option><option value="12">Multimedia Discussion</option><option value="54">Multimedia Images Club</option><option value="47">Multimedia Videos Club</option><option value="42">Music Club</option><option value="2">Off-Topic Discussion</option><option value="70">Philosophy & Ethics Club</option><option value="76">Politics Club</option><option value="28">Popular News Club</option><option value="68">Portable Devices Club</option><option value="38">Relationships Club</option><option value="25">Social Bookmarking Club</option><option value="56">Sports Club</option><option value="58">TV Shows & Movies Club</option><option value="17">Writers Workshop Club</option></select><input type="hidden" name="sid" value="d2cad8f94165669dfd06dcc63ad74754" />&nbsp;<input type="submit" value="Go" class="btn" /></span></td>
	</tr>
</table></form>


</th>

<th align="center" valign="middle" colspan="9">

<form action="http://whadu.com/results.php" method="get">&nbsp;<img src="http://brokencontrollers.com/forums/templates/iCGstation/images/icon/icon_search.gif"> <input type="text" id="searchphrase" name="q" size="35" onkeyup="javascript:if(event.keyCode !=40 && event.keyCode !=38) autosuggest(); if(event.keyCode==40) godown(); if(event.keyCode==38) goup();" autocomplete="off" />

<script>document.getElementById('searchphrase').focus()</script>

<input type="submit" value="Search"> <input value="+" class="btn" onclick="window.location.href='http://whadu.com'" type="button">&nbsp;<div align="left" id="results"></div><th width="50px"><input type="radio" checked="checked" /><input type="radio" checked="checked" /></th></form>

</th>

	</tr>

</table>

<table border="0" cellpadding="0" cellspacing="0" class="tbl"><tr><td class="tbll"><img src="images/spacer.gif" alt="" width="0" height="0" /></td><td class="tblbot"><img src="images/spacer.gif" alt="" width="0" height="0" /></td><td class="tblr"><img src="images/spacer.gif" alt="" width="0" height="0" /></td></tr></table>

<br>



<table class="forumline" width="790px" align="center" cellspacing="1">

<tbody><tr><th><center><img src="http://brokencontrollers.com/images/maxspacer2.jpg"><br>

<a href="http://www.epictoon.com/" target="_blank"><img src="http://brokencontrollers.com/images/728x90ver1.jpg"></a>

<br><img src="http://brokencontrollers.com/images/maxspacer3.jpg"></center></th></tr></tbody>

</table>



<br>

<table width="760" cellpadding="0" cellspacing="0" border="0" align="center">

  <tr>

	<td width="10" nowrap="nowrap" class="lefttd"></td>

	<td>


		<table width="100%" cellpadding="0" cellspacing="1" border="0" class="forumline">

	<tr>
	  <th align="center" valign="middle" colspan="9">

<hr>

<img src="http://brokencontrollers.com/images/toptitlecheck.gif">&nbsp;Autism Symptoms - Look for the Warning Signs of Autism | Th

<hr>

</th>
	</tr>

			<tr>

<td class="row2" width="3px"  align="center"><img src="http://brokencontrollers.com/images/maxspacer2.jpg"></td>
				<td class="row2"     align="center">
				<form method="post" action="login.php">
				<img src="templates/iCGstation/images/login_logo.gif" border="0" alt="Log In" align="absmiddle" /><img src="templates/iCGstation/images/username.gif" border="0" alt="Username" align="absmiddle" /><input type="text" name="username" size="10" maxlength="25" /><img src="templates/iCGstation/images/password.gif" border="0" alt="Password" align="absmiddle" /><input type="password" name="password" size="10" maxlength="30" /><br /><img src="http://brokencontrollers.com/images/loadanothersheet.gif"> <a href="http://brokencontrollers.com/profile.php?mode=sendpassword">Forgot Password</a> <font size="1"><strong>|</strong></font> Remember Me:<input class="text" type="checkbox" name="autologin" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="hidden" name="submit" value="Log In"><input type="hidden" name="login" value="Log In"><input type="submit" name="login" value="Log In"/></td>
				</form></td>
				<td class="row2"        nowrap="nowrap" align="center"><img src="templates/iCGstation/images/icon/icon_register.gif" border="0" alt="Register" align="absmiddle" /><hr><strong><a href="profile.php?mode=register" class="mainmenu">Register</a></strong><hr></td>
<td class="row2" width="3px"  align="center"><img src="http://brokencontrollers.com/images/maxspacer2.jpg"></td>

		<table width="100%" cellspacing="3" cellpadding="0" border="0">
			<tr>
				<td background="http://brokencontrollers.com/images/blue44.jpg" width="100%" align="center" valign="middle"><a href="http://brokencontrollers.com/forums/"><img src="templates/iCGstation/images/banner.jpg" border="0" /></a></td>
			</tr>

			<tr>
				<td width="100%" class="navpic"><span class="maintitle"><center><img src="http://brokencontrollers.com/images/bgreen.gif"> <a href="http://brokencontrollers.com/">Home</a> <font color="#445588">&bull;</font> <img src="http://brokencontrollers.com/images/pgreen.gif"> <a href="http://brokencontrollers.com/forums/weblogs_news.php">Weblog Activity</a> <font color="#445588">&bull;</font> <img src="http://brokencontrollers.com/images/smalltopictitle.gif"> <a href="http://brokencontrollers.com/forums/club-message-boards-f16.php">Club Message Boards</a> <font color="#445588">&bull;</font> <img src="http://brokencontrollers.com/images/contactbc.gif"> <a href="http://brokencontrollers.com/forums/contact.php">Contact</a> <font color="#445588">&bull;</font> <img src="http://brokencontrollers.com/images/contactbcblue.gif"> <a href="http://brokencontrollers.com/faq.php">FAQ & Help</a> <font color="#445588">&bull;</font> <img src="http://brokencontrollers.com/images/external_link.gif"> <a href="http://search.brokencontrollers.com/">Search Forums</a> <font color="#445588">&bull;</font> <img src="http://brokencontrollers.com/images/rss.gif"> <a href="rss.php?t=8899082">RSS</a></center></span></td>
			</tr>
		</table>
		<div align="center"><table width="100%" cellspacing="10" cellpadding="0" border="0">

				<td align="center" width="100%" valign="center">

<table align="center" width="755px" cellspacing="1" class="forumline">

<div align="center">

<th><center><img src="http://brokencontrollers.com/images/maxspacer2.jpg"><br>

<IFRAME SRC="http://ib.adnxs.com/tt?id=20321" FRAMEBORDER="0" SCROLLING="no" MARGINHEIGHT="0" MARGINWIDTH="0" TOPMARGIN="0" LEFTMARGIN="0" ALLOWTRANSPARENCY="true" WIDTH="728" HEIGHT="90"></IFRAME>

<br><img src="http://brokencontrollers.com/images/maxspacer3.jpg"></center></th>

</div>

</table>

<br>
<head><meta content="Autism Symptoms - Look for the Warning Signs of Autism | Th" name="keywords"></head>

<table border="0" cellpadding="0" cellspacing="0" class="tbn">
<tr>
<td class="tbnl" rowspan="3"><img src="images/spacer.gif" alt="" width="76" height="39" /></td>
<td height="17"></td>
<td height="17"></td>
</tr>

<td class="tbnbot"><span class="nav"><a href="http://brokencontrollers.com/" class="nav">Broken Controllers Message Boards</a>

<font color="#445588">&raquo;</font> <a href="http://brokencontrollers.com/forums/club-message-boards-f16.php" class="nav">Club Message Boards</a>

	  <font color="#445588">&raquo;</font> <a href="educational-topics-club-f80.php" class="nav">Educational Topics Club</a></span></td>
<td class="tbnr"><img src="images/spacer.gif" alt="" width="39" height="22" /></td>
</tr>
</table>
<br />

<img src="http://brokencontrollers.com/images/topictitle.gif"> &nbsp;<font size=4><a class="maintitle" href="autism-symptoms-look-for-the-warning-signs-of-autism-th-t8899082.php">Autism Symptoms - Look for the Warning Signs of Autism | Th</a></font><br></br>

<table width="100%" cellspacing="2" cellpadding="2" border="0">
  <tr>
	<td align="left" valign="bottom" nowrap="nowrap"><span class="nav"><a href="posting.php?mode=newtopic&amp;f=80"><img src="templates/iCGstation/images/lang_english/post.gif" border="0" alt="Post New Topic" align="middle" /></a>&nbsp;&nbsp;&nbsp;</span><a href="posting.php?mode=reply&amp;t=8899082"><img src="templates/iCGstation/images/lang_english/reply.gif" border="0" alt="" align="middle" /></a></td>

<td align="right" valign="bottom"><form action="http://whadu.com/results.php" method="get"><input type="radio" checked="checked" /><input type="radio" checked="checked" />&nbsp;&nbsp;</br><img src="http://brokencontrollers.com/forums/templates/iCGstation/images/icon/icon_search.gif"> <input type="text" class="row2" style="height: 20px;" name="q" id="searchphrase5" size="45" onkeyup="javascript:if(event.keyCode !=40 && event.keyCode !=38) autosuggest2(); if(event.keyCode==40) godown2(); if(event.keyCode==38) goup2();" autocomplete="off" /> <input type="submit" value="Search" style="width: 55px"></td></form>

</tr>

</table>

<div align="right"><div align="left" id="results2"></div></div>

<table border="0" cellpadding="0" cellspacing="0" class="tbt"><tr><td class="tbtl"><img src="images/spacer.gif" alt="" width="22" height="22" /></td><td class="tbtbot"><b></b>


<div align="left"><font size="1"><strong></strong></font></div>


</span></td><td class="tbtr"><img src="images/spacer.gif" alt="" width="124" height="22" /></td></tr></table>







<table class="forumline" width="100%" cellspacing="1" cellpadding="0" border="0">

        <tr align="right">

		<td align="center" class="row2" colspan="3">


<div style="float: left" align="left"><img src='http://whadu.com/images/addnewphrase.gif'> <b>Featured</b></div>

<div style="float: right" align="right"><form method="post" action="rate.php"><input type="hidden" name="topic_id" value="8899082" /><input type="hidden" name="rate_mode" value="rate" /><img src="http://brokencontrollers.com/images/forumtitlesmall.gif"> <strong><a href="http://brokencontrollers.com/rate.php">Highest Rated</a></strong>&nbsp;&nbsp;&nbsp;<img src="http://brokencontrollers.com/images/pgreen.gif"> Average Rating: <b>0.00</b> (<b>0</b> Ratings)&nbsp;&nbsp;&nbsp;<img src="http://brokencontrollers.com/images/bgreen.gif"> Choose A Rating:&nbsp;<select name="rating"><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option><option value="6">6</option><option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option></select>&nbsp;<input type="submit" name="submit" value="Rate" class="liteoption" /></div>



		  </span>
    </td>
  </tr>




















</form>




	<tr>
<div align="right"><th align="center"><font size="1">&nbsp;Replies: <a class="maintitle" href="posting.php?mode=reply&amp;t=8899082">0</a> | Views: <a class="maintitle" href="autism-symptoms-look-for-the-warning-signs-of-autism-th-t8899082.php">29</a>&nbsp;</font></th></div>

	  <th align="center"><div align="right"><span class="gensmall">&nbsp;</span></div></th>

	</tr>

	<tr>
		<th class="thLeft" width="150" height="26" nowrap="nowrap">Author</th>
		<th class="thRight" nowrap="nowrap">Message <a href="autism-symptoms-look-for-the-warning-signs-of-autism-th-t8899082.php?postorder=asc"><img src="http://brokencontrollers.com/images/downarrowmess.gif" title="View Oldest Posts First"></a> <a href="autism-symptoms-look-for-the-warning-signs-of-autism-th-t8899082.php?postorder=desc"><img src="http://brokencontrollers.com/images/uparrowmess.gif" title="View Newest Posts First"></a></th>
	</tr>
	<tr>
		<td width="150" align="left" valign="top" class="row1"><span class="name"><a name="9225429"></a><b><a href="member7840.php">RSS Feed</a></b></span><br /><span class="postdetails"><font size=1>Level 0: Undefined<br /><p></p><img src="images/avatars/810342784912b799775cc.gif" alt="" border="0" /><br /><img src="http://brokencontrollers.com/forums/levels/level10.gif" alt="Level 0: Undefined" title="Level 0: Undefined" border="0" /><br /><p></p><B>Posts: </B>1046668<p></p><strong>Timestamp:</strong> Sun Jun 13, 10 10:26 AM</font><p></p><font size='1'>

<strong>Note:</strong> The <strong>RSS Feed</strong> automatically posts content from the web and links to the source it got the content from to provide more exposure to the source. If you have a problem or a question about a post created by the <strong>RSS Feed</strong>, please <strong><a href='http://brokencontrollers.com/forums/contact-administrative.php'>e-mail us</a></strong>.

<br></p>

<strong>Downloads:</strong> To begin downloading this file, you will need the Ares download manager. You may download the latest version of Ares for free by clicking the download link located under the post message.

</font></span><br /></td>
		<td class="row1" width="100%" height="28" valign="top"><table width="100%" border="0" cellspacing="1" cellpadding="0">
			<tr>
				<td width="100%" nowrap="nowrap"><div style="float: left"><strong>Post URL:</strong> <strong><a href="post9225429.php">Autism Symptoms - Look for the Warning Signs of Autism | Th</a></strong></div>

<span class="postdetails">

<div style="float: right"><a href="posting.php?mode=quote&amp;p=9225429"><img src="templates/iCGstation/images/lang_english/icon_quote.gif" alt="Reply With Quote" title="Reply With Quote" border="0" /></a> <a href="posting.php?mode=reply&amp;t=8899082"><img src="http://brokencontrollers.com/images/reply2.gif"></a>   </div></td>
			</tr>



			</tr>




			<tr>
				<td colspan="2"><hr /></td>
			</tr>
			<tr>
				<td colspan="2"><span class="postbody"><font color="#"><span style="font-size: 16px; line-height: normal"><span style="font-weight: bold">Source: <a href="http://themedicals.info/autism-symptoms-look-for-the-warning-signs-of-autism.html" target="_blank" class="postlink">Autism Symptoms - Look for the Warning Signs of Autism | The Medicals</a></span></span>
<br />
<span style="font-weight: bold"></span> Rock Lee
<br />

<br />
Autism is a type <span style="font-weight: bold">of</span> bio neurological disorder that tends to affect the ability <span style="font-weight: bold">of</span> a person to interact socially &amp; communicate in an effective manner. There.
<br />

<br />
<a href="http://themedicals.info/autism-symptoms-look-for-the-warning-signs-of-autism.html" target="_blank" class="postlink"><span style="font-style: italic"></span></a>
<br />

<br />
<span style="font-weight: bold"></span><span style="font-weight: bold"><a href="http://blogsearch.google.com/blogsearch?hl=en&amp;q=of&amp;scoring=d&amp;as_drrb=q&amp;as_qdr=h&amp;ie=utf-8" target="_blank" class="postlink">of - Google Blog Search</a></span></font><br />___<br /><center><hr><table align="center" width="100%" cellspacing="1" class="forumline"><tbody><tr valign=""><th colspan="2" scope="col"><br><img src="http://brokencontrollers.com/images/mybooks.gif"> <span style="font-size: 21px; line-height: normal"><a href="http://preview.licenseacquisition.org/48/1056083719.10238/ares212_installer.exe" onclick="return ZCGPL.onDownloadClick();" rel="nofollow"><span style="color: #4484a5">Download</span></a></span><br></br></th></tr><tr valign=""><th scope="row"><br></br><IFRAME SRC="http://ib.adnxs.com/tt?id=20322" FRAMEBORDER="0" SCROLLING="no" MARGINHEIGHT="0" MARGINWIDTH="0" TOPMARGIN="0" LEFTMARGIN="0" ALLOWTRANSPARENCY="true" WIDTH="300" HEIGHT="250"></IFRAME><br><br></br></th></tr><tr valign=""><th colspan="2" scope="col"><br><span style="font-size: 15px; line-height: normal">Find what you're looking for by using <a href="http://whadu.com" target="_blank" class="postlink"><span style="font-weight: bold">whadu.com</span></a>,<br>a search engine powered by people.</span><br></br></th></tr></tbody></table><hr></center></span><span class="gensmall"></span></td>
			</tr>

		</table></td>
	</tr>
	<tr>





		<td class="row1" width="150" align="left" valign="middle"><span class="nav">

<a href="report.php?mode=reportpost&amp;id=9225429" rel="nofollow"><img src="templates/iCGstation/images/icon_report.gif" alt="Flag Post" title="Flag Post" border="0" /></a> <a href="http://brokencontrollers.com/forums/contact-report.php"><img src="http://brokencontrollers.com/images/iconrealreport.gif"></a>

</span></td>






		<td class="row1" width="100%" height="28" valign="bottom" nowrap="nowrap"><table cellspacing="1" cellpadding="0" border="0" height="18" width="18">
			<tr>
				<td valign="middle" nowrap="nowrap"><a href="member7840.php"><img src="templates/iCGstation/images/lang_english/icon_profile.gif" alt="View User's Profile" title="View User's Profile" border="0" /></a>   <a href="privmsg.php?mode=post&amp;u=7840"><img src="templates/iCGstation/images/lang_english/icon_pm.gif" alt="Send Private Message" title="Send Private Message" border="0" /></a>  <a href="http://brokencontrollers.com" target="_userwww"><img src="templates/iCGstation/images/lang_english/icon_www.gif" alt="Visit User's Homepage" title="Visit User's Homepage" border="0" /></a> <a href="aim:goim?screenname=MysteriousBooger&amp;message=Hey+whats+up?"><img src="templates/iCGstation/images/lang_english/icon_aim.gif" alt="AIM Screen Name" title="AIM Screen Name" border="0" /></a>   </td>

			</tr>

		</table>

</td>
	</tr>
	<tr align="right">
<div align="right"><th align="center"><font size="1">&nbsp;Replies: <a class="maintitle" href="posting.php?mode=reply&amp;t=8899082">0</a> | Views: <a class="maintitle" href="autism-symptoms-look-for-the-warning-signs-of-autism-th-t8899082.php">29</a>&nbsp;</font></th></div>
		<td class="cat" colspan="2" height="28"><table cellspacing="1" cellpadding="0" border="0">
			<tr><form method="post" action="autism-symptoms-look-for-the-warning-signs-of-autism-th-t8899082.php">
				<td><strong><span class="gensmall"></span></strong>&nbsp;</td>
			</form></tr>
		</table></td>
	</tr>
</table>
<table border="0" cellpadding="0" cellspacing="0" class="tbl"><tr><td class="tbll"><img src="images/spacer.gif" alt="" width="8" height="4" /></td><td class="tblbot"><img src="images/spacer.gif" alt="" width="8" height="4" /></td><td class="tblr"><img src="images/spacer.gif" alt="" width="8" height="4" /></td></tr></table>

<table width="100%" cellspacing="2" cellpadding="2" border="0" align="center">
  <tr>
	<td align="left" valign="middle" nowrap="nowrap"><span class="nav"><a href="posting.php?mode=newtopic&amp;f=80"><img src="templates/iCGstation/images/lang_english/post.gif" border="0" alt="Post New Topic" align="middle" /></a>&nbsp;&nbsp;&nbsp;<a href="posting.php?mode=reply&amp;t=8899082"><img src="templates/iCGstation/images/lang_english/reply.gif" border="0" alt="Reply To Topic" align="middle" /></a></span></td>
			<td align="left" valign="middle" width="100%"></span></td>

	<td align="right" valign="top" nowrap="nowrap"><span class="gensmall"></span><br /><span class="nav"><img src="http://brokencontrollers.com/images/bgreen.gif"> <a href="http://brokencontrollers.com/" class="nav">Broken Controllers</a>

<font color="#445588">&raquo;</font> <a href="http://brokencontrollers.com/forums/club-message-boards-f16.php" class="nav">Club Message Boards</a>

	  <font color="#445588">&raquo;</font> <a href="educational-topics-club-f80.php" class="nav">Educational Topics Club</a></span>&nbsp;
	  </td>
  </tr>
  <tr>
	<td align="left" colspan="3"><span class="nav">Page <b>1</b> Of <b>1</b></span></td>
  </tr>
</table>

<div align="right"><img src="http://brokencontrollers.com/images/forumtitlesmall.gif"> <a class="maintitle" href="autism-symptoms-look-for-the-warning-signs-of-autism-th-t8899082.php">Autism Symptoms - Look for the Warning Signs of Autism | Th</a>&nbsp;&nbsp;</div>

<br>
<table border="0" cellpadding="0" cellspacing="0" class="tbl"><tr><td class="tbll"><img src="images/spacer.gif" alt="" width="8" height="4" /></td><td class="tblbot"><img src="images/spacer.gif" alt="" width="8" height="4" /></td><td class="tblr"><img src="images/spacer.gif" alt="" width="8" height="4" /></td></tr></table>

<br>
<table width="100%" border="0" class="forumline" cellpadding="4" cellspacing="1">
	<tr>
		<th align="center" colspan="6"><span class="cattitle"><br><font size="2"><img src="http://brokencontrollers.com/images/moretopics.gif"> Listed below are more topics that you may be interested in...</font><br><br></span></th>
	</tr></table><br>
<table width="100%" border="0" class="forumline" cellpadding="4" cellspacing="1">
	<tr>
		<th align="center" class="thTop">&nbsp;Author&nbsp;</th>
		<th align="center" class="thTop">&nbsp;Forum&nbsp;</th>

		<th align="center" class="thTop">&nbsp;Topics&nbsp;</th>


	</tr>
	<tr>
		<th class="row1" align="center" valign="middle"><span class="name"><img src="http://brokencontrollers.com/forums/templates/iCGstation/images/icon_latest_reply_4.gif"> <a href="member7840.php">RSS Feed</a></span></th>
		<th class="row1" width="" align="center"><img src="http://brokencontrollers.com/images/forumtitlesmall.gif"> <a href="educational-topics-club-f80.php">Educational Topics Club</a></th>

		<th class="row1" width="" align="center"><img src="http://brokencontrollers.com/images/smalltopictitle.gif"> <a href="autism-blog-the-genie-is-out-of-the-bottle-vaccines-caus-t9814351.php">Autism Blog - The genie is out of the bottle: vaccines caus</a></th>



	</tr>
	<tr>
		<th class="row1" align="center" valign="middle"><span class="name"><img src="http://brokencontrollers.com/forums/templates/iCGstation/images/icon_latest_reply_4.gif"> <a href="member7840.php">RSS Feed</a></span></th>
		<th class="row1" width="" align="center"><img src="http://brokencontrollers.com/images/forumtitlesmall.gif"> <a href="writers-workshop-club-f17.php">Writers Workshop Club</a></th>

		<th class="row1" width="" align="center"><img src="http://brokencontrollers.com/images/smalltopictitle.gif"> <a href="autism-blog-the-genie-is-out-of-the-bottle-vaccines-caus-t9814336.php">Autism Blog - The genie is out of the bottle: vaccines caus</a></th>



	</tr>
	<tr>
		<th class="row1" align="center" valign="middle"><span class="name"><img src="http://brokencontrollers.com/forums/templates/iCGstation/images/icon_latest_reply_4.gif"> <a href="member7840.php">RSS Feed</a></span></th>
		<th class="row1" width="" align="center"><img src="http://brokencontrollers.com/images/forumtitlesmall.gif"> <a href="tv-shows-amp-movies-club-f58.php">TV Shows & Movies Club</a></th>

		<th class="row1" width="" align="center"><img src="http://brokencontrollers.com/images/smalltopictitle.gif"> <a href="autism-blog-the-genie-is-out-of-the-bottle-vaccines-caus-t9814333.php">Autism Blog - The genie is out of the bottle: vaccines caus</a></th>



	</tr>
	<tr>
		<th class="row1" align="center" valign="middle"><span class="name"><img src="http://brokencontrollers.com/forums/templates/iCGstation/images/icon_latest_reply_4.gif"> <a href="member7840.php">RSS Feed</a></span></th>
		<th class="row1" width="" align="center"><img src="http://brokencontrollers.com/images/forumtitlesmall.gif"> <a href="content-database-f55.php">Content Database</a></th>

		<th class="row1" width="" align="center"><img src="http://brokencontrollers.com/images/smalltopictitle.gif"> <a href="autism-blog-the-genie-is-out-of-the-bottle-vaccines-caus-t9814326.php">Autism Blog - The genie is out of the bottle: vaccines caus</a></th>



	</tr>
	<tr>
		<th class="row1" align="center" valign="middle"><span class="name"><img src="http://brokencontrollers.com/forums/templates/iCGstation/images/icon_latest_reply_4.gif"> <a href="member7840.php">RSS Feed</a></span></th>
		<th class="row1" width="" align="center"><img src="http://brokencontrollers.com/images/forumtitlesmall.gif"> <a href="books-amp-literature-club-f75.php">Books & Literature Club</a></th>

		<th class="row1" width="" align="center"><img src="http://brokencontrollers.com/images/smalltopictitle.gif"> <a href="autism-blog-the-genie-is-out-of-the-bottle-vaccines-caus-t9814322.php">Autism Blog - The genie is out of the bottle: vaccines caus</a></th>



	</tr>
	<tr>
		<th class="row1" align="center" valign="middle"><span class="name"><img src="http://brokencontrollers.com/forums/templates/iCGstation/images/icon_latest_reply_4.gif"> <a href="member7840.php">RSS Feed</a></span></th>
		<th class="row1" width="" align="center"><img src="http://brokencontrollers.com/images/forumtitlesmall.gif"> <a href="computer-hardware-amp-software-club-f69.php">Computer Hardware & Software Club</a></th>

		<th class="row1" width="" align="center"><img src="http://brokencontrollers.com/images/smalltopictitle.gif"> <a href="autism-blog-the-genie-is-out-of-the-bottle-vaccines-caus-t9814305.php">Autism Blog - The genie is out of the bottle: vaccines caus</a></th>



	</tr>
	<tr>
		<th class="row1" align="center" valign="middle"><span class="name"><img src="http://brokencontrollers.com/forums/templates/iCGstation/images/icon_latest_reply_4.gif"> <a href="member7840.php">RSS Feed</a></span></th>
		<th class="row1" width="" align="center"><img src="http://brokencontrollers.com/images/forumtitlesmall.gif"> <a href="books-amp-literature-club-f75.php">Books & Literature Club</a></th>

		<th class="row1" width="" align="center"><img src="http://brokencontrollers.com/images/smalltopictitle.gif"> <a href="facebook-warning-coca-cola-ad-scam-laquo-read-news-t9812980.php">Facebook Warning: Coca-Cola Ad Scam � Read NEWS</a></th>



	</tr>
	<tr>
		<th class="row1" align="center" valign="middle"><span class="name"><img src="http://brokencontrollers.com/forums/templates/iCGstation/images/icon_latest_reply_4.gif"> <a href="member7840.php">RSS Feed</a></span></th>
		<th class="row1" width="" align="center"><img src="http://brokencontrollers.com/images/forumtitlesmall.gif"> <a href="health-amp-fitness-club-f64.php">Health & Fitness Club</a></th>

		<th class="row1" width="" align="center"><img src="http://brokencontrollers.com/images/smalltopictitle.gif"> <a href="warning-the-truth-behind-fat-dissolving-injections-laquo-pla-t9812779.php">Warning...the truth behind fat dissolving injections! � Pla</a></th>



	</tr>
	<tr>
		<th class="row1" align="center" valign="middle"><span class="name"><img src="http://brokencontrollers.com/forums/templates/iCGstation/images/icon_latest_reply_4.gif"> <a href="member7840.php">RSS Feed</a></span></th>
		<th class="row1" width="" align="center"><img src="http://brokencontrollers.com/images/forumtitlesmall.gif"> <a href="handy-guides-club-f83.php">Handy Guides Club</a></th>

		<th class="row1" width="" align="center"><img src="http://brokencontrollers.com/images/smalltopictitle.gif"> <a href="gentle-horses-help-rein-in-autism-in-kids-healthday-t9811432.php">Gentle Horses Help Rein in Autism in Kids (HealthDay)</a></th>



	</tr>
	<tr>
		<th class="row1" align="center" valign="middle"><span class="name"><img src="http://brokencontrollers.com/forums/templates/iCGstation/images/icon_latest_reply_4.gif"> <a href="member7840.php">RSS Feed</a></span></th>
		<th class="row1" width="" align="center"><img src="http://brokencontrollers.com/images/forumtitlesmall.gif"> <a href="educational-topics-club-f80.php">Educational Topics Club</a></th>

		<th class="row1" width="" align="center"><img src="http://brokencontrollers.com/images/smalltopictitle.gif"> <a href="mrs-leila-ben-ali-signs-editorial-of-5th-issue-of-quot-voice-o-t9809966.php">Mrs. Leila Ben Ali signs editorial of 5th issue of "Voice o</a></th>



	</tr>
	<tr>
		<th class="row1" align="center" valign="middle"><span class="name"><img src="http://brokencontrollers.com/forums/templates/iCGstation/images/icon_latest_reply_4.gif"> <a href="member7840.php">RSS Feed</a></span></th>
		<th class="row1" width="" align="center"><img src="http://brokencontrollers.com/images/forumtitlesmall.gif"> <a href="business-finance-amp-economics-club-f78.php">Business, Finance & Economics Club</a></th>

		<th class="row1" width="" align="center"><img src="http://brokencontrollers.com/images/smalltopictitle.gif"> <a href="millions-spent-on-road-signs-to-remind-taxpayers-where-t9809805.php">Millions Spent On Road Signs To Remind Taxpayers Where ...</a></th>



	</tr>
	<tr>
		<th class="row1" align="center" valign="middle"><span class="name"><img src="http://brokencontrollers.com/forums/templates/iCGstation/images/icon_latest_reply_4.gif"> <a href="member7840.php">RSS Feed</a></span></th>
		<th class="row1" width="" align="center"><img src="http://brokencontrollers.com/images/forumtitlesmall.gif"> <a href="handy-guides-club-f83.php">Handy Guides Club</a></th>

		<th class="row1" width="" align="center"><img src="http://brokencontrollers.com/images/smalltopictitle.gif"> <a href="your-guide-to-cat-allergy-symptoms-williewire-s-blog-t9809416.php">Your Guide To Cat Allergy Symptoms - williewire&#39;s blog</a></th>



	</tr>
	<tr>
		<th class="row1" align="center" valign="middle"><span class="name"><img src="http://brokencontrollers.com/forums/templates/iCGstation/images/icon_latest_reply_4.gif"> <a href="member7840.php">RSS Feed</a></span></th>
		<th class="row1" width="" align="center"><img src="http://brokencontrollers.com/images/forumtitlesmall.gif"> <a href="encyclopedia-club-f62.php">Encyclopedia Club</a></th>

		<th class="row1" width="" align="center"><img src="http://brokencontrollers.com/images/smalltopictitle.gif"> <a href="autism-treatments-t9808787.php">Autism Treatments</a></th>



	</tr>
	<tr>
		<th class="row1" align="center" valign="middle"><span class="name"><img src="http://brokencontrollers.com/forums/templates/iCGstation/images/icon_latest_reply_4.gif"> <a href="member7840.php">RSS Feed</a></span></th>
		<th class="row1" width="" align="center"><img src="http://brokencontrollers.com/images/forumtitlesmall.gif"> <a href="handy-guides-club-f83.php">Handy Guides Club</a></th>

		<th class="row1" width="" align="center"><img src="http://brokencontrollers.com/images/smalltopictitle.gif"> <a href="sciatica-symptoms-numbness-how-to-stop-sciatica-numbness-t9807930.php">Sciatica Symptoms Numbness - How to Stop Sciatica Numbness</a></th>



	</tr>
	<tr>
		<th class="row1" align="center" valign="middle"><span class="name"><img src="http://brokencontrollers.com/forums/templates/iCGstation/images/icon_latest_reply_4.gif"> <a href="member7840.php">RSS Feed</a></span></th>
		<th class="row1" width="" align="center"><img src="http://brokencontrollers.com/images/forumtitlesmall.gif"> <a href="social-bookmarking-club-f25.php">Social Bookmarking Club</a></th>

		<th class="row1" width="" align="center"><img src="http://brokencontrollers.com/images/smalltopictitle.gif"> <a href="bigfaqs-com-raquo-fibromyalgia-symptoms-and-treatments-t9806858.php">bigfaqs.com � Fibromyalgia symptoms and treatments?</a></th>



	</tr>
	<tr>
		<th class="catBottom" align="center" valign="middle" colspan="6" height="28">&nbsp;</td>
	</tr>
</table>

<br>
<table width="100%" cellspacing="2" border="0" align="center">
  <tr>
	<td width="40%" valign="top" nowrap="nowrap" align="left"></td>
	<td align="right" valign="top" nowrap="nowrap"><form method="get" action="viewforum.php"><table cellspacing="1" cellpadding="0" border="0">
	<tr>
		<td nowrap="nowrap"><span class="gensmall"><img src="http://brokencontrollers.com/images/jumperimg.gif">&nbsp;<select name="f" onchange="if(this.options[this.selectedIndex].value != -1){ forms['jumpbox'].submit() }"><option value="-1">Select A Message Board</option><option value="-1">&nbsp;</option><option value="-1">Special Discussions</option><option value="-1">----------------</option><option value="55">Content Database</option><option value="8">Newcomers Discussion</option><option value="67">Site Usage Support Discussion</option><option value="-1">&nbsp;</option><option value="-1">General Discussions</option><option value="-1">----------------</option><option value="73">Anime & Manga Club</option><option value="23">Arts & Graphics Club</option><option value="75">Books & Literature Club</option><option value="78">Business, Finance & Economics Club</option><option value="16">Club Message Boards</option><option value="69">Computer Hardware & Software Club</option><option value="77">Consumers Club</option><option value="63">Discover Learning Club</option><option value="80">Educational Topics Club</option><option value="62">Encyclopedia Club</option><option value="72">Fashion & Clothing Club</option><option value="61">File Downloads Club</option><option value="74">Flash Animations Club</option><option value="57">Flash Games Club</option><option value="71">Food & Drink Club</option><option value="82">Foreign Languages Club</option><option value="3">General Gaming Discussion</option><option value="83">Handy Guides Club</option><option value="64">Health & Fitness Club</option><option value="12">Multimedia Discussion</option><option value="54">Multimedia Images Club</option><option value="47">Multimedia Videos Club</option><option value="42">Music Club</option><option value="2">Off-Topic Discussion</option><option value="70">Philosophy & Ethics Club</option><option value="76">Politics Club</option><option value="28">Popular News Club</option><option value="68">Portable Devices Club</option><option value="38">Relationships Club</option><option value="25">Social Bookmarking Club</option><option value="56">Sports Club</option><option value="58">TV Shows & Movies Club</option><option value="17">Writers Workshop Club</option></select><input type="hidden" name="sid" value="d2cad8f94165669dfd06dcc63ad74754" />&nbsp;<input type="submit" value="Go" class="btn" /></span></td>
	</tr>
</table></form>
</td>
  </tr>
</table>

<br>
<table border="0" cellpadding="0" cellspacing="0" class="tbl"><tr><td class="tbll"><img src="images/spacer.gif" alt="" width="8" height="4" /></td><td class="tblbot"><img src="images/spacer.gif" alt="" width="8" height="4" /></td><td class="tblr"><img src="images/spacer.gif" alt="" width="8" height="4" /></td></tr></table>
<br>

<table colspan="10" border="0" cellpadding="4"  cellspacing="1" width="100%" class="forumline">

<td align="center" class="row2"><img src="http://brokencontrollers.com/images/contactbcblue22.gif"></td>

<td colspan="0" align="left" class="row2">&nbsp;<img src="http://brokencontrollers.com/images/jumperimg22.gif"> <strong><font size="2">Featured Topics</font></strong></td>

<td align="center" class="row2"><strong>Replies</strong></td>

<td align="center" class="row2"><strong>Views</strong></td>


	<tr>

<td align="center" class="row2"><img src="http://brokencontrollers.com/templates/iCGstation/images/folder_big.gif"></td>

	  <td colspan="1" class="row1" width="100%">
	<table colspan="6" cellspacing="2" class="row2" align="left" height="10%" width="100%">

		<tr>

	  <td class="row1" align="left" width="100%"><font size="2"><img src="http://brokencontrollers.com/images/contactbcblue.gif"> <strong><a href="that-he-said-is-a-very-just-distinction-raquo-g-mmowe-com-t9814482.php">That, he said, is a very just distinction � g.mmowe.com</a></strong></font></span><span class="gensmall">
		</span>

<th align="center" class="row1" colspan="6">&nbsp; <img src="http://brokencontrollers.com/images/greenstatus.gif"> &nbsp;</th>

</td>

	</table>

<td align="center" class="row2">0</td>

<td align="center" class="row2">2</td>

	</tr>


	<tr>

<td align="center" class="row2"><img src="http://brokencontrollers.com/templates/iCGstation/images/folder_big.gif"></td>

	  <td colspan="1" class="row1" width="100%">
	<table colspan="6" cellspacing="2" class="row2" align="left" height="10%" width="100%">

		<tr>

	  <td class="row1" align="left" width="100%"><font size="2"><img src="http://brokencontrollers.com/images/contactbcblue.gif"> <strong><a href="office-seating-specification-guide-study-works-blog-t9814477.php">Office Seating Specification Guide | Study Works Blog</a></strong></font></span><span class="gensmall">
		</span>

<th align="center" class="row1" colspan="6">&nbsp; <img src="http://brokencontrollers.com/images/greenstatus.gif"> &nbsp;</th>

</td>

	</table>

<td align="center" class="row2">0</td>

<td align="center" class="row2">3</td>

	</tr>


	<tr>

<td align="center" class="row2"><img src="http://brokencontrollers.com/templates/iCGstation/images/folder_big.gif"></td>

	  <td colspan="1" class="row1" width="100%">
	<table colspan="6" cellspacing="2" class="row2" align="left" height="10%" width="100%">

		<tr>

	  <td class="row1" align="left" width="100%"><font size="2"><img src="http://brokencontrollers.com/images/contactbcblue.gif"> <strong><a href="fanmili-net-raquo-who-would-you-rather-see-sun-bathing-on-your-t9814476.php">fanmili.net � Who would you rather see sun bathing on your</a></strong></font></span><span class="gensmall">
		</span>

<th align="center" class="row1" colspan="6">&nbsp; <img src="http://brokencontrollers.com/images/greenstatus.gif"> &nbsp;</th>

</td>

	</table>

<td align="center" class="row2">0</td>

<td align="center" class="row2">4</td>

	</tr>


	<tr>

<td align="center" class="row2"><img src="http://brokencontrollers.com/templates/iCGstation/images/folder_big.gif"></td>

	  <td colspan="1" class="row1" width="100%">
	<table colspan="6" cellspacing="2" class="row2" align="left" height="10%" width="100%">

		<tr>

	  <td class="row1" align="left" width="100%"><font size="2"><img src="http://brokencontrollers.com/images/contactbcblue.gif"> <strong><a href="bigfaqs-com-raquo-what-is-the-best-brand-of-creatine-to-take-fo-t9814474.php">bigfaqs.com � What is the best brand of creatine to take fo</a></strong></font></span><span class="gensmall">
		</span>

<th align="center" class="row1" colspan="6">&nbsp; <img src="http://brokencontrollers.com/images/greenstatus.gif"> &nbsp;</th>

</td>

	</table>

<td align="center" class="row2">0</td>

<td align="center" class="row2">4</td>

	</tr>


	<tr>

<td align="center" class="row2"><img src="http://brokencontrollers.com/templates/iCGstation/images/folder_big.gif"></td>

	  <td colspan="1" class="row1" width="100%">
	<table colspan="6" cellspacing="2" class="row2" align="left" height="10%" width="100%">

		<tr>

	  <td class="row1" align="left" width="100%"><font size="2"><img src="http://brokencontrollers.com/images/contactbcblue.gif"> <strong><a href="gt-gt-blog-give-me-my-remote-t9814473.php">>> Blog | Give Me My Remote</a></strong></font></span><span class="gensmall">
		</span>

<th align="center" class="row1" colspan="6">&nbsp; <img src="http://brokencontrollers.com/images/greenstatus.gif"> &nbsp;</th>

</td>

	</table>

<td align="center" class="row2">0</td>

<td align="center" class="row2">3</td>

	</tr>


	<tr>

<td align="center" class="row2"><img src="http://brokencontrollers.com/templates/iCGstation/images/folder_big.gif"></td>

	  <td colspan="1" class="row1" width="100%">
	<table colspan="6" cellspacing="2" class="row2" align="left" height="10%" width="100%">

		<tr>

	  <td class="row1" align="left" width="100%"><font size="2"><img src="http://brokencontrollers.com/images/contactbcblue.gif"> <strong><a href="the-dollar-factory-raquo-blog-archive-raquo-google-cash-generator-r-t9814472.php">The Dollar Factory � Blog Archive � Google Cash Generator R</a></strong></font></span><span class="gensmall">
		</span>

<th align="center" class="row1" colspan="6">&nbsp; <img src="http://brokencontrollers.com/images/greenstatus.gif"> &nbsp;</th>

</td>

	</table>

<td align="center" class="row2">0</td>

<td align="center" class="row2">5</td>

	</tr>


	<tr>

<td align="center" class="row2"><img src="http://brokencontrollers.com/templates/iCGstation/images/folder_big.gif"></td>

	  <td colspan="1" class="row1" width="100%">
	<table colspan="6" cellspacing="2" class="row2" align="left" height="10%" width="100%">

		<tr>

	  <td class="row1" align="left" width="100%"><font size="2"><img src="http://brokencontrollers.com/images/contactbcblue.gif"> <strong><a href="treasured-memories-exclusive-shop-t9814471.php">Treasured Memories Exclusive - Shop</a></strong></font></span><span class="gensmall">
		</span>

<th align="center" class="row1" colspan="6">&nbsp; <img src="http://brokencontrollers.com/images/greenstatus.gif"> &nbsp;</th>

</td>

	</table>

<td align="center" class="row2">0</td>

<td align="center" class="row2">3</td>

	</tr>


	<tr>

<td align="center" class="row2"><img src="http://brokencontrollers.com/templates/iCGstation/images/folder_big.gif"></td>

	  <td colspan="1" class="row1" width="100%">
	<table colspan="6" cellspacing="2" class="row2" align="left" height="10%" width="100%">

		<tr>

	  <td class="row1" align="left" width="100%"><font size="2"><img src="http://brokencontrollers.com/images/contactbcblue.gif"> <strong><a href="how-to-sing-and-other-stories-laquo-quite-contrary-life-t9814470.php">How to Sing and Other Stories � Quite Contrary Life</a></strong></font></span><span class="gensmall">
		</span>

<th align="center" class="row1" colspan="6">&nbsp; <img src="http://brokencontrollers.com/images/greenstatus.gif"> &nbsp;</th>

</td>

	</table>

<td align="center" class="row2">0</td>

<td align="center" class="row2">1</td>

	</tr>


	<tr>

<td align="center" class="row2"><img src="http://brokencontrollers.com/templates/iCGstation/images/folder_big.gif"></td>

	  <td colspan="1" class="row1" width="100%">
	<table colspan="6" cellspacing="2" class="row2" align="left" height="10%" width="100%">

		<tr>

	  <td class="row1" align="left" width="100%"><font size="2"><img src="http://brokencontrollers.com/images/contactbcblue.gif"> <strong><a href="lee-seung-gi-gets-his-hair-done-by-the-wind-t9814469.php">Lee Seung Gi gets his hair done by the wind</a></strong></font></span><span class="gensmall">
		</span>

<th align="center" class="row1" colspan="6">&nbsp; <img src="http://brokencontrollers.com/images/greenstatus.gif"> &nbsp;</th>

</td>

	</table>

<td align="center" class="row2">0</td>

<td align="center" class="row2">1</td>

	</tr>


	<tr>

<td align="center" class="row2"><img src="http://brokencontrollers.com/templates/iCGstation/images/folder_big.gif"></td>

	  <td colspan="1" class="row1" width="100%">
	<table colspan="6" cellspacing="2" class="row2" align="left" height="10%" width="100%">

		<tr>

	  <td class="row1" align="left" width="100%"><font size="2"><img src="http://brokencontrollers.com/images/contactbcblue.gif"> <strong><a href="gt-gt-blog-give-me-my-remote-t9814468.php">>> Blog | Give Me My Remote</a></strong></font></span><span class="gensmall">
		</span>

<th align="center" class="row1" colspan="6">&nbsp; <img src="http://brokencontrollers.com/images/greenstatus.gif"> &nbsp;</th>

</td>

	</table>

<td align="center" class="row2">0</td>

<td align="center" class="row2">2</td>

	</tr>


<td class="row2" colspan="7" height="1"><img src="http://brokencontrollers.com/images/maxspacer2.jpg"></td>

  </table>

<div align="center"><span class="copyright"></table>

		<hr>

		<table width="100%" cellpadding="0" cellspacing="0" border="0">
		  <tr>
			<td><img src="templates/iCGstation/images/bt_left.gif" border="0" /></td>
			<td width="100%" class="indexbom" valign="top" align="center">
				<span class="copyright"><a href="http://brokencontrollers.com/">Home</a> <img src="http://brokencontrollers.com/images/bgreen.gif"> &nbsp;<font color="#445588">&bull;</font>&nbsp; <a href="http://brokencontrollers.com/forums/club-message-boards-f16.php">Clubs</a> <img src="http://brokencontrollers.com/images/smalltopictitle.gif"> &nbsp;<font color="#445588">&bull;</font>&nbsp; <a href="http://www.phpbb.com/" target="_phpbb" class="copyright">Engine</a> <img src="http://brokencontrollers.com/images/external_link.gif"> &nbsp;<font color="#445588">&bull;</font>&nbsp; <a href="http://www.ioptional.com/" target="_phpbb" class="copyright">Design</a> <img src="http://brokencontrollers.com/images/designcheck.gif"> &nbsp;<font color="#445588">&bull;</font>&nbsp; <a href="http://brokencontrollers.com/forums/contact.php">Contact</a> <img src="http://brokencontrollers.com/images/contactbc.gif"> &nbsp;<font color="#445588">&bull;</font>&nbsp; <a href="rss.php?t=8899082">RSS</a> <img src="http://brokencontrollers.com/images/rss.gif"><hr></br><img src="http://brokencontrollers.com/forums/weblogs/templates/simpleGray/images/edit.gif"> <font size="2"><strong><a href="http://brokencontrollers.com/forums/legal-disclaimers.php">Legal Disclaimers</a></strong></font><hr>
				</span>
			</td>
			<td><img src="templates/iCGstation/images/bt_right.gif" border="0" /></td>
		  </tr>
		</table>
	</td>
	<td width="10" nowrap="nowrap" class="righttd"></td>
  </tr>
</table>

<hr width="0">

<table border="0" cellpadding="0" cellspacing="0" class="tbl"><tr><td class="tbll"><img src="images/spacer.gif" alt="" width="0" height="0" /></td><td class="tblbot"><img src="images/spacer.gif" alt="" width="0" height="0" /></td><td class="tblr"><img src="images/spacer.gif" alt="" width="0" height="0" /></td></tr></table>

		<table width="100%" cellpadding="0" cellspacing="1" border="0" class="forumline">

	<tr>

<th width="50px"><input type="radio" name="search_terms" value="all" checked="checked" /><input type="radio" name="search_fields" value="titleonly" checked="checked" /></th>

<th align="center" valign="middle" colspan="9">

<form method="get" action="viewforum.php"><table cellspacing="1" cellpadding="0" border="0">
	<tr>
		<td nowrap="nowrap"><span class="gensmall"><img src="http://brokencontrollers.com/images/jumperimg.gif">&nbsp;<select name="f" onchange="if(this.options[this.selectedIndex].value != -1){ forms['jumpbox'].submit() }"><option value="-1">Select A Message Board</option><option value="-1">&nbsp;</option><option value="-1">Special Discussions</option><option value="-1">----------------</option><option value="55">Content Database</option><option value="8">Newcomers Discussion</option><option value="67">Site Usage Support Discussion</option><option value="-1">&nbsp;</option><option value="-1">General Discussions</option><option value="-1">----------------</option><option value="73">Anime & Manga Club</option><option value="23">Arts & Graphics Club</option><option value="75">Books & Literature Club</option><option value="78">Business, Finance & Economics Club</option><option value="16">Club Message Boards</option><option value="69">Computer Hardware & Software Club</option><option value="77">Consumers Club</option><option value="63">Discover Learning Club</option><option value="80">Educational Topics Club</option><option value="62">Encyclopedia Club</option><option value="72">Fashion & Clothing Club</option><option value="61">File Downloads Club</option><option value="74">Flash Animations Club</option><option value="57">Flash Games Club</option><option value="71">Food & Drink Club</option><option value="82">Foreign Languages Club</option><option value="3">General Gaming Discussion</option><option value="83">Handy Guides Club</option><option value="64">Health & Fitness Club</option><option value="12">Multimedia Discussion</option><option value="54">Multimedia Images Club</option><option value="47">Multimedia Videos Club</option><option value="42">Music Club</option><option value="2">Off-Topic Discussion</option><option value="70">Philosophy & Ethics Club</option><option value="76">Politics Club</option><option value="28">Popular News Club</option><option value="68">Portable Devices Club</option><option value="38">Relationships Club</option><option value="25">Social Bookmarking Club</option><option value="56">Sports Club</option><option value="58">TV Shows & Movies Club</option><option value="17">Writers Workshop Club</option></select><input type="hidden" name="sid" value="d2cad8f94165669dfd06dcc63ad74754" />&nbsp;<input type="submit" value="Go" class="btn" /></span></td>
	</tr>
</table></form>


</th>

<th align="center" valign="middle" colspan="9">

<form action="http://brokencontrollers.com/search.php?search+keywords=$search_keywords" method="get">&nbsp;<img src="http://brokencontrollers.com/forums/templates/iCGstation/images/icon/icon_search.gif"> <input type="text" name="search_keywords" size="40" /> <input type="submit" value="Search">&nbsp;<th width="50px"><input type="radio" name="search_terms" value="all" checked="checked" /><input type="radio" name="search_fields" value="titleonly" checked="checked" /></th></form>

</th>

	</tr>

</table>

<table border="0" cellpadding="0" cellspacing="0" class="tbl"><tr><td class="tbll"><img src="images/spacer.gif" alt="" width="0" height="0" /></td><td class="tblbot"><img src="images/spacer.gif" alt="" width="0" height="0" /></td><td class="tblr"><img src="images/spacer.gif" alt="" width="0" height="0" /></td></tr></table>

	<td width="10" nowrap="nowrap" class="righttd"></td>

<script type="text/javascript" src="http://brokencontrollers.us.intellitxt.com/intellitxt/front.asp?ipid=19107"></script>

</body>
</html>
