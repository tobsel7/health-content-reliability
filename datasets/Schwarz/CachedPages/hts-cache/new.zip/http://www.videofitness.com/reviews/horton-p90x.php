<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML//EN">
<html>
  <head><TITLE>exercise video reviews: P90X Series</TITLE>
<META  NAME="description" CONTENT="Video Fitness contains exercise video reviews by consumer reviewers, plus advice and motivation from a large community of home exercise enthusiasts.">
<META  name="keywords" content="exercise videos, DVD, DVDs, exercise video reviews, exercise video, fitness videos, fitness video reviews, reviews of exercise videos, aerobic videos, Video Fitness, aerobics, aerobic choreography, step aerobics, strength training, weight training, home exercise, exercising at home, Pilates, kickboxing,  indoor cycling, Exercise Videos, reviews, how to choose an exercise video, Video Fitness, fitness links, consumer guide to exercise videos">
<META NAME="ROBOTS" CONTENT="NOARCHIVE">
<link rel="stylesheet" href="/~vfwnk/templates/vfstyle2.css">
</HEAD>
<BODY bgcolor="#ffffff" topmargin=0 leftmargin=0 rightmargin=0 marginwidth=0 marginheight=0 text="#330099" link="#6633ff" alink="#FF0033" vlink="#663399"><table cellspacing="0" cellpadding="0" border="0" width=100%><tr><td align="right" valign="bottom" rowspan=2 bgcolor="9999cc" width="95"><a href="http://www.videofitness.com"><img src="/~vfwnk/images/barbell3.jpg" width="94" height="111" alt="" border="0"></a></td><td bgcolor="#9999cc" align=center><SCRIPT type="text/javascript" LANGUAGE="javascript" src="http://www.qksz.net/1e-9nsi"> </SCRIPT></td></tr><tr><td valign="bottom" bgcolor="#9999cc" align=left><a href="http://www.videofitness.com"><img src="/~vfwnk/images/videofitness2.gif" width="195" height="27" alt="Video Fitness" border="0" hspace=2></a></td></tr></table>
<TABLE width=100% border="0" cellspacing=0 cellpadding=0 bgcolor="#ffffff">
<TR><td valign=top width=42 align=right rowspan=3 bgcolor="#FFFFFF"><img src="/~vfwnk/images/clear.gif" alt="" border="0" height=3 width=42></td><TD align=left valign=top bgcolor="#FFFFFF"><img src="/~vfwnk/images/blank.gif" alt="" border="0" width=54 height=3><A HREF="http://www.videofitness.com"><img src="/~vfwnk/images/tagline.gif" height="15" width=304 alt="" border="0"></A></TD><td valign=bottom align=right bgcolor="#FFFFFF"><FORM NAME="SelectForm"><SCRIPT LANGUAGE="JavaScript">
		function LeftSelect(theForm)
		{
			var val;
        
    	    val = theForm.LeftList.options[theForm.LeftList.selectedIndex].value;
	       	if (val == 2) location = "/reviews/";
        	if (val == 3) location = "http://forum.videofitness.com";
        	if (val == 4) location = "/exchange/";
        	if (val == 5) location = "/features/";
        	if (val == 8) location = "/faves/";
        	if (val == 9) location = "/instructors/";
   	       	if (val == 10) location = "/search/";
	       	if (val == 11) location = "/interviews/";
 	      	if (val == 12) location = "/success/";
			if (val == 13) location = "/beginners/";
        	if (val == 17) location = "/network/";
			if (val == 18) location = "http://forum.videofitness.com/forumdisplay.php?f=14";
			if (val == 19) location = "/about/supportvf.php";
	       	if (val == 23) location = "/about/";
	       	if (val == 24) location = "/100club/";
	       	if (val == 25) location = "/selector/";
		}
		</SCRIPT>
		<SELECT NAME="LeftList" onChange="LeftSelect(this.form)">		
		<OPTION VALUE="HOME">Inside Video Fitness
		<OPTION VALUE="23">About Videofitness.com
		<OPTION VALUE="10">Search VF
		<OPTION VALUE="2">Reviews
		<OPTION VALUE="9">Instructor Index
		<OPTION VALUE="3">Reader Forum
		<OPTION VALUE="4">Video Exchange
		<OPTION VALUE="18">Bargain Watch
		<OPTION VALUE="19">Support VF
		<OPTION VALUE="13">Getting Started	
		<OPTION VALUE="5">Features
		<OPTION VALUE="25">Personal Video Selector
		<OPTION VALUE="8">Favorites
		<OPTION VALUE="11">Interviews		
		<OPTION VALUE="24">100 Club		
		<OPTION VALUE="12">Success Stories	





		</SELECT></FORM></td><td valign=top width=15 align=right rowspan=3 bgcolor="#FFFFFF"><img src="/~vfwnk/images/clear.gif" alt="" border="0" width=15 height=15></td></tr>
<tr>
<td bgcolor="#FFFFFF" valign=top colspan=2 align=left>
<TABLE width=100% border="0" cellspacing=0 cellpadding=5><tr><td>
<!--begin content-->   

<h1>P90X Series</h1>
<a href="http://www.collagevideo.com/showvideo.aspx?item=detect&prioritycode=RF
92"><img src="http://www.collagevideo.com/affiliates/videopreviewimage.aspx?PriorityC
ode=RF92" align=left vspace=15 border=0 width=130 height=65></a> 
<div class="nb">

<b><I>Tony Horton</I></b>
<P>

This is to comment generally on the series.<br />
<br />
This series makes use of pullups, and I can't see getting all I can out of it without either purchasing some form of pullup bar (likely the Door Gym), or buying the bands and a door attachment to simulate the motion (one exerciser shows this).<br />
<br />
The DVDs came packaged in a nice and cushioned black, zippered case. What a GREAT alternative to the standard individually wrapped jewel cases!!  I REALLY liked this packaging concept.<br />
<br />
It also came with a lot of other stuff which  made the box huge.  I haven't yet looked at it all.<br />
<br />
It *seems* as if the same ab routine shows up at the end of a lot of the DVDS, but I'm not sure.  The ab routine looks grueling!!<br />
<br />
The strength routine makes me NOT want to rejoin the gym.  I need to solve my pullup quandry, but once I do, I feel I will get a very effective *strength building* workout at home - even for my back.<br />
<br />
I previewed the following: Chest & Back, Legs and Back, Shoulders and Arms, Yoga.  I did the Kenpo one.<br />
<br />
The Kenpo workout was a lot of fun, and I will review it in more detail in a separate review.<br />
<br />
There is a countdown graphic, but I like it.  The music is nice in all the dvds - I find it motivating when it needs be, and relaxing when it needs be.<br />
<br />
The background exercisers look great, and are motivating for that reason.<br />
<br />
Overall: Grade is: A.  I really like this, and I intend to keep it.<br />
<br />

<P><B>Instructor comments: </B>

Tony is a chatty guy.  He talks, he jokes, he makes a lot of comments, and the 'catch phrase' in this series is 'Bring it' ... and that gets said a lot.<br />
<br />
He's not to everyone's taste - does the "cool guy" thing - but it's not obnoxious, mostly it just made me smile and shake my head a few times.<br />
<br />
But Tony seems genuinely nice, and interested in helping people get fit.
			
<P><I>Leela</I><BR>
<br>
3/17/04
<p><img src="/images/hr.gif"><p>

P90X First Impression<br />
<br />
Got my P90X kit two weeks ago and have finally done all the workouts.  As you can tell from the heading, I love these workouts.  I probably won�t use them in the prescribed way, at least not yet, but they are a lot of fun.<br />
<br />
First about me so you can take my review with a grain of salt:  I�m a lifelong athlete (lacrosse, track, soccer, skiing, snowboarding) and I mostly workout to Cathe but love FitPrime.  I also do yoga daily and I like to add on fusion workouts like ATRM, Pilates, LB, and TBM.  I run and bike with Runervlas and Spinervals. <br />
<br />
I was a little intimidated by these workouts but I was able to do them and they challenged me in new ways.  Before I got into each workout, here are some overall things about the workouts: <br />
<br />
The pull-up bar is very new to me and is used in all the back workouts.  I don�t have one yet but I used my squat racks with a body bar.  I don�t recommend this as it was very unstable but it help me get started.  This is a weak area for me as it probably is for a lot of women but I feel I gained some strength. IMHO, this is one move that we should all be able to do � to lift our own body weight.  <br />
<br />
The workouts are �approachable� and this to me is a Beach Body signature.  They are not tightly choreographed � just the moves.  And boy - are there a lot of new moves in here!  I�m a certified group instructor and personal trainer and we struggle to get people to exercise.  I really like Slim Series because of its no-nonsense approach.  OK � these workouts are really tough � I admit it � but they are easy to learn.  <br />
<br />
The moves are sometimes repeated for two sets. Some are done in super set format.  Like Chest, Triceps, Shoulders � three exercises, then another three, working all those body parts  - until the work out is complete.  <br />
<br />
Warm-up and cool downs are no-nonsense Beach Body style.  Nothing new here � some cool new shoulder stretches I hadn�t seen before.  <br />
<br />
 Tony told me 1000x to write it down and I didn�t this first time through but I wish I did � because I�m the one that sets the benchmark here.  Another poster said they thought the lifting was not as heavy as Cathe.  Who says so!  All the participants were lifting different level weights.  I feel this could be a very heavy workout series if I wanted it to be.  He says 8-10 for muscle building, 10-15 for leaning out.  <br />
<br />
I felt like I had finally stepped into another world � the world of men�s training.  It was kind of cool.  These guys work hard � and the gals that were with them were working just as hard � that was really cool.  <br />
<br />
That said, this is not a stereotypically muscle man set of workouts.  Tony incorporates many new techniques and the exercise variety is astounding.  He combines standard weight training, with intense aerobics, and flexibility training as well as functional fitness.  I am impressed.  <br />
<br />
Tony is funny and makes me laugh.  I didn�t find him annoying at all. <br />
<br />
There are 12 workouts plus a book explaining the workouts and rotations in detail and a nutrition book.  I think this is a great value even without the 20% discount.<br />
<br />
Two more cool features:  I think you can do the entire series with bands and it looks tough!  I have to double check this but I think this is true.  This is great for travelers.  Also Ab Ripper is included at the end of all the weight DVDs so you don�t have to load that DVD.  Love this.<br />
<br />
The music is terrific - much better than Slim Series and I always leave it on. <br />
<br />
I�m not going to break down the workouts in detail but just give a few comments on each: <br />
<br />
Chest & Back -- 53 minutes -- pull-up bar or bands, chair, dumbbells or bands, push up bars<br />
<br />
This is mostly push-ups and pull-ups in all different varieties.  <br />
<br />
Plyometrics -- 59 minutes -- mat, chair<br />
<br />
This is tough and similar to IMAX1 or 2 but no choreography � just move after move after move.  <br />
<br />
Shoulders & Arms -- 60 minutes -- dumbbells or bands, chair<br />
<br />
Typically weight training but lots of new moves. <br />
<br />
Yoga -- 1 hour, 33 minutes -- mat, yoga blocks<br />
<br />
I�ve been doing Yoga for over 20 years and granted I do like the more vigorous yoga styles but I�m usually a snob when someone not completely life-dedicated to yoga teaches yoga (how I get off thinking that �I don�t know).  That said, I really liked this practice and Tony stayed true to himself and did a terrific job.  <br />
<br />
Legs & Back -- 59 minutes -- dumbbells or bands, pull up bar or bands, chair<br />
<br />
This reminded me of a harder Legs& Glutes from Cathe.  And with pull-ups mixed in.  I was sore!<br />
<br />
Kenpo -- 59 minutes -- heart rate monitor<br />
<br />
This was similar to KP&C � I don�t do a ton of kickboxing � but less choreographed.  It was fun and tough. <br />
<br />
Stretch -- 58 minutes -- mat, yoga blocks<br />
<br />
Nice stretch routine � harder than Cool It Off<br />
<br />
Core Synergistics -- 58 minutes -- mat, weights, and a plastic plate, cardboard or towel<br />
<br />
This is a TLP like workout but again less choreographed. <br />
<br />
Chest, Shoulders, & Triceps -- 56 minutes -- dumbbells or bands, push up bars, chair, and a plastic plate, cardboard or towel<br />
<br />
Killer � 3 exercises � 3 body parts � over and over again � changing the exercises each time.  <br />
<br />
Back & Biceps -- 52 minutes -- dumbbells or bands, pull up bar or bands, chair<br />
<br />
Again � very tough � 2 back exercises, 2 bicep, over and over again. <br />
<br />
Cardio -- 44 minutes -- chair, mat, yoga blocks<br />
<br />
A shorter rehash of moves from YogaX, Plyo, Core, and Kenpo � but this is new footage � it isn�t a cut and paste of other footage. Nice routine for a shorter add-on of cardio. <br />
<br />
Ab Ripper -- 16 minutes � mat<br />
<br />
Wow! � A great tough ab routine.  <br />
<br />
I�m glad that I have this set � it gives me the variety I�ve been wanting and I enjoy have a new instructor.  These workouts are very well designed and I strongly recommend them to intermediate or advanced exercisers.  <br />
<br />
The classic rotation has not as much cardio as I would like so they have other rotations that include more cardio � that is the one I used.  <br />

<P><B>Instructor comments: </B>

Tony is an excellent motivator and instructor.  
			
<P><I>Christine Miyachi</I><BR>
cmiyachi@alum.mit.edu<br>
4/4/04
<p><img src="/images/hr.gif"><p>


I thought that I would first write a review based on the concept of the P90X Upper Body Weight Lifting program, which include 1) chest and back 2) shoulders and arms 3) back and biceps 4) chest, shoulders and triceps, because I would like to underscore the uniqueness of these breakthrough workouts as a whole. <br />
<br />
OVERVIEW<br />
Endurance weight lifting video workouts seemed to be long-lasting trend, but finally P90X broke that barrier and introduced a series that is not afraid to lift heavy but also kept endurance-based exercises in the mix. By leaving adequate room for breaks, the exerciser can lift for endurance by maximizing from 12-16 reps. In fact, there is always someone in the crew lifting for endurance so you don�t feel left out if you opt for this route. Also, much of the chest and back work in P90X is completely endurance based as you are encouraged to pump out as many reps as possible. Without limiting the exerciser to a specific rep count, this allows one to lift according to their goals and thus, maximize their potential. This perhaps is the underlying reason why P90X has garnered plaudits from the VF community.<br />
<br />
DIFFICULTY<br />
Weight lifting is always customizable to the user so I guess two questions come into play: Can a beginner do this and is there potential for growth? I do not think that the P90X strength training system is appropriate for beginners to weight lifting for several reasons: 1) You are concentrating on isolated muscle groups for long periods of time. 2) Many of the exercises come with innovative twists and it is more important to master form on their more traditional counterparts first to reduce risk of injury. 3) The athletic performance of the crew might discourage a beginner or encourage them to work beyond their limits. <br />
<br />
When I started P90X I would rate myself as a solid intermediate and I was thoroughly challenged but a bit discouraged as I was lagging behind the crew�s performance. But with each session I was gaining confidence, and performing better. I could not believe how much I improved in so little time but even after 90 days, I still knew that there was a lot of room for improvement. For example, I still can�t complete that brutal pushup segment in Chest, Shoulders and Triceps. To sum it up, P90X has exposed me to the most thorough and difficult strength routines and for this reason, there is plenty of room for growth.<br />
<br />
FUN FACTOR<br />
There is so much going on with each workout � some tried and true traditional weight lifting exercises and some that are semi-traditional. The sequencing of exercises, which involves switching between two or three muscle groups throughout the workout (example: one chest exercise followed by one shoulder, then one triceps exercise) allows for a more engaging routine because the next exercise is always something entirely different.<br />
<br />
What initially brought on an onslaught of dread, turned out to be exercises that I can no longer ignore � yes they are the commonly detested pushups and pull-ups. Without P90X I would have never been able to do a pull-up and probably never be able to do pushups on my toes. In P90X, a multitude of pushup and pull-up possibilities are demonstrated so you are not doing the same old standard exercise over and over again. Not only will you be able to pump out more reps with this program, but you won�t be dreading it either. Hey, I will admit that pushups and pull-ups will never be fun but they are a lot more appealing now. And getting that chin above the bar elicits such an empowering feeling: it is well worth the effort.<br />
<br />
TRACKING YOUR RESULTS<br />
The reason why so many people are successful with their strength gains when doing P90X is beyond its outstanding weight lifting routines. It is because Tony focuses your attention on the elements that matter: realizing a goal (strength or endurance will determine your rep range goal), knowing what poundage will deliver a burn in your rep range and executing proper form. So in other words, you are you � it doesn�t matter how much the instructor is lifting and for how long. What matters is how much weight you can handle in your rep range goal that will bring you to muscle fatigue. So why should an instructor specify your rep count if they don�t know your potential?<br />
<br />
By recording your numbers, not only will you know your current limit but you will also know when you reach the finish line. Once you max out your rep range it is time to start a new race � one with a slightly heavier weight. The beauty of P90X is that it facilitates the process of allowing you to focus on yourself as the sole competitor. The reasons are simple and brilliant: 1) Tony does not ever count off the full number of reps. 2) Everyone is lifting according to their own goals instead of following Tony. 3) Tony isn�t instructing the entire time anyway but going to each crew member to comment on their form and give you tips. 4) The camera never focuses on a single person and shifts around to discourage you from following someone too.<br />
<br />
LASTING APPEAL<br />
The most striking aspect of the P90X series is the lasting appeal � these are workouts that you can reach for over and over again because of their challenge, uniqueness, variety, versatility and brutal enjoyment. The organization of exercises and detailed chaptering allow you to easily skip chapters so that you can make your own P90X routines. For example by skipping the second set of exercises or by doing the first or latter half of the workouts, you can easily mix and match a multitude of possibilities. For these reasons, I will be reaching for my P90X strength routines way beyond its 90 day commitment. 
<P><B>Instructor comments: </B>

I could not ask for a better fitness trainer and coach. It feels like Tony is making sure that you and the crew are always doing it right. He is also pushing you to work hard by exhibiting his own struggle and pointing out the effort of the crew. Tony goes beyond instructing: he is humorous, competitive and fun to work out with. 
			
<P><I>Celes</I><BR>
<br>
September 9, 2004
<p><img src="/images/hr.gif"><p>

This is one of the best fitness purchases and I have ever made.  I am not into the P90X rotation and prefer different cardio, so I did not keep all of the videos.  But I was able to sell off the workouts I didn�t want to keep and ended up with 8 great workouts for less than $50.  <br />
<br />
The set is made up of: <br />
 * Ab Ripper X (I don�t love it because it is hard on the hip flexors, but great workout.) <br />
 * Back and Biceps <br />
 * Cardio X (An easier cardio workout that I didn�t keep) <br />
 * Chest and Back<br />
 * Chest Shoulders and Triceps <br />
 * Core Synergistics (One of my favorite strength workouts ever, that works a little of everything) <br />
 * Kenpo X (Kickboxing, I didn�t keep this one) <br />
 * Legs and Back (A great leg workout with functional moves.  I always skip the back work.) <br />
 * Plyometrics X (A very nice interval workout using good plyometric moves.) <br />
 * Shoulders and Arms <br />
 * Stretch X (A nice stretch workout that allows you to pick and choose your stretches) <br />
 * Yoga X (A 90 minute yoga workout that looked great, but I didn�t keep because of its length.) <br />
<br />
FYI, Ab Ripper X is found on all the upper body strength workouts.  <br />
<br />
There are several things I love about these workouts.  <br />
<br />
1) The sequencing of the upper body work.  I appreciate the cycling through the body parts, instead of just working one part to exhaustion, as Cathe does in most of her strength workouts.  For example you do Shoulders, Biceps, Triceps, Shoulders, Biceps, Triceps, etc.   This allows you to lift a little heavier and it is less boring to me. <br />
<br />
2) The functional fitness aspects of the leg and core work.  Tony understands that it is not just about lifting heavy and there are lots of exercises in at least a few of these workouts, that will work your body in different planes and with functional movements.  I am a fan of functional fitness, so I appreciate being able to work on this at the same time as you are building strength. <br />
<br />
3) Pushups!  I used to hate pushups, but I have grown to love them with the variations that Tony has in this workout.   I can do a few more every time I do this workout, and that is very motivating. <br />
<br />
4) Good stretching in all of the workouts. <br />
<br />
5) The trademark Beachbody Timer, and excellent chapter points.  You can skip exercises very easily (which I do often!) <br />
<br />
6) Tony�s reminders to write things down (and the time to do so) are very helpful. <br />
<br />
There are also a few things I don�t love so much about these workouts.  <br />
 <br />
1) The same old boring warm-up over and over.  <br />
<br />
2) The heavy focus on back and the reliance on pull-ups, which are still out of reach for me.  Even if I had the strength, I don�t have the space in my basement to do them.  The bands work OK, but I wish there was more variety in back work. <br />
<br />
3) The length of the upper body workouts are too long for me.  However, this is easily handled with skipping some sets.  I can build strength doing just half of the upper body workouts, so that is what I do.  It works well, and I have time for some cardio then. <br />
<br />
4) Tony is a bit of a show-off  - grabbing heavy weights, and then stopping early to give form pointers.  Although he does re-endear himself to me at one point when he admits that he wouldn�t have been able to finish the set with his original weight. <br />
<br />
I�m really neutral on the music and the set.  Everyone raved about these factors when these workouts were first released, but I find the music pretty repetitive and boring.  The set is fine and works well for these workouts.  <br />
<br />
Overall, this set is a great value, even if you can�t sell off some of the workouts like I have.  Although the workouts come with a very effective rotation that many people have had great results with, you do not need to do the workouts as is, to get good use from these workouts.  If you want to build strength, I highly recommend these workouts.  
<P><B>Instructor comments: </B>

You can�t have a review of a Tony Horton workout, without making some instructor comments.  When I first purchased these workouts, I previewed them, and I hated Tony.  I was afraid I could not enjoy the workouts, because I found his mannerisms so annoying.  For example saying �my brother� quite frequently, and his goofy way of counting down �5,4....,3,2...1".   I also found his tendency to pick heavy weights and then stopping early (as I mentioned above) to also be extremely annoying.  I also found his look to be a little disturbing, because I think he has too much makeup on.   <br />
<br />
However, when I do these workouts, I don�t notice those things as much.  And, I could even say now that I kind of like Tony.  He is extremely encouraging and will push you to do things you didn�t think you could do.  He has great form pointers and he clearly understands the importance of working in a functional way.  He is not just about building big muscles.   So, I would recommend holding judgement on Tony until you actually do the workouts.  I don�t think I�m the first one who has changed their opinion of him over time. 
			
<P><I>Lisa C</I><BR>
<br>
08/22/06
<p><img src="/images/hr.gif"><p>


			
<br><p align=center>
<SCRIPT LANGUAGE="JavaScript">
		function RevSelect(theForm2)
		{
			var val;
        
    	    val = theForm2.RevList.options[theForm2.RevList.selectedIndex].value;
        	if (val == 102) location = "/reviews/step.php";
        	if (val == 103) location = "/reviews/floor.php";
        	if (val == 104) location = "/reviews/strength.php";
        	if (val == 105) location = "/reviews/stryoga.php";
        	if (val == 106) location = "/reviews/slide.php";
        	if (val == 107) location = "/reviews/cycling.php";
        	if (val == 108) location = "/reviews/pregnant.php";
        	if (val == 109) location = "/reviews/box.php";
        	if (val == 110) location = "/reviews/kids.php";
        	if (val == 111) location = "/reviews/instructional.php";
        	if (val == 112) location = "/books/";
        	if (val == 113) location = "/reviews/";

		}
		</SCRIPT>
		<FORM NAME="SelectForm2">
		<SELECT NAME="RevList" onChange="RevSelect(this.form)">		
		<OPTION VALUE="HOME">[more reviews]
		<OPTION VALUE="113">Review Index
		<OPTION VALUE="102">Step Videos		
		<OPTION VALUE="103">Hi/Lo Floor Videos		
		<OPTION VALUE="104">Strength Videos
		<OPTION VALUE="109">Kickboxing/Martial Arts	
		<OPTION VALUE="105">Stretch/Yoga		
		<OPTION VALUE="106">Slide Videos		
		<OPTION VALUE="107">Indoor Cycling		
		<OPTION VALUE="108">Pregnancy Videos
		<OPTION VALUE="110">Kids Videos
		<OPTION VALUE="111">Instructional
		<OPTION VALUE="112">Book Reviews
		</SELECT></form> 
</div>
</td></tr></table>

<P>
<BR clear=left>
<center><font size="-2">Video Fitness copyright &copy; 1996 - 2009 Wendy Niemi Kremer &nbsp;&nbsp; All rights reserved</font><p><br></center></center></td></tr></table>
<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
</script>
<script type="text/javascript">
_uacct = "UA-921450-1";
urchinTracker();
</script>
</body></html>  