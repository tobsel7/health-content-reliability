
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<HTML lang="en">
<head>

<title>Map Of Alzheimer's Genes May Lead To Novel Therapies</title>
<meta name="description" content="Breakthrough genetic research to map all the genes connected to Alzheimer's, which could lead to more aggressive treatment and a potential cure for the disease, was the focus of a presentation by ">
<meta name="keywords" content="Alzheimer's / Dementia news, medical news, health news, medical headlines, healthcare news, health articles, medicine articles, welfare, living">
<META name="rating" content="general">
<META name="distribution" content="global">
<META name="revisit" content="7 days">
<META http-equiv="Pragma" content="no-cache">
<META http-equiv="Cache-Control" content="no-cache">
<META name="alias" content="http://www.medicalnewstoday.com">
<META http-equiv="bulletin-text" content="Copyright">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="shortcut icon" type="image/ico" href="/favicon.ico">
<link rel="alternate" type="application/rss+xml" title="Medical News Headlines RSS" href="http://www.medicalnewstoday.com/medicalnews.xml">


<style type="text/css">
<!--
@media all{
IE\:HOMEPAGE {behavior:url(#default#homepage)}
}
//-->
</style>

<style type="text/css" media="all">
	@import "/css/pagelayout.css";
	@import "/css/default.css";
	@import "/css/defaultnews.css";
</style>

<SCRIPT LANGUAGE="javascript" type="text/javascript">
<!--

function openpage(page) 
{
   mywin=window.open(page, "Window", "toolbar=yes,status=yes,menubar=yes,scrollbars=yes,resizable=yes,width=630,height=500");
}

// -->
</SCRIPT>

<SCRIPT LANGUAGE="javascript" type="text/javascript">
<!-- get out of frames and Change URL to Correct URL

if (top.frames.length!=0)
    top.location=self.document.location;

//-->
</SCRIPT>

<script language="JavaScript" src="/scripts/AntiSpambotMailto.js" type="text/javascript"></script>
<script type="text/javascript" src="/scripts/menu.js"></script>
<script language="JavaScript" src="/scripts/googleadcode.js" type="text/javascript"></script>

<!--script type="text/javascript">
// Script to resize page if resolution is less than 900 (for old versions of IE that don't like centering of website)
if (screen.width < 900)
	document.write('<link href="/css/pagelayout_800.css" rel="stylesheet" type="text/css">');
</script-->
</head>

<body bgcolor="#dddddd">
<a name="top"></a>

<div id="wrapper">

	<!-- Title Section -->
	
	<div id="title" class="robots-nocontent">
		<div id="headerback">

<div id="titleback">

<div style="position:absolute; top:0px; left:0px; z-index:1;">
<a href="/" title="back to homepage" rel="nofollow"><img src="/images/toplogo.jpg" width=118 height=69 alt="Medical News Today" border=0></a>
</div>


<table border="0" cellspacing="0" cellpadding="0" style="position:absolute; left:305px; height:69px;">
  <tr>
    <td width="10">&nbsp;</td>
    <td class="top-menu" align="right"><a href="/" accesskey="h" style="color:#FFFF00;" title="Health News Homepage">Health News</a></td>
    <td><img src="/images/menusep.gif" width=16 height=69 alt=""></td>
    
    <td width="10">&nbsp;</td>
    <td class="top-menu" align="right"><a href="/healthvideos.php" style="color:#FFFFFF;" title="Health Videos Section">Videos</a></td>
    <td><img src="/images/menusep.gif" width=16 height=69 alt=""></td>    

    <td width="10">&nbsp;</td>
    <td class="top-menu" align="right"><a href="/youropinions.php" style="color:#FFFFFF;" rel="nofollow"  title="Voice Your Opinion">Article Opinions</a></td>
    <td><img src="/images/menusep.gif" width=16 height=69 alt=""></td>  
    
    <td width="10">&nbsp;</td>
    <td class="top-menu" align="right"><a href="http://www.medicalhealthforum.com/medical-news-today/" style="color:#ffffff;" title="Visit Our Forum" target="_blank">Forum</a></td>
    <td><img src="/images/menusep.gif" width=16 height=69 alt=""></td>  

	<td width="10">&nbsp;</td>
    <td class="top-menu" align="right"><a href="/healthcareadvertising.php" accesskey="r" style="color:#FFFFFF;" rel="nofollow"  title="How to Advertise in Medical News Today">Advertise</a></td>
    <td><img src="/images/menusep.gif" width=16 height=69 alt=""></td>  

    <td width="10">&nbsp;</td>
    <td class="top-menu" align="right"><a href="/contactus.php" accesskey="c" style="color:#FFFFFF;" rel="nofollow"  title="Contact Us - Feedback">Contact</a></td>

    <td width="46">&nbsp;</td>
 </tr>
</table>

<div style="position:absolute; right:0px; top:20px;">
<a href="/index.php?page=newsfeed" title="Health News RSS Feeds"><img src="/images/rsslogo.gif" width=61 height=31 alt="Health News RSS Feeds" border="0"></a>
</div>

</div>

<div style="margin-left:50px;"><img src="/images/top3.jpg" width="396" height="66" alt=""></div>
<div id="searchback">

<!-- SiteSearch Google -->
<form name="topsearch" method="get" action="/newssearch2.php" style="margin-bottom:0px; margin-top:0px;" target="_top">

<table border=0 cellspacing=0 cellpadding=1 style="position:relative; top:14px;">
 <tr>
  <td style="font-size:11px; color:#000000;">

<input type="text" name="q" id="keyw" style="width:350px; height:18px; font-size:11px;" size="18">&nbsp;
  </td>
  <td><input type="submit" value="Search" class="submit" style="width:50px; height:18px; font-size:11px;"> &nbsp;&nbsp;</td>
  <td rowspan=2><img src="/images/googlelogo2.gif" width=64 height=31 alt="Search is Powered by Google"></td>
 </tr>
 <tr>
  <td colspan=2 >


<input type="radio" name="sitesearch" value="www.medicalnewstoday.com" class="radio" checked id="ss1"></input>
<label for="ss1" title="Search www.medicalnewstoday.com"><span style="font-size:11px;">News Archive [<a href="/newssearch.php" accesskey="s" rel="nofollow">link</a>]</span></label>
<input type="radio" name="sitesearch" value="" class="radio" id="ss0"></input>
<label for="ss0" title="Search the Web"><span style="font-size:11px;">Web</span></label>
<input type="radio" name="sitesearch" value="en.wikipedia.org" class="radio" id="ss2"></input>
<label for="ss2" title="Search Wikipedia"><span style="font-size:11px;">Wikipedia</span></label>
<input type="radio" name="sitesearch" value="www.medilexicon.com/medicaldictionary.php" class="radio" id="ss3"></input>
<label for="ss3" title="Search Medical Dictionary"><span style="font-size:11px;">Medical Dictionary [<a href="http://www.medilexicon.com" target="_blank" title="Medical dictionary - external website link">link</a>]</span></label>


<input type="hidden" name="channel" value="1651883988">
<input type="hidden" name="client" value="pub-1971793357249522">
<input type="hidden" name="forid" value="1">
<input type="hidden" name="ie" value="ISO-8859-1">
<input type="hidden" name="oe" value="ISO-8859-1">
<input type="hidden" name="flav" value="0000">
<input type="hidden" name="sig" value="vptscazCworEUP7D">
<input type="hidden" name="cof" value="GALT:#aaaaaa;GL:1;DIV:#FFFFFF;VLC:990099;AH:center;BGC:FFFFFF;LBGC:FFFFFF;ALC:0F3F9F;LC:0F3F9F;T:444444;GFNT:aaaaaa;GIMP:aaaaaa;FORID:11"></input>
<input type="hidden" name="hl" value="en">
<input type="hidden" name="domains" value="www.medicalnewstoday.com">
<input type="hidden" name="sa" value="Search">

  </td>
 </tr>
</table>
</form>
<!-- SiteSearch Google -->

</div>

</div>

<div id="title_right">
<span class="customtitle">Follow us on:</span><br>
<a href="/twitterhealthfeeds.php"><img src="/images/icons/twitter_header.gif" width="60" height="19" alt="Follow our health news on Twitter" border="0"></a><br>
<a href="http://apps.facebook.com/health-news/" target="_blank" rel="nofollow"><img src="/images/icons/facebook_header.gif" width="60" height="19" alt="Follow Our News on Facebook" border="0"></a>
</div>

<div id="login">

<span class="customtitle">Personalization</span><br><a href="/users/login.php" rel="nofollow">login</a> | <a href="/users/register.php" rel="nofollow">register</a>
</div>	</div>
	
	<div id="maincontent">
	
		<div align="center"><table border="0" width="100%" cellspacing="0" cellpadding="0">
			<tr>
<td valign="bottom"><div class="newstabbuttonactive">Alzheimer's / Dementia News</div></td>
<td valign="bottom"><div class="newstabbuttoninactive"><a href="/medicallinks.php?categoryid=3">Useful Links</a></div></td>
<td valign="bottom"><div class="newstabbuttoninactive"><a href="/sections/alzheimers/videos.php">Video Library</a></div></td>
</tr></table></div>
<img src="/images/transpixel.gif" width=1 height=5 alt=''><br>
<h1>Map Of Alzheimer's Genes May Lead To Novel Therapies</h1>

Main Category: <a href="/sections/alzheimers/">Alzheimer's / Dementia</a><br>
Also Included In: <a href="/sections/genetics/">Genetics</a><br>
Article Date: 30 Jul 2008 - 1:00 PDT<br><br>
<a href="/emailanarticle.php?newsid=116532"><img src="/images/icons/email.gif" width=14 height=14 border="0" alt="email icon" title="email"/> email to a friend</a> &nbsp; <a href="javascript:openpage('/printerfriendlynews.php?newsid=116532')"><img src="/images/icons/print.gif" width=14 height=14 border="0" alt="printer icon" title="print"/> printer friendly</a> &nbsp; <a href="116532.php#opinions"><img src="/images/icons/write.gif" width=14 height=14 border="0" alt="write icon" title="write"/> view / write opinions</a>
<!-- &nbsp; <a href="#ratethis"><img src="/images/icons/tick.gif" width=14 height=14 border="0" alt="rate icon" title="rate"/> rate article</a-->
<br>

<div class="articletopbox">
<!-- Begin Adify tag for "MediumRectangle" Ad Space (300x250) ID #8472607 -->
<script type="text/javascript">
sr_adspace_id = 8472607;
sr_adspace_width = 300;
sr_adspace_height = 250;
sr_ad_new_window = true;
sr_adspace_type = "graphic";
</script>
<script type="text/javascript" src="http://ad.afy11.net/srad.js?azId=8472607">
</script>
<!-- End Adify tag for "MediumRectangle" Ad Space (300x250) ID #8472607 --><br><br>

<div style="width:281px; text-align:left;  border: 1px solid #dddddd; margin-bottom:5px; padding:5px 5px 5px 12px; font-size:11px;">
<div style="text-align:left;"><b>Current Article Ratings: </b></div><br><table border=0 width='280' cellspacing=0 cellpadding=0>
<tr>
<td width="43%" style="font-size:12px; color:#009900;"><strong>Patient / Public:</strong></td><td width="85"><img src="/images/rater/notyetrated.gif" id="publicnotyetrated" alt="not yet rated"></td>
<td width="75" style="padding-left:2px"><p style="font-size:10px" id="avgpublicrating_raterstarserver"></p></td></tr><tr>
<td width="43%" style="font-size:12px; color:#CC0000"><strong>Health Professional:</strong></td><td width="80"><img src="/images/rater/3stars.gif" id="hcpstars" alt="3 stars"></td>
<td width="75" style="padding-left:2px"><p style="font-size:10px" id="avghcprating_raterstarserver">3 (1 votes)</p></td></tr>
<tr><td>Article Opinions:</td><td>&nbsp;<a href='/articles/116532.php#opinions' rel='nofollow'>0 posts</a></td></tr>
</table>
</div>



</div><br>Breakthrough genetic research to map all the genes connected to Alzheimer's, which could lead to more aggressive treatment and a potential cure for the disease, was the focus of a presentation by leading Alzheimer's researcher Dr. Rudolph Tanzi at the International Conference on Alzheimer's Disease (ICAD) in Chicago. <br><br>
Tanzi, Chairman of the Cure Alzheimer's Fund Research Consortium and the Joseph and Rose Kennedy Professor of Neurology at Harvard Medical School, was one of eight featured speakers discussing the genetic factors of <a href="/articles/159442.php" title="What Is Alzheimer's Disease? What Causes Alzheimer's Disease?">Alzheimer's disease</a> as part of ICAD. Tanzi discussed his work on the "Alzheimer's Genome Project" (AGP), identifying all of the genes that work individually or together to influence one's risk of Alzheimer's disease. A paper on AGP is currently under peer review at a prestigious science journal. <br><br>
"With the innovative developments in genetic technology, completion of the human genome project and the advances in statistical analyses, we are on the cusp of a rare 'science moment' that should greatly accelerate our efforts to treat and prevent Alzheimer's disease," Dr. Tanzi told conference attendees. "Every new Alzheimer's gene we identify provides clues to the cause of this dreadful disease. The knowledge gained from the Alzheimer's-associated defects in these genes should guide the development of novel therapeutics." <br><br>
Tanzi highlighted two specific areas of the AGP, funded by the Cure Alzheimer's Fund. The genome-wide association screen is the largest such family-based screen ever conducted. Tanzi and his team collected genetic data from more than 1,300 families affected by Alzheimer's disease to determine gene variants that influence one's lifetime risk of Alzheimer's. His presentation will cover a 'novel' gene, one of the top genetic hits for Alzheimer's emerging from that screen. <br><br>
In addition, Tanzi discussed AlzGene, a publicly available web database (<a href="http://alzgene.org" target="_blank" rel="nofollow">http://alzgene.org</a>) for researchers working to uncover the genetic underpinnings of Alzheimer's disease. Spearheaded by Dr. Tanzi's colleague, Lars Bertram, Assistant Professor of Neurology at MGH, AlzGene provides a comprehensive and systematic display of all published Alzheimer's genetics research over the past 30 years. In addition, through analysis of the collective genetic data, Tanzi and Bertram have determined 30 genes that increase one's lifetime risk for Alzheimer's as well as others that protect against it. Their overarching goal is to combine the results of the AlzGene project and the genome-wide association screen to ultimately identify all the genes that significantly influence one's lifetime genetic risk for Alzheimer's disease. The first set of breakthroughs in this project will be presented by Dr. Tanzi at ICAD. <br><br>
"Research findings in the past year alone have generated tremendous excitement in the field of neuroscience, genetics and especially in Alzheimer's research," said Tanzi. "Ultimately, the combined results of the family-based genome-wide screen and AlzGene should allow for the reliable prediction of Alzheimer's disease while also guiding the development of novel therapies. These studies will someday lead to the development of therapies aimed at treating and preventing Alzheimer's according to one's personal genome." <br><br>
Cure Alzheimer's Fund&trade; is a 501c3 public charity established to fund targeted research with the highest probability of slowing, stopping or reversing Alzheimer's disease. <br><br><a href="http://www.curealzfund.org" target="_blank" rel="nofollow">Cure Alzheimer's Fund</a>
<a name="ratethis"></a>
<br clear="all"><br>


<script type="text/javascript" src="/rater/rater.js"></script>
    <div>
    	<div align="left" id="txtHint"></div>
    </div>
    
	<script type="text/javascript">document.write('<form style="margin-bottom:0px;" id="ratings_form">');</script>
	<noscript><form method="post" action="#ratethis" style="margin-bottom:0px;"></noscript>

<div style="border-top:solid thin #eeeeee; padding:5px 0 5px 0;">

<table cellpadding="0" cellspacing="0" border="0">
	<tr>   
    	<td width="160" valign="top">
        	<strong>Please rate this article:</strong><br>
            (Hover over the stars<br> 
            then click to rate)
        </td>

         <td width="95" valign="top" style="font-size:12px; color:#009900;">
			<strong>Patient / Public:</strong><br>      
        
        <script type="text/javascript">document.write('<ul class="starrating unrated" style="margin-bottom:0;"><li class="onestar"><a href="javascript:rate(\'public\',1);" ondblclick="return false;" title="1 star - not interesting">1</a></li><li class="twostar"><a href="javascript:rate(\'public\',2); " ondblclick="return false;" title="2 stars">2</a></li><li class="threestar"><a href="javascript:rate(\'public\',3);" ondblclick="return false;" title="3 stars">3</a></li><li class="fourstar"><a href="javascript:rate(\'public\',4);" ondblclick="return false;" title="4 stars">4</a></li><li class="fivestar"><a href="javascript:rate(\'public\',5);" ondblclick="return false;" title="5 stars - very interesting">5</a></li></ul>');
		</script>      
            
		</td>
        <td width="45" valign="top" align="center" style="font-size:12px;"><b>or</b></td>
		<td width="160" valign="top" style="font-size:12px; color:#CC0000">
        	<strong>Health Professional:</strong><br>
            
        	<script type="text/javascript">document.write('<ul class="starrating unrated" style="margin-bottom:0;"><li class="onestar"><a href="javascript:rate(\'hcp\',1);" ondblclick="return false;" title="1 star - not interesting">1</a></li><li class="twostar"><a href="javascript:rate(\'hcp\',2);" ondblclick="return false;" title="2 stars">2</a></li><li class="threestar"><a href="javascript:rate(\'hcp\',3);" ondblclick="return false;" title="3 stars">3</a></li><li class="fourstar"><a href="javascript:rate(\'hcp\',4);" ondblclick="return false;" title="4 stars">4</a></li><li class="fivestar"><a href="javascript:rate(\'hcp\',5);" ondblclick="return false;" title="5 stars - very interesting">5</a></li></ul>');  
			</script>             
            
         </td>     
	</tr>
</table>
</div>

    <input type="hidden" id="newsid" name="newsid" value="116532">
	<input type="hidden" id="categoryid" name="categoryid" value="3">
	</form>

    
<div style="left:5px; color:#339900; font-weight:bold;" id="opinion_area" align="left"></div>
<div style="margin-top:15px;">

<!-- Used at bottom of sections, same code as article bottom --><script language="JavaScript"><!--google_ad_client = 'pub-1971793357249522';//2007-07-20: Medical News 300x250 Bottom, MNT - Alzheimer's / Dementia
google_ad_channel = "5828687880+1842996401";
google_max_num_ads = '3';google_ad_type = 'text,image,flash,html';google_ad_output = 'js';google_image_size = '300x250';google_feedback = 'on';google_adtest = 'off';// --></script><script language="JavaScript" src="http://pagead2.googlesyndication.com/pagead/show_ads.js"></script> 
</div>

<hr size="1">

<div>

<div style="width:200px; position:relative; float:right; font-size:12px; margin-left:10px;">
 <!-- AddThis Button BEGIN -->
<script type="text/javascript">addthis_pub  = 'medi32';</script>
<a href="http://www.addthis.com/bookmark.php?v=20" onmouseover="return addthis_open(this, '', '[URL]', '[TITLE]')" onmouseout="addthis_close()" onclick="return addthis_sendto()"><img src="http://s7.addthis.com/static/btn/lg-share-en.gif" width="125" height="16" alt="Bookmark and Share" style="border:0"/></a><script type="text/javascript" src="http://s7.addthis.com/js/200/addthis_widget.js">
</script>
<!-- AddThis Button END -->

<br><br>
<p>
<strong>Note</strong>: Any medical information published on this website is not intended as a substitute for informed medical advice and you should not take any action before consulting with a health care 
professional. For more information, please read our <a href="/index.php?page=termsandconditions&amp;title=Terms+and+Conditions" rel="nofollow">terms and conditions</a>.
</p>
</div>

<a href="/twitterhealthfeeds.php"><img src="/images/icons/twittericon_articlebottom.gif" width=14 height=14 border="0" alt="twitter icon" style="margin-top:3px;">&nbsp; Follow us on Twitter</a><br>
<a href="/sections/alzheimers/" rel="nofollow"><img src="/images/icons/icon2.gif" width=14 height=14 border="0" alt="news icon" style="margin-top:3px;">&nbsp; Alzheimer's / Dementia headlines</a><br>
<a href="javascript:openpage('/emailanarticle.php?newsid=116532')" rel="nofollow"><img src="/images/icons/email.gif" width=14 height=14 border="0" alt="email icon" title="email" style="margin-top:3px;">&nbsp; email to a friend</a><br>
<a href="javascript:openpage('/printerfriendlynews.php?newsid=116532')" rel="nofollow"><img src="/images/icons/print.gif" width=14 height=14 border="0" alt="printer icon" title="print" style="margin-top:3px;">&nbsp; printer friendly version</a><br>
<a href="/newsletters.php" rel="nofollow"><img src="/images/icons/newsletter2.gif" width=14 height=14 border="0" alt="newsletter icon" style="margin-top:3px;">&nbsp; weekly newsletter</a><br>
<a href="/customizedhealthnews.php" rel="nofollow"><img src="/images/icons/rate2.gif" width=14 height=14 border="0" alt="star icon" style="margin-top:3px;">&nbsp; personalize your news</a><br>
<a href="/index.php?page=newsfeed" rel="nofollow"><img src="/images/icons/rss.gif" width=14 height=14 border="0" alt="rss icon" style="margin-top:3px;">&nbsp; rss feeds</a>
<br><br>
<a href="#top" rel="nofollow"><img src="/images/icons/top.gif" width=14 height=14 border="0" alt="back to top - icon" style="margin-top:3px;">&nbsp; back to top</a>


</div>

<hr size="1">

<a name="opinions"><a name="post"><h1>Add Your Opinion</h1><p><b>All opinions are moderated before being added.</b></p>
	  <p>Please note that <b>we publish your name</b>, but we <b>do not publish</b> your email address. It is only used to let 
	  you know when your message is published. We do not use it for any other purpose. Please see our <a href="/index.php?page=privacypolicy">privacy policy</a> for more information.</p>
	  <p>If you write about specific medications or operations, please <b>do not</b> name health care professionals by name.
	  </p><div class="opinion-commentform">
  <form name="xfrm" method=post action="116532.php#post">
  <table border=0 width="450" cellspacing=0 cellpadding=5>
   <tr>
    <td width='130' style="padding-left:0px;">Your Name:*</td>
    <td><input type=text name="formName" size=25 value=""></td>
   </tr>
   <tr>
    <td style="padding-left:0px;">E-mail Address:*</td>
    <td><input type=text name="formEmail" size=25 value=""></td>
   </tr>
   <tr>
    <td style="padding-left:0px;">Title For Opinion:*</td>
    <td><input type=text name="formTitle" size=40 value=""></td>
   </tr>
   <tr>
    <td style="padding-left:0px;">Opinion:*</td>
   </tr>
   <tr>
    <td colspan=2 style="padding-left:0px;"><textarea name="formOpinion" rows=8 cols=55></textarea></td>
   </tr>
   <tr>
    <td style="padding-left:0px;">
		This is to help prevent SPAM submissions. Please enter the words exactly as they appear, including capital letters and punctuation.*
	  </td>
   <td><script type="text/javascript" src="http://api.recaptcha.net/challenge?k=6LcEVAcAAAAAANFISQ6h2ugNtIj6KzLNeza3ibFu"></script>

	<noscript>
  		<iframe src="http://api.recaptcha.net/noscript?k=6LcEVAcAAAAAANFISQ6h2ugNtIj6KzLNeza3ibFu" height="300" width="500" frameborder="0"></iframe><br/>
  		<textarea name="recaptcha_challenge_field" rows="3" cols="40"></textarea>
  		<input type="hidden" name="recaptcha_response_field" value="manual_challenge"/>
	</noscript></td>
   </tr>
   <tr>
    <td></td>
	<td><input type=submit value="Submit!"></td>
   </tr>
  </table>
  <p>* Fields marked with a * need to be filled in before you hit the submit button.</p>

<input type=hidden name=associatednewsid value='116532'>
</form>
</div>

<p>
<b>Contact Our News Editors</b>
</p>
<p>
For any corrections of factual information, or to contact the editors please use our <a href="/index.php?page=feedback&amp;title=Feedback" rel="nofollow">feedback form</a>.<br>
<img src="/images/transpixel.gif" width="1" height="5" alt=""><br>
Please send any medical news or health news press releases to:
<script type="text/javascript">AntiSpambotMailto('145|147|134|148|148|147|134|141|134|130|148|134|97|142|134|133|138|132|130|141|143|134|152|148|149|144|133|130|154|79|132|144|142')</script>
</p>
<br>
<div align="center">

<table border="0" width="97%" cellspacing="2" cellpadding="5">
 <tr>
  <td bgcolor="#f4f4ff" class="box" width="30%" align="center"><a href="#top" rel="nofollow">Back to top</a></td>
  <td bgcolor="#f4f4ff" class="box" width="30%" align="center"><a href="http://www.medicalnewstoday.com">Back to front page</a></td>
  <td bgcolor="#f4f4ff" class="box" width="40%" align="center"><a href="/allarticles.php">List of All Medical Articles</a></td>
 </tr>
</table>

<br><img src="/images/blanktab.gif" width="1" height="5" alt=""><br>

<table border="0" class="box" width="96%" cellspacing="0" cellpadding="5">
 <tr>
  <td width="20%" align="center" bgcolor="#f4f4ff"><a href="/index.php?page=privacypolicy&amp;title=Privacy+Policy" rel="nofollow">Privacy Policy</a></td>
  <td width="30%" align="center" bgcolor="#f4f4ff"><a href="/index.php?page=termsandconditions&amp;title=Terms+and+Conditions" rel="nofollow">Terms and Conditions</a></td>
  <td width="50%" align="center" bgcolor="#f4f4ff">&copy; 2010 <a href="http://www.medilexicon.org" target="_blank" rel="nofollow">MediLexicon International Ltd</a></td>
 </tr>
</table>

</div><br clear="all">
	
	</div>
	
	<div id="titlebannernew"><!-- Begin Adify tag for "Leaderboard" Ad Space (728x90) ID #8472807 -->
<script type="text/javascript">
sr_adspace_id = 8472807;
sr_adspace_width = 728;
sr_adspace_height = 90;
sr_ad_new_window = true;
sr_adspace_type = "graphic";
</script>
<script type="text/javascript" src="http://ad.afy11.net/srad.js?azId=8472807">
</script>
<!-- End Adify tag for "Leaderboard" Ad Space (728x90) ID #8472807 --><br><br>

</div>	
	<div id="leftmenu" class="robots-nocontent">
		
<div style="margin-top:2px;">
<div class="menutitle">News Category Menu</div>  
</div>

<div id="menu">

<ul>
<li><a href="/sections/alzheimers/" style='background-color: #ffff99; border-left:1px solid #999999; border-bottom:1px solid #999999; padding-top:5px; padding-bottom:5px;'>Alzheimer's / Dementia</a></li>
</ul>


<ul>
 <li><a href="/index.php?page=newssections#A" class="x" rel="nofollow"><div class="menuarrows">&gt;</div>Categories A-B</a>
 
 <ul>
 <li><a href="/sections/abortion/" class="z" style="border-top:1px solid #999999;">Abortion</a></li>
 <li><a href="/sections/gerd/" class="z">Acid Reflux / GERD</a></li>
 <li><a href="/sections/adhd/" class="z">ADHD</a></li>
 <li><a href="/sections/aid-disasters/" class="z">Aid / Disasters</a></li>

 <li><a href="/sections/alcohol/" class="z">Alcohol / Addiction / Illegal Drugs</a></li>
 <li><a href="/sections/allergy/" class="z">Allergy</a></li>
 <li><a href="/sections/complementary_medicine/" class="z">Alternative Medicine</a></li>
 <li><a href="/sections/alzheimers/" class="z">Alzheimer's / Dementia</a></li>
 <li><a href="/sections/anxiety/" class="z">Anxiety / Stress</a></li>
 <li><a href="/sections/arthritis/" class="z">Arthritis / Rheumatology</a></li>
 
 <li><a href="/sections/asbestos/" class="z">Asbestos / Mesothelioma</a></li>
 <li><a href="/sections/asthma-respiratory/" class="z">Asthma</a></li>
 <li><a href="/sections/autism/" class="z">Autism</a></li>
 <li><a href="/sections/back-pain/" class="z">Back Pain</a></li>
 <li><a href="/sections/bioterrorism/" class="z">Bio-terrorism / Terrorism</a></li>
 <li><a href="/sections/biology-biochemistry/" class="z">Biology / Biochemistry</a></li>

 <li><a href="/sections/bipolar/" class="z">Bipolar</a></li>
 <li><a href="/sections/birdflu/" class="z">Bird Flu / Avian Flu</a></li>
 <li><a href="/sections/blood/" class="z">Blood / Hematology</a></li>
 <li><a href="/sections/bodyaches/" class="z">Body Aches</a></li>
 <li><a href="/sections/bones/" class="z">Bones / Orthopaedics</a></li>
 <li><a href="/sections/breast_cancer/" class="z">Breast Cancer</a></li>
 
 </ul>

 </li>
</ul>

<ul>
 <li><a href="/index.php?page=newssections#C" class="x" rel="nofollow"><div class="menuarrows">&gt;</div>Categories C-D</a>
 
 <ul class="sub2">
 <li><a href="/sections/cancer-oncology/" class="z" style="border-top:1px solid #999999;">Cancer / Oncology</a></li>
 <li><a href="/sections/cardiovascular/" class="z">Cardiovascular / Cardiology</a></li>
 <li><a href="/sections/caregivers/" class="z">Caregivers / Homecare</a></li>

 <li><a href="/sections/cervical_cancer/" class="z">Cervical Cancer / HPV Vaccine</a></li>
 <li><a href="/sections/cholesterol/" class="z">Cholesterol</a></li>
 <li><a href="/sections/cjd-vcjd/" class="z">CJD / vCJD / Mad Cow Disease</a></li>
 <li><a href="/sections/cleft_palate/" class="z">Cleft Palate</a></li>
 <li><a href="/sections/clinical_trials/" class="z">Clinical Trials / Drug Trials</a></li>
 <li><a href="/sections/colorectal_cancer/" class="z">Colorectal Cancer</a></li>
 <li><a href="/sections/complementary_medicine/" class="z">Complementary Medicine</a></li>
 <li><a href="/sections/compliance/" class="z">Compliance</a></li>
 <li><a href="/sections/conferences/" class="z">Conferences</a></li>
 <li><a href="/sections/copd/" class="z">COPD</a></li>
 <li><a href="/sections/cosmetic_medicine/" class="z">Cosmetic Medicine</a></li>
 <li><a href="/sections/crohns/" class="z">Crohn's</a></li>

 <li><a href="/sections/cystic_fibrosis/" class="z">Cystic Fibrosis</a></li>
 <li><a href="/sections/dentistry/" class="z">Dentistry</a></li>
 <li><a href="/sections/depression/" class="z">Depression</a></li>
 <li><a href="/sections/dermatology/" class="z">Dermatology</a></li>
 <li><a href="/sections/diabetes/" class="z">Diabetes</a></li>
 <li><a href="/sections/dyslexia/" class="z">Dyslexia</a></li>
 
 </ul>

 </li>
</ul>

<ul>
 <li><a href="/index.php?page=newssections#E" class="x" rel="nofollow"><div class="menuarrows">&gt;</div>Categories E-G</a>
 
 <ul class="sub3">
 <li><a href="/sections/ent/" class="z" style="border-top:1px solid #999999;">Ear, Nose and Throat</a></li>
 <li><a href="/sections/eatingdisorders/" class="z">Eating Disorders</a></li>
 <li><a href="/sections/eczema-psoriasis/" class="z">Eczema / Psoriasis</a></li>
 <li><a href="/sections/endocrinology/" class="z">Endocrinology</a></li>
 <li><a href="/sections/epilepsy/" class="z">Epilepsy</a></li>

 <li><a href="/sections/erectile_dysfunction/" class="z">Erectile Dysfunction</a></li>
 <li><a href="/sections/eye_health/" class="z">Eye Health / Blindness</a></li>
 <li><a href="/sections/fertility/" class="z">Fertility</a></li>
  <li><a href="/sections/fibromyalgia/" class="z">Fibromyalgia</a></li>
 <li><a href="/sections/flu-sars/" class="z">Flu / Cold / SARS</a></li>
 
 <li><a href="/sections/gastrointestinal/" class="z">GastroIntestinal / Gastroenterology</a></li>
 <li><a href="/sections/genetics/" class="z">Genetics</a></li>
 <li><a href="/sections/gout/" class="z">Gout</a></li>
 <li><a href="/sections/womens_health/" class="z">Gynecology</a></li>
 
 </ul>

 </li>
</ul>
 
<ul>
 <li><a href="/index.php?page=newssections#H" class="x" rel="nofollow"><div class="menuarrows">&gt;</div>Categories H-L</a>
 
 <ul class="sub4"> 
 <li><a href="/sections/headache-migraine/" class="z" style="border-top:1px solid #999999;">Headache / Migraine</a></li>
 <li><a href="/sections/health_insurance/" class="z">Health Insurance / Medical Insurance</a></li>

 <li><a href="/sections/hearing-deafness/" class="z">Hearing / Deafness</a></li>
 <li><a href="/sections/heart-disease/" class="z">Heart Disease</a></li>
 <li><a href="/sections/hiv-aids/" class="z">HIV / AIDS</a></li>
 <li><a href="/sections/huntingtons_disease/" class="z">Huntingtons Disease</a></li>
 <li><a href="/sections/hypertension/" class="z">Hypertension</a></li>
 
 <li><a href="/sections/immune_system/" class="z">Immune System / Vaccines</a></li>
 <li><a href="/sections/infectious_diseases/" class="z">Infectious Diseases</a></li>
 <li><a href="/sections/crohns/" class="z">Inflammatory Bowel Disease</a></li>
 <li><a href="/sections/ibs/" class="z">Irritable Bowel Syndrome</a></li>
 <li><a href="/sections/it/" class="z">IT / Internet / E-mail</a></li>
 <li><a href="/sections/medical_malpractice/" class="z">Litigation</a></li>
 <li><a href="/sections/liver_disease/" class="z">Liver Disease / Hepatitis</a></li>

 <li><a href="/sections/lung_cancer/" class="z">Lung Cancer</a></li>
 <li><a href="/sections/lupus/" class="z">Lupus</a></li>
 <li><a href="/sections/lymphology/" class="z">Lymphology / Lymphedema</a></li>
 <li><a href="/sections/lymphoma-leukemia/" class="z">Lymphoma / Leukemia</a></li>
 </ul>

 </li>
</ul>
 
<ul>
 <li><a href="/index.php?page=newssections#M" class="x" rel="nofollow"><div class="menuarrows">&gt;</div>Categories M-O</a>
 
 <ul class="sub5">
 
 <li><a href="/sections/medical_devices/" class="z" style="border-top:1px solid #999999;">Medical Devices / Diagnostics</a></li>
 <li><a href="/sections/medical_malpractice/" class="z">Medical Malpractice</a></li>
 <li><a href="/sections/medical_practice/" class="z">Medical Practice Management</a></li>
 <li><a href="/sections/medical_students/" class="z">Medical Students / Training</a></li>
 <li><a href="/sections/medicare-medicaid/" class="z">Medicare / Medicaid / SCHIP</a></li>
 <li><a href="/sections/melanoma/" class="z">Melanoma / Skin Cancer</a></li>
 <li><a href="/sections/mens_health/" class="z">Men's Health</a></li>
 <li><a href="/sections/menopause/" class="z">Menopause</a></li> 
 <li><a href="/sections/mental_health/" class="z">Mental Health</a></li> 

 <li><a href="/sections/mri-pet/" class="z">MRI / PET / Ultrasound</a></li>
 <li><a href="/sections/mrsa-superbug/" class="z">MRSA / Drug Resistance</a></li>
 <li><a href="/sections/multiple_sclerosis/" class="z">Multiple Sclerosis</a></li>
 <li><a href="/sections/muscular_dystrophy/" class="z">Muscular Dystrophy / ALS</a></li>
 <li><a href="/sections/lymphoma-leukemia/" class="z">Myeloma</a></li>
 <li><a href="/sections/neurology/" class="z">Neurology / Neuroscience</a></li>
 <li><a href="/sections/nursing/" class="z">Nursing / Midwifery</a></li>
 <li><a href="/sections/nutrition-agriculture/" class="z">Nutrition / Diet</a></li>
 
 <li><a href="/sections/fitness-obesity/" class="z">Obesity / Weight Loss / Fitness</a></li>
 <li><a href="/sections/ovarian_cancer/" class="z">Ovarian Cancer</a></li>
 
 </ul>

 </li>
</ul>
 
<ul>
 <li><a href="/index.php?page=newssections#P" class="x" rel="nofollow"><div class="menuarrows">&gt;</div>Categories P-R</a>
 
 <ul class="sub6">

 <li><a href="/sections/pain/" class="z" style="border-top:1px solid #999999;">Pain / Anesthetics</a></li>
 <li><a href="/sections/palliative_care/" class="z">Palliative Care / Hospice Care</a></li>
 <li><a href="/sections/pancreatic-cancer/" class="z">Pancreatic Cancer</a></li>
 <li><a href="/sections/parkinsons_disease/" class="z">Parkinson's Disease</a></li>
 <li><a href="/sections/pediatrics/" class="z">Pediatrics / Children's Health</a></li>
 <li><a href="/sections/pharma_industry/" class="z">Pharma / Biotech Industry</a></li>
 <li><a href="/sections/pharmacy/" class="z">Pharmacy / Pharmacist</a></li>
 <li><a href="/sections/cosmetic_medicine/" class="z">Plastic Surgery</a></li>
 <li><a href="/sections/pregnancy/" class="z">Pregnancy / Obstetrics</a></li>
 <li><a href="/sections/erectile_dysfunction/" class="z">Premature Ejaculation</a></li>
 <li><a href="/sections/preventive-medicine/" class="z">Preventive Medicine</a></li>
 <li><a href="/sections/primary_care/" class="z">Primary Care / General Practice</a></li>
 <li><a href="/sections/prostate/" class="z">Prostate / Prostate Cancer</a></li>
 <li><a href="/sections/psychology-psychiatry/" class="z">Psychology / Psychiatry</a></li>
 <li><a href="/sections/public_health/" class="z">Public Health</a></li>
 <li><a href="/sections/radiology/" class="z">Radiology / Nuclear Medicine</a></li>

 <li><a href="/sections/regulatoryaffairs/" class="z">Regulatory Affairs / Drug Approvals</a></li>
 <li><a href="/sections/rehabilitation/" class="z">Rehabilitation / Physical Therapy</a></li>
 <li><a href="/sections/asthma-respiratory/" class="z">Respiratory</a></li>
 <li><a href="/sections/restless-legs/" class="z">Restless Legs Syndrome (NEW)</a></li>
 
 </ul>

 </li>
</ul>

<ul>
 <li><a href="/index.php?page=newssections#S" class="x" rel="nofollow"><div class="menuarrows">&gt;</div>Categories S-Z</a>
 
 <ul class="sub7"> 
  <li><a href="/sections/schizophrenia/" class="z" style="border-top:1px solid #999999;">Schizophrenia</a></li>
 <li><a href="/sections/seniors/" class="z">Seniors / Aging</a></li>
 <li><a href="/sections/sexual_health/" class="z">Sexual Health / STDs</a></li>
 <li><a href="/sections/sleep/" class="z">Sleep / Sleep Disorders</a></li>
 <li><a href="/sections/smoking/" class="z">Smoking / Quit Smoking</a></li>
 <li><a href="/sections/sports_medicine/" class="z">Sports Medicine / Fitness</a></li>
 <li><a href="/sections/statins/" class="z">Statins</a></li>
 <li><a href="/sections/stem_cell/" class="z">Stem Cell Research</a></li>
 <li><a href="/sections/stroke/" class="z">Stroke</a></li>
 <li><a href="/sections/swine-flu/" class="z">Swine Flu</a></li>
 <li><a href="/sections/transplants/" class="z">Transplants / Organ Donations</a></li>
 <li><a href="/sections/tropical_diseases/" class="z">Tropical Diseases</a></li>
 <li><a href="/sections/tuberculosis/" class="z">Tuberculosis</a></li>
 <li><a href="/sections/urology-nephrology/" class="z">Urology / Nephrology</a></li>
 <li><a href="/sections/vascular/" class="z">Vascular</a></li>
 <li><a href="/sections/veterans/" class="z">Veterans / Ex-Servicemen</a></li>
 <li><a href="/sections/veterinary/" class="z">Veterinary</a></li>
 <li><a href="/sections/infectious_diseases/" class="z">Viruses / Bacteria</a></li>
 <li><a href="/sections/water_quality/" class="z">Water - Air Quality / Agriculture</a></li>
 <li><a href="/sections/womens_health/" class="z">Women's Health</a></li>
  
</ul>

 </li>
</ul>

<ul>
 <li><a href="/index.php?page=newssections" title="full list of all news category sections" accesskey="m">View full category list</a></li>
</ul>

</div>

<br clear="all">

<!-- Main Menu Links -->

<div class="menutitle">News Options</div>  
<a href="/customizedhealthnews.php" title="personalize your homepage" class="menubutton1">Personalized Homepage</a>
<a href="/newsletters.php" title="Free weekly medical news newsletter by e-mail" class="menubutton1">Weekly Newsletters</a>
<a href="/newsalerts.php" title="Free daily news alerts by e-mail" class="menubutton1">Daily News Alerts</a>
<br clear="all">

<div class="menutitle">
What Is...
</div>

<a href="/info/hemophilia/what-is-hemophilia.php" class="menubutton2" title="What is hemophilia? What is haemophilia?">Hemophilia</a>
<a href="/info/pneumococcal-disease/what-is-pneumococcal-disease.php" class="menubutton2" style="margin-bottom:5px;" title="What is pneumococcal disease?">Pneumococcal Disease</a>

<a href="/info/adhd/whatisadhd.php" class="menubutton2" title="What is ADHD?" style="border-top:1px solid #999;">ADHD</a>
<a href="/info/anxiety/what-is-anxiety.php" class="menubutton2" title="What is Anxiety? Anxiety Symptoms and Causes">Anxiety</a>
<a href="/info/asthma/what-is-asthma.php" class="menubutton2" title="What is Asthma? What Causes Asthma?">Asthma</a>
<a href="/info/atrial-fibrillation/" class="menubutton2" title="What is Atrial Fibrillation?">Atrial Fibrillation</a>
<a href="/info/autism/whatisautism.php" class="menubutton2" title="What is Autism?">Autism</a>
<a href="/info/cancer-oncology/whatiscancer.php" class="menubutton2" title="What is Cancer?">Cancer</a>
<a href="/info/diabetes/whatisdiabetes.php" class="menubutton2" title="What is Diabetes?">Diabetes</a>
<a href="/info/lung-cancer/what-is-lung-cancer.php" class="menubutton2" title="What is Lung Cancer?">Lung Cancer</a>
<a href="/info/lupus/whatislupus.php" class="menubutton2" title="What is Lupus?">Lupus</a>
<a href="/info/medicare-medicaid/whatismedicare.php" class="menubutton2" title="What is Medicare? What is Medicaid?">Medicare / Medicaid</a>
<a href="/info/obesity/what-is-obesity.php" class="menubutton2" title="What is Obesity?">Obesity and BMI</a>
<a href="/info/oic/what-are-opioids.php" class="menubutton2" title="What is opioid induced constipation?">Opioid Induced Constipation</a>
<a href="/info/pancreatic-cancer/what-is-pancreatic-cancer.php" class="menubutton2" title="What is Pancreatic Cancer?">Pancreatic Cancer</a>
<a href="/info/parkinsons-disease/" class="menubutton2" title="What is Parkinson's Disease?">Parkinson's Disease</a>
<a href="/info/stem_cell/whatarestemcells.php" class="menubutton2" title="What are Stem Cells?">Stem Cells</a>
<a href="/info/whatis.php" class="menubutton1">All 'What Is...' Articles</a>
<!--a href="/info/howto.php" class="menubutton1">All 'How To...' Articles</a-->
<br clear="all">

<form name="conditionsform" method="post" style="margin-bottom:0px; padding-top:0px;">

<div class="menutitle">
<LABEL for="conditions">Conditions Information</LABEL>
</div>


<select name="fwd" id="conditions" size="10" style="width:159px; font-size:11px;" onChange="location.href=document.forms['conditionsform'].conditions.value;return false">
<option value="http://www.medicalnewstoday.com/articles/170136.php">Abscess (Dental)</option>
<option value="http://www.medicalnewstoday.com/articles/146619.php">Acid Reflux</option>
<option value="http://www.medicalnewstoday.com/articles/107146.php">Acne</option>
<option value="http://www.medicalnewstoday.com/info/addiction/what-is-addiction.php">Addiction</option>
<option value="http://www.medicalnewstoday.com/articles/186235.php">Addison’s Disease (Primary Adrenal Insufficiency)</option>
<option value="http://www.medicalnewstoday.com/info/adhd/whatisadhd.php">ADHD</option>
<option value="http://www.medicalnewstoday.com/articles/162169.php">Agoraphobia</option>
<option value="http://www.medicalnewstoday.com/articles/157163.php">Alcoholism</option>
<option value="http://www.medicalnewstoday.com/articles/70956.php">Alopecia Areata</option>
<option value="http://www.medicalnewstoday.com/articles/179819.php">Altitude Sickness (Acute Mountain Sickness)</option>
<option value="http://www.medicalnewstoday.com/articles/159442.php">Alzheimer's Disease</option>
<option value="http://www.medicalnewstoday.com/articles/152105.php">AMD / Macular Degeneration</option>
<option value="http://www.medicalnewstoday.com/articles/9673.php">Amnesia</option>
<option value="http://www.medicalnewstoday.com/articles/73225.php">Anagen Effluvium</option>
<option value="http://www.medicalnewstoday.com/articles/156549.php">Anal Cancer</option>
<option value="http://www.medicalnewstoday.com/articles/168728.php">Anal Itching (Itchy Bottom)</option>
<option value="http://www.medicalnewstoday.com/articles/186480.php">Androgen Insensitivity Syndrome (AIS)</option>
<option value="http://www.medicalnewstoday.com/articles/158800.php">Anemia</option>
<option value="http://www.medicalnewstoday.com/articles/156993.php">Aneurysm</option>
<option value="http://www.medicalnewstoday.com/articles/162035.php">Anger</option>
<option value="http://www.medicalnewstoday.com/articles/8886.php">Angina</option>
<option value="http://www.medicalnewstoday.com/articles/105102.php">Anorexia & Bulimia</option>
<option value="http://www.medicalnewstoday.com/articles/181700.php">Antiphospholipid Syndrome (Hughes Syndrome)</option>
<option value="http://www.medicalnewstoday.com/info/anxiety/what-is-anxiety.php">Anxiety</option>
<option value="http://www.medicalnewstoday.com/articles/158806.php">Appendicitis</option>
<option value="http://www.medicalnewstoday.com/articles/8887.php">Arrhythmia</option>
<option value="http://www.medicalnewstoday.com/articles/7621.php">Arthritis</option>
<option value="http://www.medicalnewstoday.com/articles/7601.php">Asperger Syndrome</option>
<option value="http://www.medicalnewstoday.com/info/asthma/what-is-asthma.php">Asthma</option>
<option value="http://www.medicalnewstoday.com/articles/158810.php">Astigmatism</option>
<option value="http://www.medicalnewstoday.com/articles/162368.php">Ataxia</option>
<option value="http://www.medicalnewstoday.com/info/atrial-fibrillation/">Atrial Fibrillation</option>
<option value="http://www.medicalnewstoday.com/info/autism/whatisautism.php">Autism</option>
<option value="http://www.medicalnewstoday.com/articles/32778.php">Avian Influenza</option>
<option value="http://www.medicalnewstoday.com/articles/172943.php">Back Pain</option>
<option value="http://www.medicalnewstoday.com/articles/184622.php">Bacterial Vaginosis</option>
<option value="http://www.medicalnewstoday.com/articles/184714.php">Baker's Cyst (Popliteal Cyst)</option>
<option value="http://www.medicalnewstoday.com/articles/184715.php">Balanitis</option>
<option value="http://www.medicalnewstoday.com/articles/173972.php">Bed Sores (Pressure Ulcers)</option>
<option value="http://www.medicalnewstoday.com/articles/158863.php">Bell's Palsy</option>
<option value="http://www.medicalnewstoday.com/articles/173184.php">Binge Eating Disorder</option>
<option value="http://www.medicalnewstoday.com/articles/37010.php">Bipolar Disorder</option>
<option value="http://www.medicalnewstoday.com/articles/5556.php">Bird Flu</option>
<option value="http://www.medicalnewstoday.com/articles/167077.php">Bladder cancer</option>
<option value="http://www.medicalnewstoday.com/articles/184998.php">Bladder Stones</option>
<option value="http://www.medicalnewstoday.com/articles/185155.php">Blepharitis</option>
<option value="http://www.medicalnewstoday.com/articles/9719.php">Body Dysmorphic Disorder</option>
<option value="http://www.medicalnewstoday.com/articles/173478.php">Body Odor (B.O.)</option>
<option value="http://www.medicalnewstoday.com/articles/171372.php">Bone Cancer</option>
<option value="http://www.medicalnewstoday.com/articles/9670.php">Borderline Personality Disorder (BPD)</option>
<option value="http://www.medicalnewstoday.com/articles/173943.php">Botulism</option>
<option value="http://www.medicalnewstoday.com/articles/185594.php">Brain Abscess (Cerebral Abscess)</option>
<option value="http://www.medicalnewstoday.com/articles/37136.php">Breast Cancer</option>
<option value="http://www.medicalnewstoday.com/articles/186084.php">Breast Lumps</option>
<option value="http://www.medicalnewstoday.com/articles/185759.php">Bronchiectasis (Bronchiectasia)</option>
<option value="http://www.medicalnewstoday.com/articles/8888.php">Bronchitis</option>
<option value="http://www.medicalnewstoday.com/articles/152120.php">Bursitis</option>
<option value="http://www.medicalnewstoday.com/info/cancer-oncology/whatiscancer.php">Cancer</option>
<option value="http://www.medicalnewstoday.com/articles/151172.php">Candidiasis</option>
<option value="http://www.medicalnewstoday.com/articles/171876.php">Carbon Monoxide Poisoning</option>
<option value="http://www.medicalnewstoday.com/articles/171780.php">Cartilage Damage</option>
<option value="http://www.medicalnewstoday.com/articles/157510.php">Cataracts</option>
<option value="http://www.medicalnewstoday.com/articles/192263.php">Catatonic Schizophrenia</option>
<option value="http://www.medicalnewstoday.com/articles/149465.php">Cellulite</option>
<option value="http://www.medicalnewstoday.com/articles/152663.php">Cellulitis</option>
<option value="http://www.medicalnewstoday.com/articles/152712.php">Cerebral Palsy</option>
<option value="http://www.medicalnewstoday.com/articles/172015.php">Cervical Spondylosis</option>
<option value="http://www.medicalnewstoday.com/articles/172056.php">Charcot-Marie-Tooth Disease</option>
<option value="http://www.medicalnewstoday.com/articles/192104.php">Childhood Schizophrenia</option>
<option value="http://www.medicalnewstoday.com/articles/8181.php">Chlamydia</option>
<option value="http://www.medicalnewstoday.com/articles/172067.php">Cholecystitis (Gallbladder Inflammation)</option>
<option value="http://www.medicalnewstoday.com/articles/173503.php">Cholestasis Of Pregnancy (Obstetric Cholestasis)</option>
<option value="http://www.medicalnewstoday.com/articles/9152.php">Cholesterol</option>
<option value="http://www.medicalnewstoday.com/articles/42058.php">Chronic Fatigue Syndrome (CFS)</option>
<option value="http://www.medicalnewstoday.com/articles/172179.php">Chronic Kidney Failure</option>
<option value="http://www.medicalnewstoday.com/articles/7698.php">Chronic Rhinosinusitis (CRS)</option>
<option value="http://www.medicalnewstoday.com/articles/172295.php">Cirrhosis</option>
<option value="http://www.medicalnewstoday.com/articles/11337.php">CJD</option>
<option value="http://www.medicalnewstoday.com/articles/37062.php">Claustrophobia</option>
<option value="http://www.medicalnewstoday.com/articles/172329.php">Clostridium Difficile (C. Difficile)</option>
<option value="http://www.medicalnewstoday.com/articles/183991.php">Clubfoot (Talipes Equinovarus)</option>
<option value="http://www.medicalnewstoday.com/articles/172387.php">Cluster Headache</option>
<option value="http://www.medicalnewstoday.com/articles/172389.php">Cold Sores</option>
<option value="http://www.medicalnewstoday.com/articles/162806.php">Colic</option>
<option value="http://www.medicalnewstoday.com/articles/150496.php">Colon Cancer</option>
<option value="http://www.medicalnewstoday.com/articles/155598.php">Colorectal Cancer</option>
<option value="http://www.medicalnewstoday.com/articles/173655.php">Coma (Comatose)</option>
<option value="http://www.medicalnewstoday.com/articles/166606.php">Common Cold</option>
<option value="http://www.medicalnewstoday.com/articles/184338.php">Complex Regional Pain Syndrome (CRPS)</option>
<option value="http://www.medicalnewstoday.com/articles/158876.php">Concussion</option>
<option value="http://www.medicalnewstoday.com/articles/181142.php">Congenital Heart Disease (Congenital Heart Defect)</option>
<option value="http://www.medicalnewstoday.com/articles/157692.php">Conjunctivitis (allergic)</option>
<option value="http://www.medicalnewstoday.com/articles/157671.php">Conjunctivitis (infective)</option>
<option value="http://www.medicalnewstoday.com/articles/150322.php">Constipation</option>
<option value="http://www.medicalnewstoday.com/articles/141287.php">COPD & Emphysema</option>
<option value="http://www.medicalnewstoday.com/articles/172459.php">Corns / Calluses</option>
<option value="http://www.medicalnewstoday.com/articles/184130.php">Coronary Heart Disease (Coronary Artery Disease)</option>
<option value="http://www.medicalnewstoday.com/articles/173681.php">Crabs (Pubic Lice)</option>
<option value="http://www.medicalnewstoday.com/articles/151620.php">Crohn's Disease</option>
<option value="http://www.medicalnewstoday.com/articles/155932.php">Croup</option>
<option value="http://www.medicalnewstoday.com/articles/184604.php">Cryptorchidism (Undescended Testicle)</option>
<option value="http://www.medicalnewstoday.com/articles/172744.php">Cushing's Syndrome</option>
<option value="http://www.medicalnewstoday.com/articles/147960.php">Cystic Fibrosis</option>
<option value="http://www.medicalnewstoday.com/articles/152997.php">Cystitis</option>
<option value="http://www.medicalnewstoday.com/articles/160821.php">Cysts</option>
<option value="http://www.medicalnewstoday.com/articles/173811.php">Cytomegalovirus (CMV)</option>
<option value="http://www.medicalnewstoday.com/articles/152844.php">Dandruff</option>
<option value="http://www.medicalnewstoday.com/articles/141618.php">Deep Vein Thrombosis</option>
<option value="http://www.medicalnewstoday.com/articles/153363.php">Dehydration</option>
<option value="http://www.medicalnewstoday.com/articles/142214.php">Dementia</option>
<option value="http://www.medicalnewstoday.com/articles/179471.php">Dengue Fever?</option>
<option value="http://www.medicalnewstoday.com/articles/8933.php">Depression</option>
<option value="http://www.medicalnewstoday.com/articles/170635.php">Detached Retina</option>
<option value="http://www.medicalnewstoday.com/articles/68082.php">DHT</option>
<option value="http://www.medicalnewstoday.com/info/diabetes/whatisdiabetes.php">Diabetes</option>
<option value="http://www.medicalnewstoday.com/articles/183251.php">Diabetes Insipidus</option>
<option value="http://www.medicalnewstoday.com/articles/183417.php">Diabetic Retinopathy</option>
<option value="http://www.medicalnewstoday.com/articles/158634.php">Diarrhea</option>
<option value="http://www.medicalnewstoday.com/articles/159534.php">Diphtheria</option>
<option value="http://www.medicalnewstoday.com/articles/182794.php">Discoid Eczema (Nummular Dermatitis)</option>
<option value="http://www.medicalnewstoday.com/articles/192361.php">Disorganized Schizophrenia (Hebephrenia)</option>
<option value="http://www.medicalnewstoday.com/articles/152995.php">Diverticulitis</option>
<option value="http://www.medicalnewstoday.com/articles/170634.php">Double Vision (Diplopia)</option>
<option value="http://www.medicalnewstoday.com/articles/145554.php">Down Syndrome</option>
<option value="http://www.medicalnewstoday.com/articles/170743.php">Dry Eye Syndrome</option>
<option value="http://www.medicalnewstoday.com/articles/187640.php">Dry Mouth (Xerostomia)</option>
<option value="http://www.medicalnewstoday.com/articles/171193.php">Dysentery</option>
<option value="http://www.medicalnewstoday.com/articles/177473.php">Dysphagia</option>
<option value="http://www.medicalnewstoday.com/articles/151951.php">Dyspraxia</option>
<option value="http://www.medicalnewstoday.com/articles/171354.php">Dystonia</option>
<option value="http://www.medicalnewstoday.com/articles/68511.php">E.coli</option>
<option value="http://www.medicalnewstoday.com/articles/164989.php">Ectopic Pregnancy</option>
<option value="http://www.medicalnewstoday.com/articles/14417.php">Eczema</option>
<option value="http://www.medicalnewstoday.com/articles/159111.php">Edema</option>
<option value="http://www.medicalnewstoday.com/articles/153704.php">Embolism</option>
<option value="http://www.medicalnewstoday.com/articles/8934.php">Emphysema</option>
<option value="http://www.medicalnewstoday.com/articles/168997.php">Encephalitis</option>
<option value="http://www.medicalnewstoday.com/articles/151016.php">Endocarditis</option>
<option value="http://www.medicalnewstoday.com/articles/149109.php">Endometriosis</option>
<option value="http://www.medicalnewstoday.com/articles/8947.php">Epilepsy</option>
<option value="http://www.medicalnewstoday.com/articles/169397.php">Epiphora (Watering Eye)</option>
<option value="http://www.medicalnewstoday.com/articles/8873.php">Erectile Dysfunction</option>
<option value="http://www.medicalnewstoday.com/articles/182951.php">Euthanasia (Assisted Suicide)</option>
<option value="http://www.medicalnewstoday.com/articles/169869.php">Exophthalmos (Bulging Eyes)</option>
<option value="http://www.medicalnewstoday.com/articles/183858.php">Eye Melanoma (Ocular Melanoma)</option>
<option value="http://www.medicalnewstoday.com/articles/168010.php">Febrile Seizures (Convulsions)</option>
<option value="http://www.medicalnewstoday.com/articles/168266.php">Fever</option>
<option value="http://www.medicalnewstoday.com/articles/151405.php">Fibroids</option>
<option value="http://www.medicalnewstoday.com/articles/147083.php">Fibromyalgia</option>
<option value="http://www.medicalnewstoday.com/articles/168608.php">Flat Feet (Fallen Arches)</option>
<option value="http://www.medicalnewstoday.com/articles/7622.php">Flatulence</option>
<option value="http://www.medicalnewstoday.com/articles/14384.php">Food Allergy</option>
<option value="http://www.medicalnewstoday.com/articles/173312.php">Fracture (Broken Bones)</option>
<option value="http://www.medicalnewstoday.com/articles/166186.php">Frozen Shoulder</option>
<option value="http://www.medicalnewstoday.com/articles/153981.php">Gallstones</option>
<option value="http://www.medicalnewstoday.com/articles/156995.php">Ganglion Cyst</option>
<option value="http://www.medicalnewstoday.com/articles/158770.php">Gangrene</option>
<option value="http://www.medicalnewstoday.com/articles/154555.php">Gastroenteritis / Food Poisoning</option>
<option value="http://www.medicalnewstoday.com/articles/155236.php">Genital Warts</option>
<option value="http://www.medicalnewstoday.com/articles/14085.php">GERD</option>
<option value="http://www.medicalnewstoday.com/articles/167079.php">Giardiasis</option>
<option value="http://www.medicalnewstoday.com/articles/166971.php">Gilbert Syndrome</option>
<option value="http://www.medicalnewstoday.com/articles/167390.php">Glandular Fever</option>
<option value="http://www.medicalnewstoday.com/articles/9710.php">Glaucoma</option>
<option value="http://www.medicalnewstoday.com/articles/167252.php">Glomerulonephritis</option>
<option value="http://www.medicalnewstoday.com/articles/167409.php">Glue Ear</option>
<option value="http://www.medicalnewstoday.com/articles/38085.php">Gluten Intolerance / Celiac Disease</option>
<option value="http://www.medicalnewstoday.com/articles/167559.php">Goiter (Goitre)</option>
<option value="http://www.medicalnewstoday.com/articles/155653.php">Gonorrhea</option>
<option value="http://www.medicalnewstoday.com/articles/144827.php">Gout</option>
<option value="http://www.medicalnewstoday.com/articles/170005.php">Graves’ Disease</option>
<option value="http://www.medicalnewstoday.com/articles/167892.php">Guillain-Barré Syndrome</option>
<option value="http://www.medicalnewstoday.com/articles/167727.php">Gum Disease (Gingivitis)</option>
<option value="http://www.medicalnewstoday.com/articles/70957.php">Hair Loss / Baldness</option>
<option value="http://www.medicalnewstoday.com/articles/166636.php">Halitosis (Bad Breath)</option>
<option value="http://www.medicalnewstoday.com/articles/5089.php">Hangover</option>
<option value="http://www.medicalnewstoday.com/articles/160665.php">Hay Fever</option>
<option value="http://www.medicalnewstoday.com/articles/164492.php">Head Lice</option>
<option value="http://www.medicalnewstoday.com/articles/73936.php">Headaches</option>
<option value="http://www.medicalnewstoday.com/articles/151444.php">Heart Attack</option>
<option value="http://www.medicalnewstoday.com/articles/180986.php">Heart Block (AV Bundle/Bundle Branch Block)</option>
<option value="http://www.medicalnewstoday.com/articles/156849.php">Heart Failure</option>
<option value="http://www.medicalnewstoday.com/articles/9151.php">Heartburn</option>
<option value="http://www.medicalnewstoday.com/articles/181453.php">Heel Pain</option>
<option value="http://www.medicalnewstoday.com/articles/166455.php">Hemochromatosis</option>
<option value="http://www.medicalnewstoday.com/info/hemophilia/what-is-hemophilia.php">Hemophilia</option>
<option value="http://www.medicalnewstoday.com/articles/73938.php">Hemroids / Hemorrhoids</option>
<option value="http://www.medicalnewstoday.com/articles/145869.php">Hepatitis</option>
<option value="http://www.medicalnewstoday.com/articles/142334.php">Hernia</option>
<option value="http://www.medicalnewstoday.com/articles/151739.php">Herpes</option>
<option value="http://www.medicalnewstoday.com/articles/9896.php">Hiccups</option>
<option value="http://www.medicalnewstoday.com/articles/181573.php">Hiccups (Hiccoughs)</option>
<option value="http://www.medicalnewstoday.com/articles/159283.php">High Blood Pressure</option>
<option value="http://www.medicalnewstoday.com/articles/17131.php">HIV / AIDS</option>
<option value="http://www.medicalnewstoday.com/articles/157260.php">Hives</option>
<option value="http://www.medicalnewstoday.com/articles/159552.php">Huntington's Disease</option>
<option value="http://www.medicalnewstoday.com/articles/181727.php">Hydrocephalus (Water On The Brain)</option>
<option value="http://www.medicalnewstoday.com/articles/182130.php">Hyperhidrosis (Excessive Sweating)</option>
<option value="http://www.medicalnewstoday.com/articles/150109.php">Hypertension</option>
<option value="http://www.medicalnewstoday.com/articles/9153.php">Hyperthyroidism</option>
<option value="http://www.medicalnewstoday.com/articles/9154.php">Hypertrophic Cardiomyopathy</option>
<option value="http://www.medicalnewstoday.com/articles/9983.php">Hypochondria</option>
<option value="http://www.medicalnewstoday.com/articles/166815.php">Hypoglycemia</option>
<option value="http://www.medicalnewstoday.com/articles/159609.php">Hypotension</option>
<option value="http://www.medicalnewstoday.com/articles/163729.php">Hypothyroidism</option>
<option value="http://www.medicalnewstoday.com/articles/161555.php">Hysterectomy</option>
<option value="http://www.medicalnewstoday.com/articles/162945.php">Impetigo</option>
<option value="http://www.medicalnewstoday.com/articles/165583.php">Incontinence (bowel)</option>
<option value="http://www.medicalnewstoday.com/articles/165408.php">Incontinence (urinary)</option>
<option value="http://www.medicalnewstoday.com/articles/163484.php">Indigestion</option>
<option value="http://www.medicalnewstoday.com/articles/165358.php">Infant Jaundice</option>
<option value="http://www.medicalnewstoday.com/articles/165748.php">Infertility</option>
<option value="http://www.medicalnewstoday.com/articles/15107.php">Influenza / Flu</option>
<option value="http://www.medicalnewstoday.com/articles/166268.php">Ingrown Toenail</option>
<option value="http://www.medicalnewstoday.com/articles/9155.php">Insomnia</option>
<option value="http://www.medicalnewstoday.com/articles/178635.php">Irregular Periods (Oligomenorrhea)</option>
<option value="http://www.medicalnewstoday.com/articles/37063.php">Irritable Bowel Syndrome (IBS)</option>
<option value="http://www.medicalnewstoday.com/articles/165749.php">Jaundice (icterus)</option>
<option value="http://www.medicalnewstoday.com/articles/165339.php">Jet Lag</option>
<option value="http://www.medicalnewstoday.com/articles/164533.php">Kawasaki Disease</option>
<option value="http://www.medicalnewstoday.com/articles/180858.php">Ketosis</option>
<option value="http://www.medicalnewstoday.com/articles/164659.php">Kidney Cancer</option>
<option value="http://www.medicalnewstoday.com/articles/182306.php">Kidney Infection (Pyelonephritis)</option>
<option value="http://www.medicalnewstoday.com/articles/154193.php">Kidney Stones</option>
<option value="http://www.medicalnewstoday.com/articles/164512.php">Lazy Eye</option>
<option value="http://www.medicalnewstoday.com/articles/180160.php">Leg Cramps</option>
<option value="http://www.medicalnewstoday.com/articles/18413.php">Legionnaires' Disease</option>
<option value="http://www.medicalnewstoday.com/articles/142595.php">Leukemia</option>
<option value="http://www.medicalnewstoday.com/articles/184866.php">Lichen Planus</option>
<option value="http://www.medicalnewstoday.com/articles/172408.php">Liver Cancer</option>
<option value="http://www.medicalnewstoday.com/info/lung-cancer/what-is-lung-cancer.php">Lung Cancer</option>
<option value="http://www.medicalnewstoday.com/info/lupus/whatislupus.php">Lupus</option>
<option value="http://www.medicalnewstoday.com/articles/150479.php">Lyme Disease</option>
<option value="http://www.medicalnewstoday.com/articles/180919.php">Lymphedema</option>
<option value="http://www.medicalnewstoday.com/articles/146136.php">Lymphoma</option>
<option value="http://www.medicalnewstoday.com/articles/39348.php">Mal De Debarquement Syndrome (MdDS)</option>
<option value="http://www.medicalnewstoday.com/articles/150670.php">Malaria</option>
<option value="http://www.medicalnewstoday.com/articles/179316.php">Malnutrition</option>
<option value="http://www.medicalnewstoday.com/articles/163876.php">Mastitis</option>
<option value="http://www.medicalnewstoday.com/articles/37135.php">Measles</option>
<option value="http://www.medicalnewstoday.com/articles/163888.php">Meniere's disease</option>
<option value="http://www.medicalnewstoday.com/articles/9276.php">Meningitis</option>
<option value="http://www.medicalnewstoday.com/articles/155651.php">Menopause</option>
<option value="http://www.medicalnewstoday.com/articles/154543.php">Mental Health</option>
<option value="http://www.medicalnewstoday.com/articles/140859.php">Mesothelioma</option>
<option value="http://www.medicalnewstoday.com/articles/190431.php">Metatarsalgia (Stone Bruise)</option>
<option value="http://www.medicalnewstoday.com/articles/148373.php">Migraine</option>
<option value="http://www.medicalnewstoday.com/articles/179609.php">Molluscum Contagiosum</option>
<option value="http://www.medicalnewstoday.com/articles/179633.php">Morning Sickness (Nausea Gravidarum)</option>
<option value="http://www.medicalnewstoday.com/articles/179773.php">Morton's Neuroma</option>
<option value="http://www.medicalnewstoday.com/articles/164342.php">Motor Neuron Disease</option>
<option value="http://www.medicalnewstoday.com/articles/165331.php">Mouth Cancer</option>
<option value="http://www.medicalnewstoday.com/articles/10634.php">MRSA</option>
<option value="http://www.medicalnewstoday.com/articles/161727.php">Multiple Myeloma</option>
<option value="http://www.medicalnewstoday.com/articles/37556.php">Multiple Sclerosis</option>
<option value="http://www.medicalnewstoday.com/articles/167813.php">Munchausen Syndrome</option>
<option value="http://www.medicalnewstoday.com/articles/167880.php">Munchausen Syndrome By Proxy</option>
<option value="http://www.medicalnewstoday.com/articles/179968.php">Myasthenia Gravis (Goldflam Disease)</option>
<option value="http://www.medicalnewstoday.com/articles/151952.php">Nail Fungal Infection</option>
<option value="http://www.medicalnewstoday.com/articles/9741.php">Narcissistic Personality Disorder</option>
<option value="http://www.medicalnewstoday.com/articles/155244.php">Narcolepsy</option>
<option value="http://www.medicalnewstoday.com/articles/177020.php">Nasal Polyps</option>
<option value="http://www.medicalnewstoday.com/articles/7884.php">Necrotizing Fasciitis</option>
<option value="http://www.medicalnewstoday.com/articles/179083.php">Neurofibromatosis</option>
<option value="http://www.medicalnewstoday.com/articles/170302.php">Neuromyelitis Optica (Devic's Disease)</option>
<option value="http://www.medicalnewstoday.com/articles/147963.php">Neuropathy</option>
<option value="http://www.medicalnewstoday.com/articles/181299.php">Nicotine Dependence (Dangers Of Smoking)</option>
<option value="http://www.medicalnewstoday.com/articles/179107.php">Norovirus Infection</option>
<option value="http://www.medicalnewstoday.com/info/obesity/what-is-obesity.php">Obesity</option>
<option value="http://www.medicalnewstoday.com/articles/12109.php">Obsessive Compulsive Disorder</option>
<option value="http://www.medicalnewstoday.com/articles/178508.php">Obsessive Compulsive Disorder (OCD)</option>
<option value="http://www.medicalnewstoday.com/articles/192912.php">Occupational Asthma</option>
<option value="http://www.medicalnewstoday.com/articles/9274.php">Oesophagitis</option>
<option value="http://www.medicalnewstoday.com/info/oic/what-are-opioids.php">Opioid-Induced Constipation (OIC)</option>
<option value="http://www.medicalnewstoday.com/articles/178864.php">Oral Thrush (Oral Candidiasis)</option>
<option value="http://www.medicalnewstoday.com/articles/27871.php">Osteoarthritis</option>
<option value="http://www.medicalnewstoday.com/articles/166764.php">Osteochondritis Dissecans</option>
<option value="http://www.medicalnewstoday.com/articles/178819.php">Osteomyelitis (Bone Infection)</option>
<option value="http://www.medicalnewstoday.com/articles/70381.php">Osteopathy</option>
<option value="http://www.medicalnewstoday.com/articles/155646.php">Osteoporosis</option>
<option value="http://www.medicalnewstoday.com/articles/178934.php">Otitis Externa (Swimmer's Ear)</option>
<option value="http://www.medicalnewstoday.com/articles/159675.php">Ovarian Cancer</option>
<option value="http://www.medicalnewstoday.com/articles/179031.php">Ovarian Cyst</option>
<option value="http://www.medicalnewstoday.com/articles/145750.php">Pain</option>
<option value="http://www.medicalnewstoday.com/info/pancreatic-cancer/what-is-pancreatic-cancer.php">Pancreatic Cancer</option>
<option value="http://www.medicalnewstoday.com/articles/160427.php">Pancreatitis (acute)</option>
<option value="http://www.medicalnewstoday.com/articles/160459.php">Pancreatitis (chronic)</option>
<option value="http://www.medicalnewstoday.com/articles/8872.php">Panic Attacks</option>
<option value="http://www.medicalnewstoday.com/articles/192621.php">Paranoid Schizophrenia</option>
<option value="http://www.medicalnewstoday.com/info/parkinsons-disease/index.php">Parkinson's Disease</option>
<option value="http://www.medicalnewstoday.com/articles/9273.php">Peptic Ulcers</option>
<option value="http://www.medicalnewstoday.com/articles/157333.php">Period Pains</option>
<option value="http://www.medicalnewstoday.com/articles/71702.php">Pimples</option>
<option value="http://www.medicalnewstoday.com/articles/175134.php">Pinworms (Threadworms)</option>
<option value="http://www.medicalnewstoday.com/articles/158813.php">Pleurisy</option>
<option value="http://www.medicalnewstoday.com/info/pneumococcal-disease/what-is-pneumococcal-disease.php">Pneumococcal Disease</option>
<option value="http://www.medicalnewstoday.com/articles/151632.php">Pneumonia</option>
<option value="http://www.medicalnewstoday.com/articles/155580.php">Polio</option>
<option value="http://www.medicalnewstoday.com/articles/156285.php">Post Traumatic Stress Disorder (PTSD)</option>
<option value="http://www.medicalnewstoday.com/articles/160253.php">Postherpetic Neuralgia</option>
<option value="http://www.medicalnewstoday.com/articles/182287.php">Prader-Willi Syndrome</option>
<option value="http://www.medicalnewstoday.com/articles/146746.php">Progeria</option>
<option value="http://www.medicalnewstoday.com/articles/150086.php">Prostate Cancer</option>
<option value="http://www.medicalnewstoday.com/articles/52457.php">Psoriasis</option>
<option value="http://www.medicalnewstoday.com/articles/167533.php">Pulmonary Edema (Oedema)</option>
<option value="http://www.medicalnewstoday.com/articles/153796.php">Pulmonary Embolism</option>
<option value="http://www.medicalnewstoday.com/articles/191799.php">Q Fever</option>
<option value="http://www.medicalnewstoday.com/articles/176713.php">Raynaud's Disease</option>
<option value="http://www.medicalnewstoday.com/articles/176443.php">Repetitive Strain Injury (RSI)</option>
<option value="http://www.medicalnewstoday.com/articles/7882.php">Restless Legs Syndrome</option>
<option value="http://www.medicalnewstoday.com/articles/176648.php">Rheumatic Fever</option>
<option value="http://www.medicalnewstoday.com/articles/177085.php">Rhinitis, Non-Allergic</option>
<option value="http://www.medicalnewstoday.com/articles/176941.php">Rickets</option>
<option value="http://www.medicalnewstoday.com/articles/158004.php">Ringworm</option>
<option value="http://www.medicalnewstoday.com/articles/160281.php">Rosacea</option>
<option value="http://www.medicalnewstoday.com/articles/164504.php">Rubella</option>
<option value="http://www.medicalnewstoday.com/articles/160942.php">Salmonella</option>
<option value="http://www.medicalnewstoday.com/articles/7543.php">SARS</option>
<option value="http://www.medicalnewstoday.com/articles/16961.php">Scabies</option>
<option value="http://www.medicalnewstoday.com/articles/176242.php">Scarlet Fever (Scarlatina)</option>
<option value="http://www.medicalnewstoday.com/articles/173081.php">Schistosomiasis (Bilharzia)</option>
<option value="http://www.medicalnewstoday.com/articles/190678.php">Schizoaffective Disorder</option>
<option value="http://www.medicalnewstoday.com/articles/36942.php">Schizophrenia</option>
<option value="http://www.medicalnewstoday.com/articles/7619.php">Sciatica</option>
<option value="http://www.medicalnewstoday.com/articles/176357.php">Scleroderma</option>
<option value="http://www.medicalnewstoday.com/articles/190940.php">Scoliosis</option>
<option value="http://www.medicalnewstoday.com/articles/155758.php">Scurvy</option>
<option value="http://www.medicalnewstoday.com/articles/10306.php">Seasonal Affective Disorder</option>
<option value="http://www.medicalnewstoday.com/articles/182473.php">Sexual Addiction (Nymphomania)</option>
<option value="http://www.medicalnewstoday.com/articles/154912.php">Shingles</option>
<option value="http://www.medicalnewstoday.com/articles/170880.php">Short Stature (Dwarfism)</option>
<option value="http://www.medicalnewstoday.com/articles/149941.php">Sinusitis</option>
<option value="http://www.medicalnewstoday.com/articles/154322.php">Skin Cancer / Melanoma</option>
<option value="http://www.medicalnewstoday.com/articles/169853.php">Slapped Cheek Syndrome</option>
<option value="http://www.medicalnewstoday.com/articles/176891.php">Social Anxiety Disorder</option>
<option value="http://www.medicalnewstoday.com/articles/10608.php">Stammering</option>
<option value="http://www.medicalnewstoday.com/articles/155412.php">Strep Throat / Sore Throat</option>
<option value="http://www.medicalnewstoday.com/articles/145855.php">Stress</option>
<option value="http://www.medicalnewstoday.com/articles/189944.php">Stress Incontinence</option>
<option value="http://www.medicalnewstoday.com/articles/7624.php">Stroke</option>
<option value="http://www.medicalnewstoday.com/articles/147720.php">Swine Flu</option>
<option value="http://www.medicalnewstoday.com/articles/175241.php">Tachycardia (Fast Heart Beat)</option>
<option value="http://www.medicalnewstoday.com/articles/170461.php">Tapeworms (Cestodes)</option>
<option value="http://www.medicalnewstoday.com/articles/175596.php">Tendinitis (Tendonitis)</option>
<option value="http://www.medicalnewstoday.com/articles/166993.php">Testicular Cancer</option>
<option value="http://www.medicalnewstoday.com/articles/190514.php">Testicular Torsion</option>
<option value="http://www.medicalnewstoday.com/articles/163063.php">Tetanus</option>
<option value="http://www.medicalnewstoday.com/articles/156286.php">Tinnitus</option>
<option value="http://www.medicalnewstoday.com/articles/8877.php">Tiredness / Fatigue</option>
<option value="http://www.medicalnewstoday.com/articles/156497.php">Tonsillitis</option>
<option value="http://www.medicalnewstoday.com/articles/175009.php">Tourette Syndrome</option>
<option value="http://www.medicalnewstoday.com/articles/175736.php">Toxic Shock Syndrome (TSS)</option>
<option value="http://www.medicalnewstoday.com/articles/164038.php">Transient Ischemic Attack</option>
<option value="http://www.medicalnewstoday.com/articles/179837.php">Traumatic Brain Injury (TBI)</option>
<option value="http://www.medicalnewstoday.com/articles/160252.php">Trigeminal Neuralgia</option>
<option value="http://www.medicalnewstoday.com/articles/187322.php">Triple X Syndrome</option>
<option value="http://www.medicalnewstoday.com/articles/8856.php">Tuberculosis</option>
<option value="http://www.medicalnewstoday.com/articles/176083.php">Turner Syndrome</option>
<option value="http://www.medicalnewstoday.com/articles/156859.php">Typhoid</option>
<option value="http://www.medicalnewstoday.com/articles/163772.php">Ulcerative Colitis</option>
<option value="http://www.medicalnewstoday.com/articles/189580.php">Umbilical Hernia</option>
<option value="http://www.medicalnewstoday.com/articles/189953.php">Urinary Tract Infection (UTI)</option>
<option value="http://www.medicalnewstoday.com/articles/166410.php">Uveitis</option>
<option value="http://www.medicalnewstoday.com/articles/189281.php">Vaculitis (Angiitis)</option>
<option value="http://www.medicalnewstoday.com/articles/175101.php">Vaginitis</option>
<option value="http://www.medicalnewstoday.com/articles/189430.php">Valley Fever (Coccidioidomycosis)</option>
<option value="http://www.medicalnewstoday.com/articles/188837.php">Ventricular Fibrillation</option>
<option value="http://www.medicalnewstoday.com/articles/160900.php">Vertigo</option>
<option value="http://www.medicalnewstoday.com/articles/189144.php">Vesicoureteral Reflux (VUR)</option>
<option value="http://www.medicalnewstoday.com/articles/172774.php">Vitamin B12 Deficiency</option>
<option value="http://www.medicalnewstoday.com/articles/188993.php">Vocal Cord Paresis (Paralysis)</option>
<option value="http://www.medicalnewstoday.com/articles/188979.php">Von Willebrand Disease</option>
<option value="http://www.medicalnewstoday.com/articles/173108.php">Vulvar Cancer (Vulval Cancer)</option>
<option value="http://www.medicalnewstoday.com/articles/155039.php">Warts</option>
<option value="http://www.medicalnewstoday.com/articles/187978.php">Water Retention (Fluid Retention)</option>
<option value="http://www.medicalnewstoday.com/articles/187807.php">Wegener's Granulomatosis</option>
<option value="http://www.medicalnewstoday.com/articles/187839.php">West Nile Virus (WNV)</option>
<option value="http://www.medicalnewstoday.com/articles/174405.php">Wheat Allergy</option>
<option value="http://www.medicalnewstoday.com/articles/188130.php">Wilms’ Tumor (Nephroblastoma)</option>
<option value="http://www.medicalnewstoday.com/articles/174372.php">Yellow Fever</option>
<option value="http://www.medicalnewstoday.com/articles/186793.php">Zollinger-Ellison Syndrome</option>
</select>

</form>
<br>

<div class="menutitle">Health Professional Sites</div>
<a href="http://www.clinical-ophthalmology.com" target="_blank" class="menubutton2" title="Ophthalmology [External Site Link. Opens in New Window]" rel="nofollow">Ophthalmology</a>
<a href="http://www.urotoday.com" target="_blank" class="menubutton2" title="UroToday Urology [External Site Link. Opens in New Window]" rel="nofollow">Urology</a>
<br clear="all">

<div class="menutitle">Other Navigation Links</div>
<a href="/index.php?page=aboutus&amp;title=About+Us" accesskey="a" rel="nofollow" class="menubutton1">About Us</a> 
<a href="/licensing.php" class="menubutton1">News Licensing</a> 
<a href="/newsfeeds.php" title="Free medical news feeds for your web site" accesskey="j" class="menubutton1">Free Website Feeds</a> 
<a href="/index.php?page=freecontent&amp;title=Free+Medical+Content+and+Tools" accesskey="t"  class="menubutton1" >Free Tools &amp; Content</a> 
<a href="/tellafriend.php" rel="nofollow" class="menubutton1">Tell a Friend</a> 
<a href="/index.php?page=accessibility&amp;title=Accessibility+Information" accesskey="x" rel="nofollow" class="menubutton1">Accessibility</a> 
<a href="/mnthelp.php" rel="nofollow" class="menubutton1">Help / FAQ</a> 
<a href="/index.php?page=authors&amp;title=Article+submission+guidelines+for+authors" rel="nofollow" class="menubutton1">Article Submission</a> 
<a href="/index.php?page=links&amp;title=Medical+News+Today+Links" rel="nofollow" class="menubutton1">Links</a> 
<a href="/contactus.php" accesskey="c" rel="nofollow" class="menubutton1">Contact Us</a> 
<br clear="all">

<form method="post" action="http://www.medilexicon.com/searches/clinicaltrials.php" enctype="application/x-www-form-urlencoded" target="_blank" style="margin-top:0px; margin-bottom:0px;">
<div class="menutitle"><label for="clinicalkeywords">Clinical Trials</label></div>
<!-- Begin Clinical Trials Search html code -->
<table border="0" width="100%" cellspacing="0" cellpadding="5" style="border:1px solid #999999;">
<tr>
<td width="80%" bgcolor="#ffffff">
<input type="text" name="keywords" id="clinicalkeywords" style="width:80px;" size="7"></td>
<td width="20%" bgcolor="#ffffff"><input type="submit" value="Go!" style="font-family:arial,helvetica; font-size: 8pt; color: #000000"></td>
</tr>
</table>
</form>

<!--
<br>
<a href="/newsletters.php"><img src="/images/newsletterad4.jpg" width="159" height="159" alt="Sign up to receive newsletters / news alerts" border="0"></a>
<br><br>
-->

<br clear="all">

<a href="http://apps.facebook.com/health-news/" title="add medical news today to your facebook" target="_blank">
<img src="/images/leftbar/banner_facebook4.jpg" alt="add medical news today to your facebook" border="0">
</a>
<br>
<a href="/medicalnewsgadget.php" title="website gadget code">
<img src="/images/google_gadget/banner_gadget1.jpg" alt="medical news gadget" border="0">
</a>

<div style='width:150px; margin-top:20px; margin-bottom:20px; text-align:left;'><script type="text/javascript"><!--
google_ad_client = "pub-1971793357249522";
google_ad_width = 120;
google_ad_height = 90;
google_ad_format = "120x90_0ads_al";
google_ad_channel ="5172264358";
google_color_border = "ffffff";
google_color_bg = "ffffff";
google_color_link = "0000CC";
google_color_url = "ff0000";
google_color_text = "000000";
google_color_line = 'ffffff';
google_reuse_colors = 1;
google_rl_dest_url="http://www.medicalnewstoday.com/healthsearch.php";
//--></script>

<script type="text/javascript"
 src=
"http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</div>



<!--div style="width:100%; margin-top:10px;"><a href="http://www.medreader.com" target="_blank" title="Link to MedReader.com" rel="nofollow"><img src="/images/medreader120x60.gif" width="120" height="60" alt="MedReader RSS Reader" border="0"></a></div-->

<img src="/images/transpixel.gif" width="1" height="20" alt=""><br>	</div>
	
	<div id="rightmenu" class="robots-nocontent">   
		<!-- Right Bar Section -->
		
<div class="box2">

	<div style="width:89px; height:80px; position:relative; float:left; margin:0px 10px 12px 0px;"><a href="http://www.medicalhealthforum.com/alzheimers-dementia/" target="_blank"><img src="/images/icons/chat.jpg" width="89" height="80" alt="Forum Icon" border="0"></a></div>

<h2 style="color: #0F3F9F; margin-left:99px; margin-top:0px; margin-bottom:8px; z-index:1000;">Alzheimer's Forum</h2>
Discuss issues relating to alzheimer's / dementia in our new forum.
<br><br>

	Visit the <a href="http://www.medicalhealthforum.com/alzheimers-dementia/" target="_blank">alzheimer's forum</a>
</div>
<br>

<div class='menutitle' style='text-align:left; padding-right:12px;'>Latest News For Alzheimer's / Dementia</div><div class="box2"><div style="padding-top:5px; padding-bottom:2px;"><a href="/articles/194790.php">Novel Chemical Could Detect Changes In Amyloid In Alzheimer's Disease</a><br>15 Jul 2010</div>
<div style="padding-top:5px; padding-bottom:2px;"><a href="/articles/194776.php">Visual Memory Improvement In Older Adults Following Brain Fitness Program</a><br>15 Jul 2010</div>
<div style="padding-top:5px; padding-bottom:2px;"><a href="/articles/194792.php">Alzheimer's Gene Linked To Cognitive Impairment In Mid-Life</a><br>15 Jul 2010</div>
<br><a href="/sections/alzheimers/">View more news...</a>
</div><br>
	<div class='menutitle' style='padding-left:16px;'>Most Popular Articles For Alzheimer's</div>
	<div class="box2" style="font-size:12px; margin-top:0px;">
	These are the most read articles from this news category for the last 6 months:
	<hr size=1>
	<div class="rbtoparticle_item"><div class="rbtoparticle_star"><img src="/images/icons/toparticlestar.jpg" width="80" height="80" alt="Top Article Star"></div><a href="/articles/180304.php">Napping Boosts Brain Power</a><br><b>24 Feb 2010</b><br>
Researchers in the US found that napping boosts brain power by clearing out the brain's temporary storage space so it can absorb new information: 
they also propose that this clearing out process happens during a specific stage of sleep...</div>
<div class="rbtoparticle_item"><a href="/articles/179882.php">Findings Suggest That A Biphasic Sleep Schedule Not Only Refreshes The Mind, But Can Make You Smarter</a><br>22 Feb 2010</div>
<div class="rbtoparticle_item"><a href="/articles/184536.php">New, Inexpensive Way To Predict Alzheimer's Disease</a><br>06 Apr 2010</div>
<div class="rbtoparticle_item"><a href="/articles/176316.php">Singing On Prescription?</a><br>18 Jan 2010</div>
<div class="rbtoparticle_item"><a href="/articles/186707.php">Brain Shrinkage In Aging May Be Influenced By Personality</a><br>27 Apr 2010</div>
	</div>
	<br>

	<div style="margin-bottom:10px;"><script language="JavaScript"><!--google_ad_client = 'pub-1971793357249522';//2008-05-20: Medical News 300x250 RightBar, MNT - Alzheimer's / Dementia
google_ad_channel = "8074693922+1842996401";
google_max_num_ads = '3';google_ad_type = 'text,image,flash,html';google_ad_output = 'js';google_image_size = '300x250';google_feedback = 'on';google_adtest = 'off';// --></script><script language="JavaScript" src="http://pagead2.googlesyndication.com/pagead/show_ads.js"></script></div>
<br clear='all'>

<div class="box2">

	<h2 style="color: #0F3F9F; margin:0px 0px 12px 4px; z-index:1000;">Follow Our News On Twitter:<br><span style="color:#0099FF;">Alzheimer's</span></h2>
	<div style="width:80px; height:80px; position:relative; float:left; margin:0px 10px 0px 0px;"><a href="http://twitter.com/mnt_alzheimers/" target="_blank"><img src="/images/icons/twittericon_rightbar.jpg" width="80" height="78" alt="Follow Us On Twitter" border="0"></a></div>
	Get the latest news for this category delivered straight to your Twitter account. Simply click the 
	link below and select the 'follow' option.
	<br style="clear:both;">
	<ul style="margin:10px 0px 0px 5px;">
	 <li>Follow our <a href="http://twitter.com/mnt_alzheimers/" target="_blank">alzheimer's / dementia news on Twitter</a></li>
	 <li>View a list of all our <a href="/twitterhealthfeeds.php">Twitter feeds</a></li>
    </ul>
    
</div>
<br>

<div class='menutitle' style='padding-left:16px;'>Latest Videos for Alzheimer's</div><div class='box2' style='margin-top:0px;'><div style="width:auto;"><img src="http://www.healthology.com/img_lib/101586_b.jpg" width="41" height="60" alt="The Role of a Caregiver image" align="left" style="margin-right:8px; margin-bottom:8px">
<b><a onclick="javascript:window.open(this.href,'VideoPlayer','scrollbars=no,resizable=no,width=732,height=604,status=no');return false;" href="http://medicalnewstoday.healthology.com/hybrid/hybrid-autodetect.aspx?content_id=1831&focus_handle=alzheimers-disease&brand_name=medicalnewstoday" target="_blank">The Role of a Caregiver</a></b>
<br><br>
When a frail or chronically ill loved one can no longer care for him or herself the issue confronting families is what to do about care. Learn what you need to think about first...
<br clear=left><br>
<img src="http://www.healthology.com/img_lib/10039_b.jpg" width="41" height="60" alt="Using Creativity to Combat Alzheimer's image" align="left" style="margin-right:8px; margin-bottom:8px">
<b><a onclick="javascript:window.open(this.href,'VideoPlayer','scrollbars=no,resizable=no,width=732,height=604,status=no');return false;" href="http://medicalnewstoday.healthology.com/hybrid/hybrid-autodetect.aspx?content_id=4544&focus_handle=alzheimers-disease&brand_name=medicalnewstoday" target="_blank">Using Creativity to Combat Alzheimer's</a></b>
<br><br>
Learn how the introduction of a new activity changed the lives of an Alzheimer's patient and her caregiver...
<br clear=left><br>
</div><a href="/sections/alzheimers/videos.php">View more videos...</a>
</div><br>
<br clear="both">

<!-- MLClick Imps Tracker -->
<img src="http://www.mlclick.com/mltr.php?aid=3FBB20449E46ACE24A54A01C346B1743" alt="" border="0">
	</div>
	
	<img src="/counter_2.php?33317&v=ba1c021924400e8beb806c10eb7f127e" width="1" height="1" alt="" border="0">
<img src="/counter_3.php?hc=3&33317&v=ba1c021924400e8beb806c10eb7f127e" width="1" height="1" alt="" border="0">

</div>

<script src="http://www.google-analytics.com/urchin.js" type="text/javascript"></script><script type="text/javascript">_uacct = "UA-849615-1";urchinTracker();</script>
</body>
</html>