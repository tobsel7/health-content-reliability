<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<title>Testosterone, Carbon Isotopes, and Floyd Landis. In the Pipeline: </title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="description" content="">
<meta name="ICBM" content="42.341665, -71.078200" />
<meta name="DC.title" content="Corante: Boston" />
<!-- http://geourl.org/news/2005/02/25/launch.html -->

<!-- sitewide CSS -->

<link rel="stylesheet" href="http://www.corante.com/css/blogs.css" type="text/css" />
<link rel="stylesheet" href="http://pipeline.corante.com/local.css" type="text/css" />

<link rel="shortcut icon" href="http://www.corante.com/favicon.ico" type="image/ico" />

<!-- points to Feedburner.com -->
<link rel="alternate" type="application/rss+xml" title="RSS" href="http://pipeline.corante.com/index.xml" />

<!-- Site Javascript  CONSOLIDATE -->
<script src="http://www.corante.com/js/site_wide.js" language="javascript" type="text/javascript"></script>
<script src="http://www.corante.com/js/obfuscator.js" language="javascript" type="text/javascript"></script>

<script type="text/javascript">
var __MTTBLINK__;
var __MTTBID__;
function obfuscator(coded, key, mode, path, hidden) {
	shift = coded.length;
	link = "";
	
	for(i=0;i<coded.length;i++) {
		if (key.indexOf(coded.charAt(i))==-1) {
			ltr = coded.charAt(i);link+=(ltr);
		} else {
			ltr = (key.indexOf(coded.charAt(i)) - shift + key.length) % key.length;
			link += (key.charAt(ltr));
		}
	}
	if(mode == 'hidden_input') {
		document.write('<input type="hidden" name="CCode" value="' + link + '" />');
	} else if(mode == '__MTTBLINK__') {
		__MTTBLINK__ = path + link;
		if(hidden) return;
		document.write(link);
	} else if(mode == '__MTTBID__') {
		__MTTBID__ = link;
		if(hidden) return;
		document.write(link);
	}
}
</script>

<!-- RSS -->
<link rel="alternate" type="application/rss+xml" title="RSS" href="http://pipeline.corante.com/index.xml" />
<link rel="alternate" type="application/atom+xml" title="Atom" href="http://pipeline.corante.com/atom.xml" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://pipeline.corante.com/rsd.xml" />

<script type="text/javascript" src="http://pipeline.corante.com/mt-site.js"></script>

</head>
<body>

<div id="aboutlinks">
<a href="http://www.corante.com/about.php">About Us</a> | <a href="http://www.corante.com/rss.php">RSS</a> | <a href="http://www.corante.com/adinfo.php">Advertise</a> | <a href="http://www.corante.com/contact.php">Contact Us</a>
</div>
<h1><a href="http://www.corante.com"><img src="http://www.corante.com/img/corante_head_logo2.gif" alt="Corante" width="233" height="37" border="0" /></a></h1>

<!-- NAVBAR -->

<table width="100%" cellpadding="0" cellspacing="0" border="0">
<tr><td class="sitenav" height="25"><a href="http://www.corante.com">Home</a> &gt; Weblog Columns &gt; <a href="http://pipeline.corante.com/">In the Pipeline</a></td><td class="sitenav" align="right"><form action="#">
<select
onchange="javascript:document.location=options[selectedIndex].value;"
class="archivemenu">
<option value="#">Weblog columns [select a blog]</option>
<option value="http://corante.corante.com/">[Corante Blog]</option>
<option
value="http://betweenlawyers.corante.com/">BETWEEN
LAWYERS: technology + culture + law</option>
<option value="http://brainwaves.corante.com/">BRAIN
WAVES:
neurons, bits  &amp; genes</option>
<option
value="http://copyfight.corante.com/">COPYFIGHT: the
politics of intellectual property</option>
<option value="http://goyami.corante.com/">GOYAMI: search engine marketing</option>
<option value="http://ideaflow.corante.com/">IDEAFLOW:
creativity
+ innovation</option>
<option value="http://pipeline.corante.com/">IN THE
PIPELINE: drug
discovery</option>
<option value="http://many.corante.com/">MANY-TO-MANY: social
software</option>
<option
value="http://rebuildingmedia.corante.com/">REBUILDING
MEDIA: the economics of media</option>
<option value="http://strange.corante.com/">STRANGE ATTRACTOR:
social media</option>
<option
value="http://totalexperience.corante.com/">TOTAL
EXPERIENCE: experience design</option>
</select>
</form></td><td width="9" align="right" style="background:url(http://www.corante.com/frontpage/crush_corner_etnaroc.gif) top right no-repeat;">
</td>
</tr>
<tr>
<td colspan="3">

<!-- SUB NAV/3 COLUMNS -->

<table width="100%" cellpadding="0" cellspacing="0" border="0" id="content">
<tr>
<td valign="top">

<div class="side">
<h5>About this Author</h5>

<img src="http://www.corante.com/pipeline/dbl.jpg" alt="Derek Lowe" width="115" border="0" />

<br>
Derek Lowe, an Arkansan by birth, got his BA from Hendrix College and his PhD in organic chemistry from Duke before spending time in Germany on a Humboldt Fellowship on his post-doc. He's worked for several major pharmaceutical companies since 1989 on drug discovery projects against schizophrenia, Alzheimer's, diabetes, osteoporosis and other diseases. 
To contact Derek email him directly: <a href="mailto:derekb.lowe@gmail.com">derekb.lowe@gmail.com</a>
Twitter: Dereklowe<br>
<br>


<iframe src="http://rcm.amazon.com/e/cm?t=lagniappe-20&o=1&p=20&l=qs1&f=ifr" width="120" height="90" frameborder="0" scrolling="no"></iframe>
</div>

<div class="side">
Chemistry and Drug Data:
<a href="http://www.drugbank.ca/">Drugbank</a><br>
<a href="http://www.emolecules.com">Emolecules</a><br>
<a href="http://www.chemspider.com">ChemSpider</a><br>
<a href="http://lab.chempedia.com/">Chempedia Lab</a><br>
<a href="http://www.syntheticpages.org/">Synthetic Pages</a><br>
<a href="http://www.organic-chemistry.org/">Organic Chemistry Portal</a><br>
<a href="http://pubchem.ncbi.nlm.nih.gov/">PubChem</a><br>
<a href="http://chem.chem.rochester.edu/~nvd/index.html">Not Voodoo</a><br>
<a href="http://dailymed.nlm.nih.gov/dailymed/about.cfm">DailyMed</a><br>
<a href="http://www.druglib.com/">Druglib</a><br>
<a href="http://clinicaltrials.gov/">Clinicaltrials.gov</a><br>
<br>
Chemistry and Pharma Blogs:
<br>
<a href="http://blogs.forbes.com/sciencebizblog/">The Science Business</a><br>
<a href="http://orgprepdaily.wordpress.com/">Org Prep Daily</a><br>
<a href="http://kilomentor.chemicalblogs.com/">Kilomentor</a><br>
<a href=" http://community.pharmamanufacturing.com/onpharma">On Pharma</a><br>
<a href="http://kinasepro.wordpress.com/">Kinase Pro</a><br>
<a href="http://anewmerckreviewed.wordpress.com/">A New Merck, Reviewed</a><br>
<a href="http://blog.pharmaconduct.org/">Pharma Conduct</a></br>
<a href="http://walkerma.wordpress.com/">One in Ten Thousand</a><br>
<a href="http://periodictabloid.chemheritage.org/">Periodic Tabloid</a><br>
<a href="http://allthingsmetathesis.com/">All Things Metathesis</a><br>
<a href="http://cenblog.org/">C&E News Blog</a><br>
<a href="http://luysii.wordpress.com/">Chemiotics II</a><br>
<a href="http://chemicalspace.wordpress.com/">Chemical Space</a><br>
<a href="http://baoilleach.blogspot.com/">Noel O'Blog</a><br>
<a href="http://invivoblog.blogspot.com/">In Vivo Blog</a><br>
<a href="http://chigginbotham.blogspot.com/">Chirality</a><br>
<a href="http://madchemistchick.blogspot.com/">Mad Chemist Chick</a><br>
<a href="http://blogs.bbsrc.ac.uk/">BBSRC/Douglas Kell</a><br>
<a href="http://drugdiscoveryopinion.com/">Drug Discovery Opinion</a><br>
<a href="http://realizationsinbiostatistics.blogspot.com/">Realizations in Biostatistics</a><br>
<a href="http://chemjobber.blogspot.com">Chemjobber</a><br>
<a href="http://www.pharmalot.com">Pharmalot</a><br>
<a href="http://blogs.wsj.com/health/">WSJ Health Blog</a><br>
<a href="http://chemicalcrystallinity.blogspot.com/">Chemical Crystallinity</a><br>
<a href="http://www.chemspider.com/blog/">ChemSpider Blog</a><br>
<a href="http://pharmagossip.blogspot.com/">Pharmagossip</a><br>
<a href="http://synchemist.blogspot.com/">Med-Chemist</a><br>
<a href="http://usefulchem.blogspot.com/">Useful Chemistry</a><br>
<a href="http://chiraljones.wordpress.com/">Chiral Jones</a><br>
<a href="http://www.pharmastrategyblog.com/">Pharma Strategy Blog</a></br>
<a href="http://gmc2007.blogspot.com/">Great Molecular Crapshoot</a><br>
<a href="http://chem.vander-lingen.nl/">No Name No Slogan</a><br>
<a href="http://practicalfragments.blogspot.com/">Practical Fragments</a><br>
<a href="http://www.simbiosys.ca/blog/">SimBioSys</a><br>
<a href="http://cultureofchemistry.blogspot.com/">Culture of Chemistry</a><br>
<a href="http://ashutoshchemist.blogspot.com/">The Curious Wavefunction</a><br>
<a href="http://naturalproductman.wordpress.com/">Natural Product Man</a><br>
<a href="http://www.totallysynthetic.com/blog/index.php">Totally Synthetic</a><br>
<a href="http://zusammen.metamolecular.com/">Zusammen</a><br>
<a href="http://mychemicaljourney.blogspot.com/">My Chemical Journey</a><br>
<a href="http://fbdd-lit.blogspot.com/">Fragment Literature</a><br>
<a href="http://fluorous.com/journal/">The F- Blog</a><br>
<a href="http://www.rscweb.org/blogs/cw/">Chemistry World Blog</a><br>
<a href="http://syntheticnature.wordpress.com/">Synthetic Nature</a><br>
<a href="http://www.chemistry-blog.com/">Chemistry Blog</a><br>
<a href="http://syntheticorganic.blogspot.com/">Synthesizing Ideas</a><br>
<a href="http://www.coronene.com/blog/">Carbon-Based Curiosities</a><br>
<a href="http://fug-experimentalerror.blogspot.com/">Experimental Error</a><br>
<a href="http://mndoci.com/">Business|Bytes|Genes|Molecules</a><br>
<a href="http://www.eyeonfda.com">Eye on FDA</a><br>
<a href="http://chemblogs.com/sial_blog/">Sigma-Aldrich ChemBlogs</a><br>
<a href="http://chemicalforums.com/">Chemical Forums</a><br>
<a href="http://depth-first.com/">Depth-First</a><br>
<a href="http://blog.symyx.com/">Symyx Blog</a><br>
<a href="http://www.p212121.com/">P212121</a><br>
<a href="http://curlyarrow.blogspot.com/">Curly Arrow</a><br>
<a href="http://www.chemcafe.net/">ChemCafe</a><br>
<a href="http://fetzthechemist.wordpress.com/">Fetz the Chemist</a><br>
<a href="http://blogs.nature.com/thescepticalchymist/">Sceptical Chymist</a><br>
<a href="http://gaussling.wordpress.com/">Lamentations on Chemistry</a><br>
<a href="http://comporgchem.com/blog/">Computational Organic Chemistry</a><br>
<a href="http://miningdrugs.blogspot.com/">Mining Drugs</a><br>
<a href="http://www.ch.ic.ac.uk/rzepa/blog/">Henry Rzepa</a><br>
<br><br>
Science Blogs and News:
<br>
<a href=" http://www.badscience.net/">Bad Science</a><br>
<a href="http://blogs.discovermagazine.com/loom/">The Loom</a><br>
<a href="http://scienceblogs.com/principles/">Uncertain Principles</a><br>
<a href="http://www.fiercebiotech.com/">Fierce Biotech</a><br>
<a href="http://dimer.tamu.edu/simplog/?blogid=3">Blogs for Industry</a><br>
<a href="http://omicsomics.blogspot.com">Omics! Omics!</a><br>
<a href="http://youngfemalescientist.blogspot.com/">Young Female Scientist</a><br>
<a href="http://williamtozier.com/slurry">Notional Slurry</a><br>
<a href="http://blogs.usyd.edu.au/labrats/">Life of a Lab Rat</a><br>
<a href="http://arstechnica.com/journals/science.ars">Nobel Intent</a><br>
<a href="http://www.scitechdaily.com/">SciTech Daily</a><br>
<a href="http://somestuffiwrite.blogspot.com/">Is This Thing On?</a><br>
<a href="http://www.scienceblog.com/cms/index.php">Science Blog</a><br>
<a href="http://science.easternblot.net/">Eastern Blot</a><br>
<a href="http://www.futurepundit.com/">FuturePundit</a><br>
<a href="http://www.ghastlyfop.com/blog/index.html">Flags and Lollipops</a><br>
<a href="http://scienceblogs.com/aetiology/">Aetiology</a><br>
<a href="http://www.gnxp.com">Gene Expression (I)</a><br>
<a href="http://scienceblogs.com/gnxp/">Gene Expression (II)</a><br>
<a href="http://www.sciencebase.com/science-blog/">Sciencebase</a><br>
<a href="http://scienceblogs.com/pharyngula/">Pharyngula</a><br>
<a href="http://scienceblogs.com/ethicsandscience/">Adventures in Ethics and Science</a><br>
<a href="http://scienceblogs.com/terrasig/">Terra Sigillata</a><br>
<a href="http://www.transterrestrial.com">Transterrestrial Musings</a><br>
<a href="http://science.slashdot.org/">Slashdot Science</a><br>
<a href="http://labcoats.blogspot.com/">A Scientist's Life</a><br>
<a href="http://scienceblogs.com/grrlscientist/">Living the Scientific Life</a><br>
<a href="http://humans.scienceboard.net/">Humans in Science</a><br>
<a href="http://www.blog.speculist.com/">Speculist</a><br>
<a href="http://shrimpandgrits.rickandpatty.com/">Science, Shrimp and Grits</a><br>
<a href="http://blogs.discovermagazine.com/cosmicvariance/">Cosmic Variance</a><br>
<a href="http://www.dissolutionsolutions.net/">The Capsule</a><br>
<a href="http://zerothorderapprox.blogspot.com/">Zeroth Order Approximation</a><br>
<a href="http://library.lib.binghamton.edu/mt/science/">Science Library Blog</a><br>
<a href="http://www.biologynews.net/">Biology News Net</a><br>
<br><br>
Medical Blogs<br>
<a href="http://www.onemedplace.com/blog">Med Tech Sentinel</a><br>
<a href="http://www.medrants.com/">DB's Medical Rants</a><br>
<a href="http://www.sciencebasedmedicine.org/">Science-Based Medicine</a><br>
<a href="http://www.gruntdoc.com/">GruntDoc</a><br>
<a href="http://matthewholt.typepad.com/the_health_care_blog/">The Health Care Blog</a><br>
<a href="http://scienceblogs.com/insolence/">Respectful Insolence</a><br>
<a href="http://www.blacktriangle.org.uk/blog/">Black Triangle</a><br>
<a href="http://www.diabetesmine.com/">Diabetes Mine</a><br>
<br><br>
Economics and Business<br>
<a href="http://www.marginalrevolution.com/">Marginal Revolution</a><br>
<a href="http://econlog.econlib.org/">Arnold Kling</a><br>
<a href="http://volokh.com/">The Volokh Conspiracy</a><br>
<a href="http://www.knowledgeproblem.com">Knowledge Problem</a><br>
<a href="http://www.thestalwart.com/">The Stalwart</a><br>
<br><br>
Politics / Current Events<br>
<a href="http://www.dynamist.com/weblog/index.html">Virginia Postrel</a><br>
<a href="http://tinkertytonk.blogspot.com/">Tinkerty Tonk</a><br>
<a href="http://www.pajamasmedia.com/instapundit">Instapundit</a><br>
<a href="http://meganmcardle.theatlantic.com">Megan McArdle</a><br>
<a href="http://pajamasmedia.com/richardfernandez/>Belmont Club</a><br>
<a href="http://kausfiles.com/">Mickey Kaus</a><br>
<a href="http://colbycosh.com/">Colby Cosh</a><br>
<a href="http://www.aracnet.com/~dcf/pr/">Alien Corn</a><br>
<a href="http://nowatermelons.blogspot.com/">No Watermelons</a><br>
<br><br>
Belles Lettres<br>
<a href="http://2blowhards.com/">Two Blowhards</a><br>
<a href="http://www.erinoconnor.org/">Critical Mass</a><br>
<a href="http://aldaily.com/">Arts and Letters Daily</a><br>
<a href="http://www.godofthemachine.com/wordpress/">God of the Machine</a><br>
<a href="http://www.newcriterion.com/weblog/armavirumque.html">Armavirumque</a><br>
<a href="http://www.artsjournal.com/aboutlastnight/">About Last Night</a><br>
</div>
</td>
<td valign="top" width="100%">
<div class="bulletin"><div class="bulletin-background"><span class="bulletin-title">In the Pipeline:</span> Don't miss Derek Lowe's excellent commentary on drug discovery and the pharma industry in general at <strong><a href="http://pipeline.corante.com">In the Pipeline</strong></a></a></div></div>

<img src="http://www.corante.com/img/structural/spacecase.gif" border="0" width="350" height="1" />

<h2><a href="http://pipeline.corante.com/"><img class="blogtitle"  src="http://pipeline.corante.com/title.gif" alt="In the Pipeline" border="0" /></a></h2>

<div id="blog">
<div class="blogbody">

<p align="center">
<a href="http://pipeline.corante.com/archives/2006/07/31/hobsons_choice.php">&laquo; Hobson's Choice</a> |

<a href="http://pipeline.corante.com/">Main</a>
| <a href="http://pipeline.corante.com/archives/2006/08/02/a_law_of_the_lab_yields_and_variations.php">A Law of the Lab: Yields and Variations &raquo;</a>

</p>

<h4>
August  1, 2006
</h4>


<!--STANDARD ENTRY -->

<h3>Testosterone, Carbon Isotopes, and Floyd Landis</h3><span class="printemail"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#zemail"><img class="print" src="http://www.corante.com/frontpage/email.gif" alt="Email This Entry" border="0" /></a></span>

<p class="author">
Posted by <span class="authorname"></b>Derek</span>
</p>
<div class="img">
<p>The <i>New York Times</i> broke the <a href="http://www.nytimes.com/2006/08/01/sports/othersports/01landis.html?ei=5065&en=62f8b57a3bf5609d&ex=1155096000&partner=MYWAY&pagewanted=print">story</a> today that the testosterone found in <i>Tour de France</i> champion Floyd Landis's blood was not from a natural source. Just how do they know that, and how reliable is the test?</p>

<p>The first thing an anti-doping lab looks for in such a case is the ratio of <a href="http://en.wikipedia.org/wiki/Testosterone">testosterone</a> to the isomeric <a href="http://en.wikipedia.org/wiki/Epitestosterone">epitestosterone</a> - too high an imbalance is physiologically unlikely and arouses suspicion. Landis already is in trouble from that reading, but the subject of the <i>Times</i> scoop is the isotopic ratio of the testosterone itself. And that one is going to be hard to get away from, if it's true.</p>

<p><i>Update: people are asking me why athletes don't just take extra epistestosterone to even things out. That they do - that's the most basic form of masking, and if Landis's ratio was as far off as is being reported, it's one of the odd features about this case. But the isotope test will spot either one, if it's not the kind your body produces itself - read on.</i></p>

<p>Steroids, by weight, are mostly carbon atoms. Most of the carbon in the world is the C-12 isotope, six protons and six neutrons, but around one per cent of it has an extra neutron to make it C-13. Those are the <a href="http://en.wikipedia.org/wiki/Carbon_isotope">only stable</a> isotopes of carbon. You can find tiny bits of radioactive C-14, though, and you can also get C-11 if you have access to a particle accelerator. Work fast, though, because it's hot as a pistol.</p>

<p>So, testosterone has 19 carbon atoms, and if on average every one out of a hundred carbon atoms is a C-13, you can calculate the spread of molecular weights you could expect, and their relative abundance. One out of every ten thousand molecules would have two C-13 atoms in there somewhere, one out of every million or so would have three, and so on. A good <a href="http://en.wikipedia.org/wiki/Mass_spectrometry">mass spectrometer</a> will lay this data out for you like a deck of cards.</p>

<p>But here's the kicker: those isotopic forms of the elements behave a bit differently in chemical reactions. The heavier ones do the same things as their lighter cousins, but if they're involved in or near key bond-breaking or bond-making steps, they do them more slowly. It's like having a heavier ball attached to the other end of a spring. This is called a <a href="http://www.bookrags.com/sciences/chemistry/kinetic-isotope-effects-woc.html">kinetic isotope effect</a>, and chemists have found all sorts of weird and ingenious ways to expoit it. But it's been showing up for a lot longer than we've been around.</p>

<p>The enzymatic reactions that plants and bacteria use when they take up or form carbon dioxide have been slowly and relentlessly messing with the isotope ratios of carbon for hundreds of millions of years. And since decayed plants are food for other plants, and the living plants are food for animals, which are food for other animals and fertilizer for still more plants. . .over all this time, biological systems have become enriched in the lighter, faster-reacting C-12 isotope, while the rest of the nonliving world has become a bit heavier in C-13. You can sample the air next to a bunch of plants and <a href="http://basinisotopes.org/basin/tutorial/gifs_2/diurnal_variation.html">watch</a> as they switch from daytime photosynthesis to nighttime respiration, just based on the carbon isotope ratios. Ridiculously tiny variations in these things can now be observed, which have led to all sorts of <a href="http://www.science.utah.edu/ehleringer2.html">unlikely</a> applications, from determining where particular batches of cocaine came from to figuring out the <a href="http://basinisotopes.org/basin/tutorial/enviro_history.html">dietary preferences</a> of extinct herbivores.</p>

<p>So, if your body is just naturally cranking out the testosterone, it's going to have a particular isotopic signature. But if you're taking the synthetic stuff, which has been <s>partly worked on with abiotic forms of carbon</s> derived from a different source (see below), the <a href="http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?itool=abstractplus&db=pubmed&cmd=Retrieve&dopt=abstractplus&list_uids=11159778">fingerprints</a>  will <a href="http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&list_uids=11272321&dopt=Abstract<br />
">show</a>. <i>(Update: yes, this means that the difference between commercial testosterone and the body's own supply isn't as large as it would be otherwise, since the commercial synthesis generally starts from plant-derived steroid backbones. But it's still nothing that a good mass spec lab would miss).</i> If the news reports are right, that's what Landis's blood samples have shown. And if they have, there seems only one unfortunate conclusion to be drawn.</p>

<p>Chem-Geek Supplemental Update: for the folks who have been wondering where exactly the isotopic difference comes in, here's the story: synthetic testosterone is made from phytosterol percursors, typically derived from wild yams or soy. Those are both warm-climate C3 plants, which take up atmospheric carbon dioxide by a different route than temperate-zone C4 plants, leading to noticeably different isotope ratios. That's where all the isotope-driven studies of diet start from. The typical Western industrial-country diet is derived from a mixture of C3 and C4 stocks, so the appearance of testosterone with a C3-plant isotopic profile is diagnostic.</p>
<a name="more"></a>
</div>


<p class="posted">
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#comments">Comments (298) </a>
</MTEntryIfAllowComments>+ <a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#comments">TrackBacks (0)</a> | Category: <a href="http://pipeline.corante.com/archives/analytical_chemistry/">Analytical Chemistry</a> | <a href="http://pipeline.corante.com/archives/current_events/">Current Events</a> 
</p>



<!-- BLINK -->



<!-- SPONSORED POST -->


 


<br />

<!-- COMMENTS DISPLAY -->




<div class="comments">
<a name="comments"></a><b>COMMENTS</b>
<div id="commentflip">
<p class="commentsbody"><a name="130994"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#130994">1. </a></span><span style="color:#036">T Rivard </span> on August  1, 2006 10:22 PM writes...</p>
<p>I don't trust the french labs.  If Landis loses, who wins?  I believe that Landis earned it fairly and is being set up.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#130994">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="130995"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#130995">2. </a></span><span style="color:#036">Process Wannabe </span> on August  1, 2006 10:37 PM writes...</p>
<p>My question is about some comments Landis' physician made, how taking synthetic testosterone would be pretty pointless for a competative cyclist.  His argument that the testosterone would only help build muscle mass, but wouldn't help the type of endurance competition found in the Tour de France.  He also pointed out that taking a shot of testosterone during the competition would not give the sort of "pick-me-up" seen in Landis' miracle come-back.  Because of these points, he says that there'd be no benefit to the testosterone, so that was his evidence for Landis' innocence.  What sort of validity do these claims have?</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#130995">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="130996"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#130996">3. </a></span><span style="color:#036">Jumbo </span> on August  1, 2006 10:44 PM writes...</p>
<p>A little less vociferously than T, I would nonetheless ask those reading who are isotopically inclined, what is the actual reliability of the isotope assay? I find it a strange coincidence that two internationally prominent athletes (Landis and the sprinter Gaitlin) turn up testosterone postive in the same week. These are athletes that have a remarkably sophisticated understanding of the physiological effects of steroids. Unless Landis has made a startling breakthrough, taking exogenous testosterone 4 days before the end of the Tour would be extremely unlikely to have a beneficial effect on performance. Derek himself has shown that assay reproducibility (the notorious vial 33) is hard to come by. But likewise, having 2 assays agree is not a guarantee that the positive result is true. It all just seems strange to me...</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#130996">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="130999"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#130999">4. </a></span><span style="color:#036">GC </span> on August  1, 2006 11:32 PM writes...</p>
<p>Carbon in testosterone is ultimately derived from acetate, which comes from any number of sugars (or amino acids, occasionally). Who's to say he wasn't taking some snake-oil supplement (say, synthetic D-ribose or amino acids) and it didn't make its way in through the pentose phosphate pathway, transaminases, etc?</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#130999">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131001"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131001">5. </a></span><span style="color:#036">Justin </span> on August  1, 2006 11:39 PM writes...</p>
<p>I cant help but think that Mr Landis has put himself in this mess by his own actions.</p>

<p>If he did administer or was administered testosterone, then he is a fool who deserves to be caught and banned. Unfortunately, I think we will never know the truth about this point. After all, Mr Landis is hardly gonna stand up and say 'I did it' while there are other defenses around.</p>

<p>And speaking of other defences, what if Mr Landis' claim of elevated testosterone levels due to alcohol consumption is true? Who administered the alcohol? Mr Landis. Who claims that he has a history of high T/E ratios? Mr Landis. Who is an elite athelete with knowledge of his elevated T/E ratios and, more than likely, a knowledge of the effects of alcohol on that ratio? Mr Landis. If this latter point is in doubt (concerning Mr. Landis' knowledge of the effects of alcohol on T/E ratios), then who is surrounded by people who could advise/warn/caution on the use of alcohol during competition? You guessed it - Mr. Landis.</p>

<p>Mr Landis drank the alcohol himself. However, I severely question his wisdom of doing this during a big race AND the collective wisdom of his team for letting him do it! I also find it hard to believe that his team bosses and doctors and dieticians and whoever else helps Mr Landis with his elite training would not have warned him about the risks of drinking too much alcohol during a competition - especially with the already documented effects that alcohol can have on human physiology! Are we to understand that Mr. Landis sat and drunk alone that fateful night? That nobody knew what he was doing? And if he was alone, then I go back to the previous point about the wisdom of drinking alcohol during a competition.</p>

<p>A knowledge of the drug testing rules and regulations MUST be know by someone in a professional cycling team, especially given the number of scandals abounding in this sport. The knowledge MUST be passed onto the riders for their own protection. Those riders MUST understand the risks involved with putting things into their bodies - illegal or otherwise.</p>

<p>This whole issue is a sorry state of affairs for everyone involved AND the sport of pro cycling. But the rules and regulations are clear and available to see for all concerned. As are the consequences.</p>

<p>Im afraid Mr Landis has to take some responsibility for the sticky situation he finds himself in.</p>

<p>Although 'innocent until proven guilty' is a legal principal, cannot the same be said about 'ignorance of the law is no defence against breaking the law'....?</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131001">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131002"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131002">6. </a></span><span style="color:#036">dopingbust </span> on August  2, 2006 12:14 AM writes...</p>
<p>American cyclists continue to dominate the Tour, and, the French, as well as others will continue to contest with allegations of wrongdoing. Floyd kickes the French and Spanish asses of those on the tour, whether he loses the title or not, we know he beat them all. Period.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131002">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131016"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131016">7. </a></span><span style="color:#036">Louise </span> on August  2, 2006  3:17 AM writes...</p>
<p>what I would like to know....why don't the dopesters also ingest epitestosterone?</p>

<p>Is it possible?</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131016">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131019"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131019">8. </a></span><span style="color:#036">jojo </span> on August  2, 2006  4:54 AM writes...</p>
<p>Boohoooo it's the french's fault, they hate us, Floyd is innocent, he's not a cheater, we are the best<br />
Hahahahahahahahahahahahahah<br />
Pathetic <br />
but very funny</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131019">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131020"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131020">9. </a></span><span style="color:#036">bob </span> on August  2, 2006  6:34 AM writes...</p>
<p>1. If you can clearly test for synthetic testosterone, why bother doing a ratio test for high levels. Wouldn't they just test for the synthetic substance?</p>

<p>2. How can you raise your "natural" levels of testosterone in an illegal manner?</p>

<p>These seem like the real questions to me?</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131020">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131023"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131023">10. </a></span><span style="color:#036">Realist </span> on August  2, 2006  6:48 AM writes...</p>
<p>The nationaliy of Landis is irrelavant. He failed the test and should be punished accordingly.</p>

<p>All the talk of conspiracies on this page are as embaressing and outlandish as the list of excuses Landis has trotted out so far.</p>

<p>As the saying goes, 'love is blind'.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131023">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131025"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131025">11. </a></span><span style="color:#036">Still Scared of Dinosaurs </span> on August  2, 2006  7:22 AM writes...</p>
<p>The simplest answer would be that he was unwittingly dosed with an agent that was very likely to show up in testing. I've been expecting this to happen for real some time-imagine what would happen if you could hit the right players from an NFL or MLB team and bet against them.<br />
I've also been expecting this to be used as an excuse, valid or not, but haven't seen it yet.<br />
What I don't understand is why we don't have unmasking agents for commercially available drugs like steroids, with greatly increased penalties for possession of drugs without the markers. There was a (sort of) precedent for this once where explosives had microscopic inclusions that would identify the production lot, but the industry had the law mandating them overturned. </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131025">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131026"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131026">12. </a></span><span style="color:#036">MTK </span> on August  2, 2006  7:37 AM writes...</p>
<p>I really don't care whether Landis is innocent or not, becuase I think the whole system is a sham.  The definition of cheating vs. advanced training and nutrition is so arbitrary it means nothing.  Throw in the fact that the testing labs and agencies themselves seem to be up to shenanigans and you've got a total snakepit.  If you don't believe me then read the Dutch arbiter's report which exonerated Armstrong in the latest EPO allegations.  It's a farce.</p>

<p>More to the science point.  I still don't quite understand the isotope thing.  For one thing, I'm assuming that synthetic testosterone is actually semi-synthetic made from some sterol from yams, soybeans, or something, so wouldn't it also be deficient in 13C?  The other thing is let's say that synthetic testosterone is enriched in 13C, and let's say in theory this whole thing works, how was the doping control test validated?  Did they actually shoot some people up, take urine samples, and do blind studies?</p>

<p>Wondering, <br />
MTK</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131026">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131027"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131027">13. </a></span><span style="color:#036"><a href="http://www.jhn1.blogspot.com" rel="nofollow">J'hn1</a> </span> on August  2, 2006  7:45 AM writes...</p>
<p>Well, the "markers" or taggents, are included in civilian explosives. They were to be included in certain compounds that could easily be used to make explosives. <br />
Fertilizer.<br />
The markers in question did not break down in the soil, and the proponents admitted that they could not guarantee that the taggents would not end up contaminating the entire US food supply.The supporters also were not willing to assume the liability for their doing so.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131027">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131028"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131028">14. </a></span><span style="color:#036">Phil-Z </span> on August  2, 2006  7:51 AM writes...</p>
<p>The carbon isotope ratio has been used to determine if a food additive or vitamin is "natural" or "not" for at least a decade. It's easy enough to get around if you start with non petrochemical feedstocks and let fermentation do a lot of your work for you. Pretty clever, using this to spot doping.<br />
I doubt he could have consumed enough C-13 enriched food to make a difference without it killing him. No doubt everyones already heard the old tale about the "deuterated dog" experiment and understands the enzyme kinetics implications of using "heavy" food.<br />
(Supposedly a mug of D2O coffee would be enough to kill someone and would be nearly undetectable. I await publication of the murder mystery featuring this plot device. Mass Spectroscopists finally star!)<br />
If as stated above testosterone would have no noticable effect and if he's really a big time social drinker it would have been trivial to slip him some when he was at a bar. <br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131028">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131031"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131031">15. </a></span><span style="color:#036">Pat Rand </span> on August  2, 2006  7:59 AM writes...</p>
<p>Interesting that the "doping" showed up only on the single most spectacular leg of the event.  I thought that these compounds were more persistent in the bloodstream...traceable even several days after an event.  Also, aren't the heavier carbon isotopes more abundantly available in the atmosphere, especially at higher elevations?</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131031">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131033"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131033">16. </a></span><span style="color:#036">Hmmm </span> on August  2, 2006  8:02 AM writes...</p>
<p>Some rumors are circulating that he wasn't purposely using testerone.  Instead he was blood doping (which they do not have a test for) and used a bag from earlier in the year when he was using testerone on accident.  Would this be possible?</p>

<p>If so it would explain why he used it when there was no apparent benefit to using it.  </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131033">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131034"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131034">17. </a></span><span style="color:#036">Kenneth Payne </span> on August  2, 2006  8:05 AM writes...</p>
<p>Hi</p>

<p>Excellent piece--very informative and clearly written. You should consider writing one of those popular science books that I can't get enough of. The world could benefit from another Timothy Ferris.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131034">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131035"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131035">18. </a></span><span style="color:#036">Process Chemist </span> on August  2, 2006  8:10 AM writes...</p>
<p>The entire sport of cycling is a fraud. 100% of the athletes running the big races are under some sort of performance enhancing treatment or drug.</p>

<p>These guys put their bodies in the hands of doctors who tell them what they have to take. If everything goes well, the doctors will get their doses right and the tests will be negative. One little screw up will make news headlines and all the guilt will be placed on the athlete, ruining his career.</p>

<p>If you ask me, let's just ban competitive cycling, for the sake of those poor guinea pigs.</p>

<p>Defending Landis just because he's American and claiming a French conspiracy is just plain pathetic. </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131035">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131036"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131036">19. </a></span><span style="color:#036"><a href="http://www.jbgstudiosupply.net" rel="nofollow">Bryan</a> </span> on August  2, 2006  8:13 AM writes...</p>
<p>In response to Justin; It is a common practice for cyclists to have a few drinks after a stage win or defeat.  Read any cyclists book and you will almost always find a paragraph or two about the "Night at the bar".</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131036">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131037"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131037">20. </a></span><span style="color:#036">Realist </span> on August  2, 2006  8:22 AM writes...</p>
<p>Please can everyone stop this "The simplest answer would be that he was unwittingly dosed...", "it would have been trivial to slip him some when he was at a bar.." and so forth.</p>

<p>The simplest answer is that he cheated and was caught. </p>

<p>People may not like it, but the facts are he failed a test.</p>

<p>Like Millar and Virenque before him, he'd be doing himself and the sport a great favour by admitting to his mistake. Sadly from his actions to date and these posts, it seems denial is part of the American psyche. </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131037">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131041"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131041">21. </a></span><span style="color:#036">Brian Moore </span> on August  2, 2006  8:33 AM writes...</p>
<p>Thank you for your lucid, infomative, and entertaining explanation of Landis's problem.</p>

<p>I used to be a literary agent, years ago. If you had the right idea, I'm pretty sure you could sell a mass market oriented science book. You can flat-out write, which is rare in your field.</p>

<p>Good luck to you.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131041">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131042"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131042">22. </a></span><span style="color:#036">davod </span> on August  2, 2006  8:43 AM writes...</p>
<p>How many times did the authorities accuse the other American champion (sorry, I am not a fan of cycling) of using drugs. I beleive it was something like six times?</p>

<p>Initially, everyone was saying this cyclist must be guilty as this was the simplest solution. He was not guilty.</p>

<p>I am sceptical of any drug testing.  </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131042">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131044"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131044">23. </a></span><span style="color:#036"><a href="http://www.jbgstudiosupply.net" rel="nofollow">Bryan</a> </span> on August  2, 2006  8:43 AM writes...</p>
<p>I’m not saying that some one slipped him something in the bar.  But if alcohol does have an effect then we should wait until the B test is released.  If he is guilty then strip him of the win and ban him from the sport, not just for two years but permanently!   I think that we are too lenient on professional athletes; if they are caught then they should be banned for life.  Taking their lively hood might make the rest of them stop and think before they try to chemically enhance their performance. </p>

<p>As far as Floyd is concerned I think we should wait for the results.  Too many times, especially in cycling, these tests have been overturned.  <br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131044">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131045"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131045">24. </a></span><span style="color:#036">PharmaChemist </span> on August  2, 2006  8:46 AM writes...</p>
<p>Like MTK (post #12 above), I still don't quite understand why supplemental T would have a different isotope level than endogenously produced testosterone.  Isn't the feedstock for synthetic/semi-synthetic testosterone obtained from a plant or animal?  Or is it a petroleum-based feedstock?  Clearly the links that Derek refer to show that there is a difference in the isotopic ratios but I don't understand why this would be unless the synthetic T is derived from a non-living feedstock.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131045">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131049"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131049">25. </a></span><span style="color:#036">grayp </span> on August  2, 2006  9:00 AM writes...</p>
<p>I am the last person on the planet qualified to comment on the chemistry/biology involved.  But there is one aspect of all this that really befuddles me.</p>

<p>Why on earth would Landis (or anyone else, for that matter) knowingly take a banned drug/supplement they knew would be detected in mandatory testing?</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131049">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131050"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131050">26. </a></span><span style="color:#036">Ron Nelson </span> on August  2, 2006  9:00 AM writes...</p>
<p>In response to Justin (post #5), it must be remembered that Floyd had "lost" the Tour in Stage 16. So what was the harm (thinking at the time) of doing a bender? This would not have been an issue if Floyd's "what the hell" ride in Stage 17 had been contested earlier by the teams that were leading after Stage 16. It's easy to see now what a mistake it was to drink away the blues, but at the time no one thought there was anything to lose.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131050">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131051"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131051">27. </a></span><span style="color:#036">ian </span> on August  2, 2006  9:00 AM writes...</p>
<p>I appreciate the article. It is my understanding that Landis' prior and subsequent tests at the Tour were normal. Is that explainable?  </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131051">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131052"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131052">28. </a></span><span style="color:#036"><a href="http://robot_guy.blogspot.com" rel="nofollow">Ed Minchau</a> </span> on August  2, 2006  9:10 AM writes...</p>
<p>Fact is, Landis made it from point A to point B faster than anyone else.  As MTK (#12) pointed out, the difference between cheating and advanced training and nutrition is trivial.  The only problem with Landis is that he got caught.  The only reason Florence Griffith-Joyner kept her gold medal was that she didn't get caught (although the mustache should have been a dead giveaway).</p>

<p>To hell with it.  If atheletes want to juice up, let them.  Who cares if they kill themselves doing it?  They are only there for our amusement anyhow.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131052">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131053"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131053">29. </a></span><span style="color:#036">JBass </span> on August  2, 2006  9:22 AM writes...</p>
<p>I'm an analytical/physical chemist.  Derek, do you have any links to papers that actually show mass spectrograms which differentiate synthetic and natural testosterone?</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131053">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131054"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131054">30. </a></span><span style="color:#036"><a href="http://www.jbgstudiosupply.net" rel="nofollow">Bryan</a> </span> on August  2, 2006  9:26 AM writes...</p>
<p>Ed, you are right; they are there for our entertainment, and so what if they kill them selves.  But if you let it happen then you are telling the future generations of athletes that they will have to do it to compete.  I don’t want any of the kids in my family to think that the only way to win is to juice up.  By the way, at least she shaved before she took the podium!</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131054">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131055"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131055">31. </a></span><span style="color:#036">absorber </span> on August  2, 2006  9:29 AM writes...</p>
<p>Does anyone know about the skin absorbability of this stuff?  It makes a difference if you start examining the sabotage possibilities.  You see these guys getting cups from fans at the side of the road amd then dumping it over their backs to cool off. </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131055">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131056"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131056">32. </a></span><span style="color:#036">Reid </span> on August  2, 2006  9:35 AM writes...</p>
<p>Agree with #21. This was well written.</p>

<p>To others on both sides, you are not compelled to reach a verdict before all the evidence is in. Yes, he could have been set up. Yes, he could be guilty. Let's just wait and see, huh?</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131056">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131057"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131057">33. </a></span><span style="color:#036"><a href="http://www.rknibbe.com/blog" rel="nofollow">RKN</a> </span> on August  2, 2006  9:36 AM writes...</p>
<p>Derek, <a href="http://www.rknibbe.com/ak/2006/07/28.html#a470" rel="nofollow">Curious minds wonder alike.</a> ;-)</p>

<p> <b>...</b></p>

<p>&nbsp;&nbsp;<i>what is the actual reliability of the isotope assay?</i></p>

<p><a>Evidently pretty reliable.</a></p>

<p><i>&nbsp;&nbsp;The entire sport of cycling is a fraud. 100% of the athletes running the big races are under some sort of performance enhancing treatment or drug.</i></p>

<p> Your evidence for this is where?</p>

<p><i>&nbsp;&nbsp;I still don't quite understand why supplemental T would have a different isotope level than endogenously produced testosterone.</i></p>

<p> Endogenously produced T is a metabolic derivative  of cholesterol (in eukaryotes) which, as I understand it, has a certain c13/c12 ratio in every individual. Hence, endogenous T will also have this ratio. Synthetic forms of T are, I think, depleted in their c13 content. If synthetic forms of T are present in the overall pool of T in your urine, the expected ratio of c13/c12 will be different than expected (i.e. if it was all endogenous), and this can be detected on a decent mass spectrometer. </p>

<p><i>&nbsp;&nbsp;2. How can you raise your "natural" levels of testosterone in an illegal manner?</i></p>

<p> That seems irrelevant at this point, since the CIR test concluded exogenous testosterone was present. The puzzling question that remains is why Landis would dope himself the night before stage 17 when, by most reports, it would do nothing to improve his performance on the bike the next day. I did read one report that claimed a BIG spike in testosterone could have swift effects, but I haven't seen this corroborated.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131057">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131058"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131058">34. </a></span><span style="color:#036">UncleHoot </span> on August  2, 2006  9:39 AM writes...</p>
<p>Cortisone injections?</p>

<p>Floyd Landis admits that he was taking daily cortisone injections.  Presumably, this is a synthetic drug and would show the same elevated levels of Carbon 13.  It's strange that I haven't even heard this mentioned.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131058">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131059"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131059">35. </a></span><span style="color:#036">Another Bob </span> on August  2, 2006  9:41 AM writes...</p>
<p>While the biochemistry discussion is interesting, the two main points remain unaddressed.</p>

<p>One (as someone asked above), why would Landis take something that he *knew* would be detected?</p>

<p>Two, can chain-of-custody of the samples be reliably documented?</p>

<p>A third point might be to ask whether the testing process is as cut-and-dried as is suggested here.  I have my doubts, but am not qualified to pursue it.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131059">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131061"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131061">36. </a></span><span style="color:#036">PCT </span> on August  2, 2006  9:47 AM writes...</p>
<p>In your final paragraph, you discuss "warm-climate C3 plants" and "temperate zone C4 plants." This is new terminology to me. Could you point to a reference?</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131061">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131063"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131063">37. </a></span><span style="color:#036">Jeff </span> on August  2, 2006  9:47 AM writes...</p>
<p>Testosterone can be absorbed through the skin (in a non estered form), just look up male hormone replacement therapy and Androgel.<br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131063">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131064"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131064">38. </a></span><span style="color:#036"><a href="http://www.rknibbe.com/blog" rel="nofollow">RKN</a> </span> on August  2, 2006  9:54 AM writes...</p>
<p>&nbsp;&nbsp;<i>Floyd Landis admits that he was taking daily cortisone injections. Presumably, this is a synthetic drug and would show the same elevated levels of Carbon 13. It's strange that I haven't even heard this mentioned.</i></p>

<p> The molecular mass of cortisone and testosterone are different (~290 vs ~360). I think the ion products on the mass spec would therefore be differentiable, as would the respective c13/c12 ratios in the two. </p>

<p>It is not simply a matter of measuring the total amount of c13 in the urine sample, it's the ratio of c13/c12 in testosterone, *specifically*, that's of interest.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131064">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131065"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131065">39. </a></span><span style="color:#036">Sam </span> on August  2, 2006 10:02 AM writes...</p>
<p>#33: It was well known that Landis was receiving cortisone injections--it had been previously cleared with the race authorities.  The cortisone injections were for his hip, Landis is suffering from osteonecrosis, a degenerative bone condition, caused by a crash from several years ago.  He needs and intends to get a hip replacement later this year.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131065">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131066"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131066">40. </a></span><span style="color:#036"><a href="http://www.jbgstudiosupply.net" rel="nofollow">Bryan</a> </span> on August  2, 2006 10:05 AM writes...</p>
<p>Nobody sabotaged him, nobody set him up.  There are only two answers; He is either really stupid and juiced, or the test results were misleading.  Either way we will not know until Saturday when the B Test results are published.</p>

<p>I personally hope that he is cleared of the charges, although at this stage it will always be remembered as a tainted victory.  </p>

<p>If he is innocent then it was probably the single greatest comeback in sports history, if he is guilty, then take the win away and ban him for life.<br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131066">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131068"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131068">41. </a></span><span style="color:#036">ajfakjw4e3tjh21 </span> on August  2, 2006 10:06 AM writes...</p>
<p>Why would anyone who knows he will be tested take anything that would disqualify him?</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131068">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131069"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131069">42. </a></span><span style="color:#036"><a href="http://www.jbgstudiosupply.net" rel="nofollow">Bryan</a> </span> on August  2, 2006 10:11 AM writes...</p>
<p>Fame and fortune make otherwise smart people do stupid things.  Just look at baseball.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131069">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131070"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131070">43. </a></span><span style="color:#036"><a href="http://pipeline.corante.com" rel="nofollow">Derek Lowe</a> </span> on August  2, 2006 10:14 AM writes...</p>
<p>Here are some literature references, as requested. For mass spectra of testosterone, see  J. Chromatog. B (2006),  831(1-2),  324-327; Current Organic Chemistry  (2005),  9(9),  825-848; and J. Chromatog. A  (2005),  1067(1-2),  323-330. Note that that last reference applies to doping in cattle!</p>

<p>For C3-C4 plants and photosynthesis, see <a href="http://en.wikipedia.org/wiki/C4_photosynthesis" rel="nofollow">here</a> and <a href="http://en.wikipedia.org/wiki/C3_carbon_fixation" rel="nofollow">here</a> from Wikipedia, and <a href="http://www.co2science.org/scripts/CO2ScienceB2C/subject/b/summaries/biodivc3vsc4.jsp" rel="nofollow">here</a> as well. </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131070">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131072"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131072">44. </a></span><span style="color:#036">mike </span> on August  2, 2006 10:18 AM writes...</p>
<p>The whole issue of 'cheating' is meaningless. Who cares? Right now some people luck into having a superior genetic profile for a given sport.</p>

<p>One guy might naturally produce more testosterone or be more efficient at using oxygen. Why shouldn't somebody else use modern biochem to even the playing field?</p>

<p>As has been pointed out: the difference between 'cheating' and good training and nutrition is meaningless -- it's all about modifying and optimizing your biochemistry. And the biggest 'cheat' of all is the starting genetic lottery.</p>

<p>Sports should just let people inject whatever they want and try to publish any known negative long term health consequences, so athletes can make more informed decisions about the risks they take.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131072">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131073"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131073">45. </a></span><span style="color:#036">rjschwarz </span> on August  2, 2006 10:21 AM writes...</p>
<p>Maybe they need to take a before and after bloodsample and check all this stuff before the race starts so the sample can simply be a confirmation that the person is still clean.</p>

<p>Maybe the French need to have an international board verify the results since clearly Gaulic pride is not trusted.</p>

<p>Maybe someone should check Landis's head if he *did* cheat and thought the French wouldn't look at every possibility under a microscope after being dominated by Lance for so many years.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131073">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131074"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131074">46. </a></span><span style="color:#036">Anonymous </span> on August  2, 2006 10:30 AM writes...</p>
<p>"One (as someone asked above), why would Landis take something that he *knew* would be detected?"</p>

<p>Because they usually aren't. The athletes are so far ahead of the testers it isn't close. Did Ullrich and Basso (banned before the tour) ever test positive? Did the Austrian X-country skiers caught in a house with a virtual lab full of drugs and needles during the olympics ever test positive? Are there really only about a dozen NFL players out of 1500 using PEDs?</p>

<p>Davod is right to be skeptical, but not about false positives. False negatives are a much bigger problem.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131074">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131075"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131075">47. </a></span><span style="color:#036"><a href="http://www.rknibbe.com/blog" rel="nofollow">RKN</a> </span> on August  2, 2006 10:30 AM writes...</p>
<p><br />
My earlier link didn't parse properly:</p>

<p>"Performance characteristics of a carbon isotope ratio method for detecting doping with testosterone based on urine diols: controls and athletes with elevated testosterone/epitestosterone ratios."</p>

<p> Full article: <a href="http://tinylink.com/?8yiYrGb5KK" rel="nofollow"><a href="http://tinylink.com/?8yiYrGb5KK" rel="nofollow">http://tinylink.com/?8yiYrGb5KK</a></a></p>

<p><br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131075">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131076"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131076">48. </a></span><span style="color:#036">Bart Hall (Kansas, USA) </span> on August  2, 2006 10:37 AM writes...</p>
<p>"synthetic testosterone is made from phytosterol percursors, typically derived from wild yams or soy. Those are both warm-climate C3 plants, which take up atmospheric carbon dioxide by a different route than temperate-zone C4 plants, leading to noticeably different isotope ratio"</p>

<p>I'm an agronomist and soil chemist by training. You don't quite have it right. Yams and soy are indeed C3 plants (glycerol pathway), and they like warm climates, but C4 plants (oxalacetic pathway) are <i>not</i> temperate zone plants.</p>

<p>C4s such as maize(corn) and sugarcane are noticeably enriched in 13C compared to all the C3s, including soy and yams.</p>

<p>Where this gets interesting is that the standard American diet gets substantial amounts of its carbon from C4 plants, the Europeans get nearly all of their carbon from cereals, potatoes, and beet sugar, all of which are 13C impoverished compared to an American diet.</p>

<p>I don't know the specifics of the Landis testing, but I would expect natural testosterone in an American to be 13C-enriched compared to a European. If derived from soybean and yam phytosterols, synthetic testosterone should be relatively <i>LOWER</i> in 13C than an American's natural hormone.</p>

<p>Soybean or yam-derived synthetic testosterone should display an isotopic ratio much closer to the natural testosterone of a European, and if a European lab is flagging high 13C in an American as a sign of synthetic testosterone I think they may be missing an important factor.  </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131076">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131077"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131077">49. </a></span><span style="color:#036">tommy </span> on August  2, 2006 11:13 AM writes...</p>
<p>France uses the Napoleonic Code where it is guilty until you prove yourself innocent.<br />
  I am in a profession that require random drug and alcohol testing. Positives occur at a very low level and most entirely for alcohol. Smart people will do stupid things.<br />
  Riders never take water or anything else from unknown spectators along the coarse. Riders have been poisoned or doped this way in the past.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131077">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131078"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131078">50. </a></span><span style="color:#036"><a href="http://pipeline.corante.com" rel="nofollow">Derek Lowe</a> </span> on August  2, 2006 11:13 AM writes...</p>
<p>Bart Hall's comment is very interesting, but I don't think that it will quite explain the test results. That J. Chrom. B reference I listed in comment #43, for example, addresses this point directly. While they did see measurable changes, still:</p>

<p><i>"Throughout the study, the subjects were living in Switzerland and were residing every year for a month or two in an African country. . .  The steroids of interest in each sample did not show significant isotopic fractionation that could lead to false positive results in anti-doping testing."</i></p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131078">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131079"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131079">51. </a></span><span style="color:#036">Jim Hu </span> on August  2, 2006 11:14 AM writes...</p>
<p>#47 Bart Hall,<br />
Interesting idea.  This would show up in other metabolites.  I wonder if they do controls for diet.</p>

<p>The NYT piece says the 13C test was only "mildly elevated".  Who knows what that means?<br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131079">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131080"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131080">52. </a></span><span style="color:#036">MTK </span> on August  2, 2006 11:23 AM writes...</p>
<p>Alright, Bart Hall, that's a nice twist.  </p>

<p>This is what I meant in my previous post about how is this type of test appropriately validated.<br />
Like I said, the whole thing is a farce.  </p>

<p>And to RKN (post #38)I think that they actually measure metabolites of testosterone in the urine and not testerone itself, so the questions becomes what happens to the testosterone vs. what happens to cortisone metabolically.  I still think you're right, thought, that it's easy to tell the difference.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131080">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131081"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131081">53. </a></span><span style="color:#036">Novice Chemist </span> on August  2, 2006  2:25 PM writes...</p>
<p>I have a poll question for all, but especially those who believe in false negatives. </p>

<p>Are doping athletes rarely caught:</p>

<p>A. because of difficulty in testing?<br />
B. because of advances in masking?<br />
C. because of advances coming from clandestine sources?</p>

<p>I have always doubted (C), because I believe that it's impractical for there to be a team somewhere of Ph.D. chemists making medchem-type analogues of known PEDs.  I am more willing to believe that there are MDs who may be willing to help abusers obtain legal drugs that can be misused, but that's just my personal bias. P.S. I am aware of the history of THG -- I think it's the exception that proves the rule.</p>

<p>My vote is (A) -- it's probably difficult to obtain enough to detect. Short of collecting athletes blood, sweat and urine 24/7, that is.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131081">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131082"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131082">54. </a></span><span style="color:#036">MTK </span> on August  2, 2006  2:44 PM writes...</p>
<p>Derek, </p>

<p>In regard to the comment in the J. Chrom. paper, does anyone know the metabolic carbon turnover?  What is the effect of a lifelong high C4 diet vs. a month-long diet?  These Swiss that spent a month in Africa, did they take cases of muesli with them?  OK, being facetious there, but I guess I'm just not convinced this test has been validated enough.  </p>

<p>Even if dietary changes were not enough to trip a false positive, doesn't the fact that it influences the base level, mean the test as a doping control is faulty?  In other words, somone on a high beet sugar/low sugarcane diet has more room to dope before crossing the threshold than someone who doesn't.</p>

<p>In the days before direct EPO testing, the International Cycling Union (UCI) used hematocrit levels as a de facto marker.  If your hematocrit was over 50 you were out of the race.  Well, guess what.  In the 90's the average hematocrit level in cyclists increased as people manipulated their EPO dosages to get as close to 50 as possible without going over.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131082">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131083"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131083">55. </a></span><span style="color:#036">dan </span> on August  2, 2006  2:45 PM writes...</p>
<p>Re the influence of diet: The NYT article says that the test actually compares the isotopic ratio in testosterone to the ratio in another hormone (cholesterol?) A difference of more than 3% constitutes a positive test. Landis came in at approx. 4%.</p>

<p>It sounds like a very tough rap to beat. Sad.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131083">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131084"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131084">56. </a></span><span style="color:#036">Chrispy </span> on August  2, 2006  2:47 PM writes...</p>
<p><br />
If using banned drugs would make one more competitive, and some athletes in the competition have been shown to use banned drugs and are not more competitive, then it follows that ALL the athletes are using these drugs.</p>

<p>These drugs are highly effective, and they ALL take them IMHO.</p>

<p>And I agree -- let 'em train as they see fit.  And let them ride recumbent bycles for that matter, too!</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131084">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131085"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131085">57. </a></span><span style="color:#036">Joe </span> on August  2, 2006  2:54 PM writes...</p>
<p>intersting...</p>

<p>"But Trevor Graham, Gatlin's coach, has contended Gatlin was the victim of a vengeful massage therapist who rubbed testosterone cream on his legs without his knowledge. </p>

<p><a href="http://sports.espn.go.com/oly/trackandfield/news/story?id=2537229&campaign=rss&source=ESPNHeadlines" rel="nofollow"><a href="http://sports.espn.go.com/oly/trackandfield/news/story?id=2537229&campaign=rss&source=ESPNHeadlines" rel="nofollow">http://sports.espn.go.com/oly/trackandfield/news/story?id=2537229&campaign=rss&source=ESPNHeadlines</a></a></p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131085">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131086"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131086">58. </a></span><span style="color:#036">Jose </span> on August  2, 2006  2:57 PM writes...</p>
<p>Hey Novice Chemist- </p>

<p>link about a very sophisticated anabolic steroid that was specifically designed to be invisible to the sreening agencies. Some VERY high level (clandestine) med chem and analytics here. "C" may be more likely-</p>

<p><a href="http://pubs.acs.org/cen/science/8146/8146sci2.html" rel="nofollow">http://pubs.acs.org/cen/science/8146/8146sci2.html</a></p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131086">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131087"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131087">59. </a></span><span style="color:#036">DFW </span> on August  2, 2006  3:13 PM writes...</p>
<p>At the Tour, riders are tested before the race; in addition, at the conclusion of each stage the stage winner, the race leader, and six to eight cyclists selected at random throughout the field are tested. That means Landis should have been tested six other times (before and as race leader after stages 11, 12, 15, 19, 20) in addition to the positive sample after his stage win of stage 17. Presumably, those samples were negative.</p>

<p>I wonder, as did Ian in 27 above, how could all Landis' other tests be negative. </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131087">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131090"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131090">60. </a></span><span style="color:#036">Novice Chemist </span> on August  2, 2006  3:21 PM writes...</p>
<p>Jose:</p>

<p>As I said in my comment, I am aware of the history of THG. It's the hydrogenation of a triple bond. Child's play, as far as I'm concerned. Patrick Arnold was the chemist involved -- it's my understanding that he has no more than a BS. </p>

<p>It is my opinion that 'designed steroids' is mostly a term for the media; 'slightly modified steroids', I think, is a better term. </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131090">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131091"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131091">61. </a></span><span style="color:#036">Maetenloch </span> on August  2, 2006  3:35 PM writes...</p>
<p>Novice chemist,<br />
I suspect that almost all elite athletes use substances like HGH, IGF, etc. that are currently undetectible. However many also use steroids for which no test exists at this time. You don't need a team of Ph.Ds developing compounds from scratch - drug companies spent most of the 60's and 70's developing and cataloging steroids in search of the holy grail, a steroid with all the benefits of testosterone but none of the side effects. Most of these were never developed commercially for one reason or another, but the original research is still available. A quick look at the history of BALCO shows that you really only need a smart chemist or two with access to pharmaceutical databases. Right now there are chemical companines in China that are selling compounds that have never been marketed commercially like 1-testosterone, turinabol, and methyl-trenbolone. It wouldn't be hard to have them manufacture a compound from the literature for which no urine test exists.<br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131091">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131093"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131093">62. </a></span><span style="color:#036">Jose </span> on August  2, 2006  4:06 PM writes...</p>
<p><br />
Novice-</p>

<p>Notice I wrote "high level med chem" and not "synthesis." Most of med chem involves fairly simple chemistry; the difficulties lie in retaining, or improving activity. Picking out gestrinone (buried in thousands upon thousands of other steroids in patents, journals, etc.), obtaining some, and doing the chemistry on it strikes me as a fairly involved operation. </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131093">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131095"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131095">63. </a></span><span style="color:#036">secret milkshake </span> on August  2, 2006  4:28 PM writes...</p>
<p>If you make living by peddling anabolics, the chances are that you have quite a good understanding what is available for abuse and what are the pros/cons, including the detectability. It is only logical that you would then think about new analogs that are not known in the forensic literature. Often you could propose a structure that has a reasonable chance of working just by combining data from some review in literature. You would be limited by feasibility of chemistry - you need some close precursor, like those contraceptive steroids they used - but you could come up with new analogs, whuch would buy you a year or two, before they will be known and tested for. In case of BALCO, I think there was a lucky coincidence that their steroid alcohol was quite hindered and acid-sensitive and would decompose under the standard conditions used for GC derivatization.</p>

<p>So all and all, you need one or two guys to pull this off. And they don't have to be geniuses, just competent and greedy.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131095">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131097"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131097">64. </a></span><span style="color:#036">JB </span> on August  2, 2006  4:37 PM writes...</p>
<p>There's an article about this on news@nature.com titled "Isotopes help pin down artificial testosterone"</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131097">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131099"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131099">65. </a></span><span style="color:#036">loikll </span> on August  2, 2006  5:01 PM writes...</p>
<p>C'mon 'Roid Landis, say it ain't so.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131099">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131101"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131101">66. </a></span><span style="color:#036">JB </span> on August  2, 2006  5:35 PM writes...</p>
<p>Here's the link<br />
<a href="http://www.nature.com/news/2006/060731/full/060731-4.html" rel="nofollow">http://www.nature.com/news/2006/060731/full/060731-4.html</a></p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131101">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131102"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131102">67. </a></span><span style="color:#036">weirdo </span> on August  2, 2006  5:48 PM writes...</p>
<p>The curious thing to me is the fact that the isotope ratio test should apparently show a difference for at least 7-8 days after administration of the exogenous testosterone (Steroids, 1997, 62:379-387).  Since Landis was tested periodically throughout the race, a one-day difference is a highly suspicious and unlikely result.</p>

<p>Any analytical chemists (non-conspiracy theorists only please!) out there care to comment?</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131102">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131106"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131106">68. </a></span><span style="color:#036">slank </span> on August  2, 2006  6:04 PM writes...</p>
<p>It's amazing how many people trust science to give them cars, big screen TV's, and airplanes.  Yet, when this science shows that our athletes are cheating (most professional bicyclists are) or that global warming is occurring then we'd better pout because it's going against something we want to believe.  landis, lance, all of the other top finishers in le tour are doping.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131106">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131109"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131109">69. </a></span><span style="color:#036"><a href="http://www.rknibbe.com/blog" rel="nofollow">RKN</a> </span> on August  2, 2006  6:42 PM writes...</p>
<p><i>Yet, when this science shows that our athletes are cheating (most professional bicyclists are) or that global warming is occurring then we'd better pout because it's going against something we want to believe. landis, lance, all of the other top finishers in le tour are doping.</i><br />
 <br />
 Specifically what "science" has shown that Lance Armstrong has cheated - ever? All the evidence -- and there's a lot of it in his case - points to exactly the opposite.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131109">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131110"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131110">70. </a></span><span style="color:#036">John K </span> on August  2, 2006  8:09 PM writes...</p>
<p>I would like to see the B sample tested by a DIFFERENT lab.  I'm surprised that in high-profile cases like this the authorities don't do that to add legitimacy to the testing process.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131110">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131111"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131111">71. </a></span><span style="color:#036">Another Chemist </span> on August  2, 2006  8:10 PM writes...</p>
<p>Some thoughts;</p>

<p>1) I note in the Clinical Chem paper that Derek cites:  Among the "high T/E testers", i.e. those >6, the T/E ratio for those who 'failed' the isotope test were typically >20 and those that 'passed' were 5-13.  Landis tested at 11.  Of course this doesn't prove that Landis is clean, but his score is more consistent with those who 'passed'.  Also, this does point out that elevated T/E ratios among athletes does occur.</p>

<p>2) The only news item I could find, re: testing of sample A with the isotope test, was a suggestion by an anonymous official to the New York Times that Landis failed the isotope test. Anonymous objective source for the Times?  Hmmmmm.</p>

<p>3) The worst case senario for Landis, if he is innocent, is that the results of the isotope test might not be clear cut.  One could imagine a 5BP-5BA of 3.0, in between those who passed and failed, with the rest of the parameters being likewise ambiguous.  How would one interperate such a result?  I can guess that the Landis fans will have a different view from the anti-American crowd.  Unfortunately, such indeterminent results are not so uncommon in my experience.  </p>

<p>My conclusion to this is that the most rational position is "We don't know....yet."  There is plenty of room to doubt the significance of T/E ratio and suggestions from anonymous sources to the Times haven't held too much weight lately.  Hopefully, the actual numbers will be released this weekend and the results will be clear cut.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131111">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131115"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131115">72. </a></span><span style="color:#036">Jim S </span> on August  2, 2006  8:44 PM writes...</p>
<p>Why would he take something that he knew would show up in a test?  Because he didn't think he'd be tested.  </p>

<p>If my memory is correct, it's the guy wearing the yellow jersey and the stage winner who are always tested.  The guy was in 11th place and riding on dead legs after the prior stage.  No one, including Landis, thought he would make a "miraculous" recovery.  </p>

<p>If Landis took the drugs - and that is not a big "if" - he was probably trying to regain some time in hopes of making the podium.  Instead, he kicked everyone's tail by an unbelievable margin.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131115">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131116"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131116">73. </a></span><span style="color:#036">Phunny Pharm </span> on August  2, 2006  9:08 PM writes...</p>
<p>Landis is straight, the French chemist are cheating jackasses. They always will be as long as Americans are making them look bad in the mother land. Oh, and all of you Floyd bashers, check his record for the year. Four major wins aint bad for an old man with a bad hip. Maybe, just maybe he trained real real hard and earned his way to the top step. Perhaps you could appreciate it better if you would spend a little more time on your bike (if you had one) doing some hard road miles up the side of some mountain. Go out and teach yourself something about motivation, realizing impossible goals, all or nothingness and hell, even carrying the weight of an entire countries hopes of just one more yellow jersey on your shoulders. That may, however afford you a little less time on your fat asses in front of the computer figuring out ways to bash a fellow American on a subject about which you are mostly ignorant. You smart sounding chemists, nice explanations. Now get a life and go ride.<br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131116">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131117"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131117">74. </a></span><span style="color:#036"><a href="http://smelloffreedom.blogspot.com" rel="nofollow">Nicholas</a> </span> on August  2, 2006  9:09 PM writes...</p>
<p>"...when science shows global warming is occurring..."</p>

<p>www.climateaudit.org</p>

<p>If you read a definition of "science" it requires independent verification. Climate "scientists" mostly refuse to give out data and methods, making such verification impossible. Therefore it is not science by definition. That web site documents the pain one guy has to go through in order to attempt to independently verify the results.</p>

<p>What does this have to do with drug tests for cyclists? Not much, other than to point out that science isn't always infallible. I wouldn't have brought it up if slank didn't try to use this throw-away slur...<br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131117">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131119"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131119">75. </a></span><span style="color:#036">Joe Blow </span> on August  2, 2006  9:13 PM writes...</p>
<p>Landis has said my high testosterone level is due to:</p>

<p>*Cortizone, which I take legally for my bum hip.<br />
*Medication, which I take for a thyroid condition.<br />
*Alcohol<br />
*a naturally high reading, which I've had for years.</p>

<p>Go ahead and blame the French or whomever you want.  But if you're nine-year-old were talking the way Landis is, you'd say, "Floyd, you're fibbing."</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131119">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131125"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131125">76. </a></span><span style="color:#036">Dave </span> on August  2, 2006  9:19 PM writes...</p>
<p>The fact that all of Floyd's other samples taken before, during, and after the race were negative implies that, if he did cheat, he must have cheated only between stages 16 and 17.  I agree with the majority of posters here: elite athletes are exquisitely well aware of what they can and cannot get away with in using PEDs.  An efficacious dose would have produced a test result far more abnormal than what was reported for the A sample.</p>

<p>This story absolutely does not add up.</p>

<p>The lab running these tests should have already been disbarred based on its shady history.<br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131125">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131129"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131129">77. </a></span><span style="color:#036">there is no santa claus </span> on August  2, 2006 10:06 PM writes...</p>
<p>Why does everyone assume that the one positive test after stage 17 means Landis could only have been cheating on that one stage - which, the reasoning goes, would make no sense, ergo he was framed/the test was screwed up/the French are against him?</p>

<p>As was mentioned waaaay upthread, there is good reason to believe that false negatives are far more common than false positives.</p>

<p>So maybe on that day he just screwed his dosage up.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131129">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131137"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131137">78. </a></span><span style="color:#036">Plunger </span> on August  2, 2006 11:20 PM writes...</p>
<p>Get over it! Your conspiracy theories are embarrassing and pathetic.  Landis will most likely be proved guilty and should be banned for life.  He is a cheat and should be humiliated! And no, THIS IS NOT SOME ANTI-AMERICAN CONSPIRACY - YOU ARE NOT BEING PERSECUTED.</p>

<p>PS  HMMM - I like your blood doping rumor - sounds plausible to me.  </p>

<p>PPS I am a biochemist, avid cyclist and cycling fan - so Phunny Pharm you can keep your rabid, nationalistic panties on.<br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131137">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131138"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131138">79. </a></span><span style="color:#036"><a href="http://parentheticalremarks.blogspot.com" rel="nofollow">Pete Blackwell</a> </span> on August  2, 2006 11:31 PM writes...</p>
<p>If Landis is disqualified, I believe a Spaniard wins. Hardly the stuff of a French conspiracy.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131138">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131155"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131155">80. </a></span><span style="color:#036">Rascal </span> on August  3, 2006  4:34 AM writes...</p>
<p>I think the french slipped him a mickey. </p>

<p>Regardez-vous! <br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131155">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131163"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131163">81. </a></span><span style="color:#036">Drugs are good </span> on August  3, 2006  7:40 AM writes...</p>
<p>All of the elite cyclists are using something to enhance performance; that includes Armstrong, who will never say "I have NEVER used these substances".  It doesn't matter, they still have to train and ride like hell.  I say we eliminate drug testing and see if the performance really improves...</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131163">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131167"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131167">82. </a></span><span style="color:#036">pdino </span> on August  3, 2006  8:33 AM writes...</p>
<p>I sure hope that either the IRMS results of the Landis B sample or subsequent analysis/testing prove and explain that he was "clean" and his performances during the TDF were unaided by banned drugs.</p>

<p>I do, however, want to comment on the motive for professional cyclists using testosterone (synthetic or real) supplementation to help performance.  If you talk to any cyclist about what it takes to win a 3 week long stage race, one of the key qualities is RECOVERY.  Successful stage racers can RECOVER between stages and have sufficient strength for the next day's stage.  </p>

<p>Testosterone is a proven muscle recovery booster.  Seems like it would be a good "performance enhancer" for a stage racer, especially during the last week of a stage race when all the racers are fatigued!?  Former pro rider Jesus Manzano has stated that Testosterone IS in fact a beneficial drug to take during stage races in that is aids recovery and improves aggressiveness/morale.</p>

<p>Like I said, I'm not jumping to any conclusions yet and I sincerely HOPE that Floyd Landis' performance during the 2006 TDF were 100% a result of hard training and natural abilities.  Let's not be naive, however, and deny that testosterone is a proven performance enhancer.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131167">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131180"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131180">83. </a></span><span style="color:#036">DFW </span> on August  3, 2006 12:28 PM writes...</p>
<p>In 77 there is no santa claus wrote: "As was mentioned waaaay upthread, there is good reason to believe that false negatives are far more common than false positives." However, the first upthread mention I can see of false negatives is in 46 where anonymous wrote: "False negatives are a much bigger problem."</p>

<p>Nowhere in this discussion can I find any citations quantifying false negatives. Where is the source that "false negatives are far more common than false positives?"</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131180">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131197"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131197">84. </a></span><span style="color:#036"><a href="http://undereating.blogspot.com" rel="nofollow">Stephen</a> </span> on August  3, 2006  5:50 PM writes...</p>
<p>Landis did a one-time "cheat", and used a testosterone patch following his disasterous stage 16, in order to recover for his miraculous stage 17.  He probably administered the patch himself, and took a chance that he'd be under the 4:1 limit when tested the following day.  It was a calculated risk.  He needed a miracle, and went for it.  There was some thought that a one-time application wouldn't be detectable: <a href="http://www.cyclingnews.com/news.php?id=news/2006/jul06/jul07news3" rel="nofollow">http://www.cyclingnews.com/news.php?id=news/2006/jul06/jul07news3</a><br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131197">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131221"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131221">85. </a></span><span style="color:#036">Mim </span> on August  4, 2006 12:36 AM writes...</p>
<p>Here's another article explaining the isotope test and its basis in some detail for those who want more info.</p>

<p><a href="http://www.raci.org.au/chemaust/docs/pdf/2006/CiAMarch2006p3.pdf" rel="nofollow"><a href="http://www.raci.org.au/chemaust/docs/pdf/2006/CiAMarch2006p3.pdf" rel="nofollow">http://www.raci.org.au/chemaust/docs/pdf/2006/CiAMarch2006p3.pdf</a></a></p>

<p>Seems like it's fairly robust by all accounts.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131221">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131247"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131247">86. </a></span><span style="color:#036">Anonymous </span> on August  4, 2006  9:48 AM writes...</p>
<p>Re comment #14:  I'm SURE it will interest you to know you are now the number one result on Google if one searches "deuterated dog".  LOL</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131247">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131262"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131262">87. </a></span><span style="color:#036">Anonymous </span> on August  4, 2006  2:53 PM writes...</p>
<p>DFW,</p>

<p>I don't have any scientific evidence that false negatives are more common than false negatives. My assertion is based on the fact many users of PEDs make it through testing regimes without being caught.  </p>

<p>Had Basso and Ullrich just started using PEDs this year? How many times were Justin Gatlin, Marion Jones and others tested with nothing showing up. I repeat my comment from above about the NFL -- is the usage rate really about 1%? Obviously tests have limitations -- and it makes sense from a fairness/civil liberties perspective to err on the side of false negatives.  As I said above, the cheaters are always ahead of the testers. No doubt there are more THG's out there today.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131262">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131272"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131272">88. </a></span><span style="color:#036"><a href="http://redsoxfann.blogspot.com/atom.xml" rel="nofollow">BCL</a> </span> on August  4, 2006  7:25 PM writes...</p>
<p>There are no false negatives, let's all be clear on this fact. See comment number 84 for all your answers, Landis cheated, he got caught, he wasn't expecting that an isotope would be his one achiles heal and he faltered at cheating. The french were waiting to pounce on this and had the test and the clear situation of a miracle time or comeback during a stage already figured out for their isotope reasoning to be an acceptable reason for his guilt.<br />
Plain and simple, he got out thought and he relied upon a mythe that the ratio would be low enough by the next day not to test positive, he calculated wrong and got caught.the c-13 isotope was his un-doing and unless he had been eating c-13 isotopes for breakfast then he took the synthetic form of BALL JUICE. plain and simple. he cheated.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131272">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131308"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131308">89. </a></span><span style="color:#036">Mark Heinicke </span> on August  5, 2006  7:04 AM writes...</p>
<p>It seems to me that the desire of the French to retain the prestige of the Tour de France would outweigh any temptation to manipulate test results.  Ergo, I believe the testing and results were fair, and devastatingly  credible.  </p>

<p>And speaking of the Tour's prestige, I don't quite understand why more of the French conspiracy theorists don't bother to express some gratitude to the French for putting on the greatest race in the world--a race which has made international heroes out of Greg Lemond and Lance Armstrong.</p>

<p>BTW, I wonder what the testing regime is for World Cup soccer?  Artifically elevated testosterone might go some way to explain Zinedine Zidane's belligerence in the WC Final head-butting incident which may well have lost France the Cup. </p>

<p> </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131308">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131329"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131329">90. </a></span><span style="color:#036">jim </span> on August  5, 2006  2:46 PM writes...</p>
<p>Anyone who is familiar with testosterone knows this steroid doesn't have a physiologic effect overnight...takes weeks to build up red blood cell count and muscle mass.  It is not a stimulant, doesn't cause "bursts of superhuman strength", and wouldn't have affected the outcome of this race.  Someone has "slipped him a mickie" or the French lab has screwed up.  Problem is most physicians and scientists have no experience with this drug "in vivo", and honestly don't know what they are talking about!!!!!  Looks like you're framed Floyd....good luck.  Jim Princeton M.D.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131329">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131342"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131342">91. </a></span><span style="color:#036">Dean </span> on August  5, 2006  6:23 PM writes...</p>
<p>My questions are:</p>

<p>Could DNA samples be conducted upon the urine which is said to be the sample given by Landis to determine if it is in fact Landis' urine, and not urine belonging to a horse, another person, etc.?</p>

<p>If Landis is innocent of the charges of doping, which we MUST presume he is, is it possible that his urine samples could have been switched or tampered with?  How is the chain of custody ensured?<br />
 <br />
Is it possible that testosterone was administered covertly to Landis by a jealous competitor (ie: mixed in with food eaten or beverages drank by Landis without his knowledge)??  </p>

<p>How long would a single dose of testosterone (since we must assume a single dose, based on the fact that other samples given by Landis during the course of the Tour did not test positive for high ratios of testosterone to epitestosterone) remain present in the body and more specifically in one's urine?  </p>

<p>Would a test, taken the day the allegations surfaced, be helpful in proving the results reported by the UCI were false or induced by tampering??  </p>

<p>My comments:<br />
I must believe that Landis is innocent until he is PROVEN guilty.  If Landis should be found guilty after exercising due process, including appeals, then it will definitely be disappointing to many of his fans and to the cycling world.  However, I believe there will be a discovery of "foul play" involving either the test results or the authenticity of the sample which was labeled as Landis'.</p>

<p>    </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131342">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131353"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131353">92. </a></span><span style="color:#036">Phunny Pharm </span> on August  5, 2006  8:39 PM writes...</p>
<p>Sorry to have embarrassed you Plunger (#78). I'm not a conspiracy theorist, just an optimist trying to support a fellow cyclist in the best way that I can while he is technically still innocent. As I am also American, Landis just happened to be first in line. The French/American love affair has been a little shakey over the past few years in case you hav'nt noticed so I was poking a little lite hearted fun at Francois' expence. I also feel that the Germans, Italians and others were handed an even bigger bone job by the Spanish. Anyway, I and my fellow cyclist, regardless of nationality sincerly appreciate your support. There Plunger, how are my panties now?</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131353">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131357"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131357">93. </a></span><span style="color:#036">jon redmond </span> on August  5, 2006  8:49 PM writes...</p>
<p>Why would someone slip a micky to a rider that was 8 minutes behind the yellow jersey?</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131357">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131362"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131362">94. </a></span><span style="color:#036">Tired of hearing it </span> on August  5, 2006 11:00 PM writes...</p>
<p>S@rew you Realist with your Anti-American comment.  If Landis did do wrong he should be punished. If on the other hand it is found that he did nothing wrong, you might want to rethink your attitude....</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131362">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131372"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131372">95. </a></span><span style="color:#036">Smoking Man </span> on August  6, 2006  2:32 AM writes...</p>
<p>Actually, the entire race was faked in a<br />
sound stage in the Arizona desert.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131372">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131373"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131373">96. </a></span><span style="color:#036">Craig </span> on August  6, 2006  3:13 AM writes...</p>
<p>Finally, an article that intelligently discusses the science behind the testing!  Thanks.</p>

<p>I look forward to a follow-up report that includes more answers to the various thoughts expressed by the commenters.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131373">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131399"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131399">97. </a></span><span style="color:#036">kvon </span> on August  6, 2006 12:11 PM writes...</p>
<p>I'm very pleased to have stumbled on this site....it answered alot of questions. I really am a novice chemist, currently finishing my BS. Novice chemist above doesn't sound very novice to me. I would be very interested in seeing the actual chemical compounds of both synthetic and biological T. I have looked through my P-chem and O-chem texts and can't find the synthetic steroid. Does anyone know of a site that would have projections of the compounds to compare?</p>

<p>I'm also a cyclist, good banter Phunny. <br />
JUST RIDE!</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131399">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131452"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131452">98. </a></span><span style="color:#036">Shelley </span> on August  6, 2006  2:55 PM writes...</p>
<p>Could synthetic testosterone have been added to Landis' urine sample?</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131452">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131579"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131579">99. </a></span><span style="color:#036">Realist </span> on August  7, 2006  2:53 AM writes...</p>
<p>Guilty!</p>

<p>I rest my case.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131579">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131603"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131603">100. </a></span><span style="color:#036">David McCune </span> on August  7, 2006 10:38 AM writes...</p>
<p>I'm still intrigued by the possibility that the synthetic cortisone was converted by his body into a "natural" testosterone that would test artificial by the isotope test.  The liver does recycle the steroid hormones, so it is possible.  In theory, an isotope test on earlier samples would also be positive.  While this would not eliminate the possibility that Landis was cheating all along, it would refute the idea that he took a one-time injection before stage 17.  Conversely, if only the stage 17 test showed altered isotopes, that would eliminate a pure natural variant, and leave only cheating and tampering as explanations.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131603">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131609"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131609">101. </a></span><span style="color:#036">brenda </span> on August  7, 2006 11:13 AM writes...</p>
<p>So the french are out to get the Americans. I'm so grateful Lance Armstrong led us all to this truth.  Forget all of the millions of dollars, fame, status that goes along with winning the  Tour De France.  Floyd Landis tested positive; perhaps he got desperate at the last minute, who knows.  I'm sick of hearing all of these people defending him just because, "he's my hero and he would never lie"  Why wouldn't he lie?  just because he's your big, bad cycling hero?  News Flash-people lie!! especially to cover their trail.  I'm sure we could fill volumes with the names of honest looking people that told lies.  Lets all stick to the facts and quit with the "hero worship".</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131609">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131613"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131613">102. </a></span><span style="color:#036">David Reed </span> on August  7, 2006 11:42 AM writes...</p>
<p>According to Brooks JR etal 2002 "the delta13C of European beers indicated mostly C3 plant carbon". How rapidly is testosterone metabolized? How variable is its isotopic ratio content in relation to diet over time? Does human metabolism discriminate carbon for testosterone production (like photosynthesis metabolisms) in preference to a common ratio? If the incorporation of carbon into testosterone is slow versus rapid, then the day of the synthetic testosterone addition would be bounded by those samples when the C3 signature appeared.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131613">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131615"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131615">103. </a></span><span style="color:#036"><a href="http://the-buzz-spot.blogspot.com/" rel="nofollow">The Analyzer</a> </span> on August  7, 2006 11:56 AM writes...</p>
<p>Maybe it's not really Landis's fault.  This article offers a different viewpoint.</p>

<p><a href="http://the-buzz-spot.blogspot.com/2006/08/floyd-landis-conspiracy.html" rel="nofollow">The Floyd Landis Conspiracy</a></p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131615">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131617"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131617">104. </a></span><span style="color:#036">Bob Eastley </span> on August  7, 2006 12:33 PM writes...</p>
<p>I just listened to two interviews related to the Landis case. First, results of the "A" test were not supposed to be made public until he had a chance to react to them. When asked why they were relased, the gentleman who got the lab results and released the information to the media gave some lame excuse about how he wanted to get it out there before someone leaked it. So it's OK if HE leaked it? When questioned again, he ducked the issue. Next, a doctor was questioned about the fact that the RATIO was high, but the testosterone level was not.  The interviewer specifically asked if an athlete would gain any benefit by having a high ratio if the testosterone level was not high.  Again the interviewee ducked the question.  Floyd Landis may be guilty, but people VERY close to the issue are not following due process. If they aren't honest enough to give him a fair chance to defend himself, why should we believe their lab results?</p>

<p>RCE</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131617">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131635"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131635">105. </a></span><span style="color:#036">Brad Sherman </span> on August  7, 2006  4:38 PM writes...</p>
<p>In response to David Reed's (102) question, the RACI paper (see Mim #85) suggests diet is unlikely to be responsible. The study presented there showed diet-related changes of deltaC13 in the testosterone metabolites that are tested ranged from around -23.6 for the highest C3 diet (Italy) to -19.5 for the highest C4 diet (Mexico). Short term impact of taking the synthetic hormone Adione (deltaC13 = -35) was to reduce deltaC13 inthe metabolites to -28 or below for 3 to 4 days.  </p>

<p>I'd be interested to learn how testosterone is metabolised when under great stress as Landis was the day before when he cracked going up the last climb. Is it possible to deplete C13 more rapidly than C12 even though C13 is heavier and less reactive?</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131635">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131643"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131643">106. </a></span><span style="color:#036">Phunny Pharm </span> on August  7, 2006  7:21 PM writes...</p>
<p>Yippee for Realist (#99)! You've single handedly made the world of cycling a better sport because YOU called it. You've won YOUR case. Now you can go to France or Spain or wherever and pick up your prize. By the way, what did you win? What was it that excited you so much about the worlds greatest stage race  being tainted by the current evidence, hhmmm? Oh, it does'nt matter, as long as YOU won! I'd say however that the rest of the cycling world lost...bigtime. Perhaps you can sleep better now. </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131643">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131653"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131653">107. </a></span><span style="color:#036">jdb13 </span> on August  7, 2006 10:16 PM writes...</p>
<p>I too, wonder about how Cortisone is metabolized.  Here is a PDF article I found.  Can one of you chemists tell me if it relates to this discussion?</p>

<p><a href="http://doi.wiley.com/10.1002/bms.1200170502" rel="nofollow">http://doi.wiley.com/10.1002/bms.1200170502</a></p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131653">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131693"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131693">108. </a></span><span style="color:#036">Strixwood </span> on August  8, 2006  9:51 AM writes...</p>
<p>As a (retired) chemist with eons of experience in clinical analyses, I'm curious as to the actual numbers involved in these tests -- especially the expected accuracy and precision.  It seems to me that the situation requires some rather complex number crunching to get at the naturally produced vs. "synthetic" content in the samples, and I would love to play around with it as an intellectual exercise strictly for my own amusement/amazement.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131693">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131716"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131716">109. </a></span><span style="color:#036">frank gattoni </span> on August  8, 2006  3:20 PM writes...</p>
<p>the way to resolve the issue as to whether floyd landis has taken testosterone or whether the results reflect an inherent metabolic anomaly that he has is to repeat that race section (or simuluate it) taking appropiate precautions to prevent illicit administration of testosterone and to then repeat the analysis.they may also wish to use some of the epitheal cells in the urine specemin to confirm that they match his dna</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131716">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131744"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131744">110. </a></span><span style="color:#036">J </span> on August  8, 2006  5:33 PM writes...</p>
<p>I believe the heads of the doping committees for the Olympics has publicly stated that a professional athlete familiar with performance enhancing drugs knows that taking drugs the night before a race would not provide any benefit.  So why do you have a rider who has been tested 4 other times so far in the race, sets out to win the Stage(all stage winners are tested) knowing he will be tested if he wins and then proceeds to pass three more drug test for the remainder of the race.  </p>

<p>How do you pass 7 and fail 1 in the middle of a few weeks.  Don't forget this is the same rider that has won many other races and passed many drug tests.  I am skeptical of all pro riders but it seems fishy in the sense that he would slip up during the biggest race of his life.  </p>

<p>This French Lab is notorious for breaking rules and not following protocol, why is it so odd that a technician would taint the sample.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131744">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="131863"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131863">111. </a></span><span style="color:#036">rt </span> on August  8, 2006  9:18 PM writes...</p>
<p>One thing no one has addressed is isotope levels in the subsequant samples.  Testosterone has a half-life of several days.  The synthetic T should also have shown up in those later sdamples.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131863">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="131960"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131960">112. </a></span><span style="color:#036">bob </span> on August  9, 2006  3:17 AM writes...</p>
<p>The paper cited in #84 is indeed interesting, and it suggests two simple ways in which WADA could reinforce the persuasiveness of its argument.  <br />
(1)  It shows that for a reasonable-sized sample, people eating US or Mediterranean diets produce T with a isotope ratio of around -23 average, with a standard deviation of around 1.2 or so.  Thus, the 3-sigma limit of the sample is around -26.6, and the "cutoff value" recommended in the paper is -27.  It also shows that for the precursor they tested, the actual ratios were below -28, and stayed there for 100 hours or so. So, what were the measured values in Landis's samples?  Maybe this has been released, but I haven't seen it.  If they were -31, probably case closed.  If they were -27.1, maybe a little more review is needed.</p>

<p>(2) The same paper and others indicate that the reduced carbon ratio remains detectable for 100 hours or more.  Wasn't Landis tested again a couple more times after Stage 17?  For that matter, what did his results look like from his earlier tests?</p>

<p>My point is that while the mass spec work has been well documented with respect to repeatability and accuracy, the LIMITS appear to have been set pretty tight: about 1 or 2 non-dopers out of 1000 could be expected to marginally fail the -27% ratio cutoff; and as many as 10 or 15 out of 1000 might naturally fail the 4:1 screening for T/E.</p>

<p>Because of this, the convincing way to present the evidence is to show that (1) Landis exceeded the normal range on the tests by a large margin; and (2) that it was an aberration -- he was normal before and normal after (and maybe even normal now), but abnormal during Stage 17; and maybe (3) that at the immediately next following test he was still a little abnormal.</p>

<p>It wouldn't be that hard to show the data, instead of just having Dick Pound say "The science is good".</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#131960">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="132044"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#132044">113. </a></span><span style="color:#036">brad sherman </span> on August  9, 2006 11:17 AM writes...</p>
<p>Following on from Bob's comments, the -27 ppt (not %) ratio suggested as the target in the RACI paper (#85) is 3 standard deviations from the mean, i.e. for Landis to get below this, i.e. -30 or so, there's a 3 in 1000 chance of it's being natural variability based on the samples of the 1120 atheletes sampled to determine the 'accepted' range of natural variability. Although the plot in the paper shows about a 100 h effect I believe the authors claim that one can only reliably expect the effect to last for 40 hours. That said, I believe Landis would have samples taken every day that he wore the yellow jersey.</p>

<p>Bearing in mind the absence of actual published test results to fuel any of this speculation, I expect it will be some weeks as the other samples are analysed. I assume he must have been sampled after the last two stages as wearer of the maillot jaune, but not necessarily after stage 18. Does anyone know who is required to provide samples at the end of each stage apart from the stage winner? Landis didn't win any stages after #17. If he wasn't sampled in 19 and 20 it would be hard to prove innocence as I would guess he'd need a clear test for samples taken within 24 - and maybe 48 -  hours of the stage 17 sample. </p>

<p>Seems a shame that in the world of sport, one is no longer presumed innocent until proven guilty after due process.  For some perverse reason I don't understand, society prefers to assume top athletes are all cheaters rather than gifted humans. My personal assumption is the converse - call me naive. I reckon none of this should have been made public until all tests and appeals had been completed. It's not fair on the athlete.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#132044">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="132050"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#132050">114. </a></span><span style="color:#036">jdb13 </span> on August  9, 2006 12:57 PM writes...</p>
<p>Tested each day are the stage winner, the current yellow jersey holder and several other iders at random.  So, Landis would have been tested after Stage 19 and 20.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#132050">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="132077"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#132077">115. </a></span><span style="color:#036">anonymous </span> on August  9, 2006  2:36 PM writes...</p>
<p>If cyclists are held to a 2 year ban for infractions of the code, why isn't the testing lab held to a similar high standard?  They made a mess of the Olympic tests, and are clearly not impartial.  Why aren't there multiple labs and random selection of which samples go to which labs.   Why is it a French-Canadian in charge of WADA and a French lab calling all the shots.</p>

<p>Mr Pound has a long history of being judge and jury without a shred of scientific data, while trying to represent an organization that is suppose to uphold science and morals at the highest standard.  These atrocities including unfounded comments about NHL athletes, Armstrong, etc which have all gone unproven and false.  </p>

<p>In early June of 2006 Armstrong wrote a letter to the IOC asking that Mr Pound, be removed for his behavior.  Now we get to the end of July and you have to ask the question if there is a hidden agenda for Mr Pound to strike back at America.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#132077">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="132094"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#132094">116. </a></span><span style="color:#036">Mr. Smith </span> on August  9, 2006  6:09 PM writes...</p>
<p>the one thing I don't get is, Testosterone is a steroide that would build mass over time. I dont see the advantige of taking it DURING a race. Also Why did he not just mask it with epi. I dont know why but i smell a coverup. I have no evidence for it but after the way they tried to get armstrong... I wonder... or could they have screwed up the test and to save face used sample A again inplace of B... or worse yet added testosterone to the sample to make the "american look bad."  </p>

<p><br />
I want to see the method of testing, What type of machine, (LCMS, GCMS, UV?) What model, what year, when the machine was last calibrated. The reagents used during the test, The lot numbers of the reagents, Experiation dates, I would also like the samples tested by independent labs. Also did they use a strandard? What standard. From an analytical chemist point of view i have a bunch of questions. Speaking of chemist was this guy a pro or was he a rookie fresh.     </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#132094">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="132111"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#132111">117. </a></span><span style="color:#036">EHF </span> on August  9, 2006  9:51 PM writes...</p>
<p>How long does synthetic testosterone stay in the system?  Landis was tested 3 or 4 times after the 17th stage, all were negative.  How could his testosterone ratio be 2-1/2 times the permisable ratio after the 17th stage, but ok a day or two later?  </p>

<p>By all accounts, synthetic testosterone takes weeks not hours to provide any performance enhancement.  Why would Landis take a banded subtance following the 16th stage that would provide no benifit for weeks?     </p>

<p>It just doesn't make sense, he takes one hit of testosterone during the tour with no positives before or after?  </p>

<p>Some have suggested that Landis must have been slipped a mickey.  But after the 16th stage, he was not considered a threat to win the tour by anyone.  Why would conspiring powers slip him a banded substance when he was no longer a threat to win the tour?  </p>

<p>The positive sample was taken after the 17th stage, but testing was not performed and results  released until after what some have called the  greatest comeback in tour history.  So we have the wrong drug to bolster near-term performance  sandwiched between numerous clean tests before and after the 17th stage.    </p>

<p>In my opinion, everything points to a tampered urine sample.  At some point after the 17th stage comeback, but before the labratory testing, synthetic testosterone was added to his urine sample.  I would take a long, hard look at chain-of-custody proceedures for that sample, who handled it, or had access to it prior to testing?   </p>

<p> </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#132111">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="132117"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#132117">118. </a></span><span style="color:#036">proofread </span> on August  9, 2006 11:06 PM writes...</p>
<p>Landis' urine, not blood, was tested. Proof read.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#132117">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="132127"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#132127">119. </a></span><span style="color:#036">Isotope Man </span> on August 10, 2006  2:29 AM writes...</p>
<p>To me this dopping alligation is not clear.  While plants fractionate isotopes, animals in general do not.  For animals, you are what you eat, isotopically speaking.  Therefore, I see at least two possible paths for this alleged synthetic testosterone.  One, that is was injected (it is unlikely that testosterone taken orally would actually be used in the body without modification).  The other possible reason would be that he had two very different diets (isotopically speaking) so that he had two different compositions of testosterone in his body at the same time.  This would seem like it might have alot of merit because you would assume that the diet in training differes drastically with the race diet.  The things that stick out are the training drinks and gu. What is gu isotopically?  It most likely comes from some sort of natual sugar (perhaps corn, a C4 plant).  The best question to ask is what is the variation of the isotopic composition of testosterone in cyclist, my bet is that there is not study to back up this method of testing!</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#132127">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="132133"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#132133">120. </a></span><span style="color:#036">weekend warrior </span> on August 10, 2006  3:52 AM writes...</p>
<p><i>If the news reports are right, that's what Landis's blood samples have shown. And if they have, there seems only one unfortunate conclusion to be drawn.</i></p>

<p>a) You don't even know what substance was tested.<br />
b) You have a very limited imagination if you think there's one possible conclusion.  I sure hope none of  your work is in a critical area.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#132133">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="132308"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#132308">121. </a></span><span style="color:#036">TEC </span> on August 10, 2006 10:11 PM writes...</p>
<p>I do not know exactly which isotope test they used on the urine. I worked at the UCLA Olympic doping lab and published two peer reviewed papers with validated methods. These have been adopted by the sports authorities. At UCLA we ran lots of controls each time we ran samples. T/E ratio is one thing our Clin Chem paper was cited in the cyclingnews.com web site. here it was used to indicate the T/E was high but isotopic data was clean. However with Landis the lab went onto use the isotope method and that was positive too. Contamination/tampering could be an issue, BUT these labs have such strict chain of custodies and samples are not identified with any name that this would be difficult to do. The isotope test involves extraction of steroids from urine, chemical treatment to make them stable in the gas chromatograph, this "peak" which is separated from other steroids it is then combusted (on-line to carbon dioxide) and goes into an IRMS (isotope ratio mass spectrometer). It analyses masses 44, 45 and 46. Then the ratio 13C/12C is calculated. The instrument is calibrated against an international standard. At UCLA we also ran a number of control positive and negative urines with know 13C-levels, everytime we tested real samples.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#132308">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="132455"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#132455">122. </a></span><span style="color:#036">CanYouSayWitchHunt </span> on August 11, 2006 12:17 PM writes...</p>
<p>I am glad to see that many of these posts are considering the possibility that Landis' urine sample was tampered with. Of all the possiblities this is the one that seems most likely to me.</p>

<p>Assuming that the French lab did the carbon isotope ratio test correctly, i.e. there actually was synthetic testosterone in Landis' urine, then we can discard all the arguments about drinking alcohol, "naturally high levels of T", etc.</p>

<p>(BTW, those who think that Landis "acts guilty" because of his multiple attempts at explaining the test results have not thought carefully about how an innocent man, especially one raised in a rural, religious society, would actually react if he were wrongly accused. Floyd is not "simple" or "stupid" in any way, but he may be a bit naive regarding the capacity for deceit and dishonesty present in much of humanity...)</p>

<p>This leaves few possibilities: 1) Landis took a one-time dose of testosterone, 2) someone "dosed" him unknowingly with same, 3) the lab "inadvertantly" screwed up, somehow "contaminating" both the A and B sample, or 4) same as (3) except "purposely" and "tampered with" replacing the corresponding phrases.</p>

<p>We can discount (1) because Landis and the Phonak team doctors & trainers are not stupid. Testosterone does nothing helpful for an athlete overnight, and they KNEW he would be tested if he won the stage and/or the yellow jersey. (2) seems vanishlingly unlikely since everything Landis consumes during a race is carefully controlled by the team - this scenario would require a "traitor" on Phonak. (3) is conceivable but just barely; how on earth would an "accredited" drug-testing lab make a mistake of such a gross nature, and ONLY on  THE SINGLE MOST IMPORTANT TEST THEY WILL MAKE ALL YEAR?</p>

<p>No my friends, (4) is the answer. Why use testosterone and not some other more plausible banned substance? (Testosterone is not "plausible" because everyone knows there is no benefit to using just once, overnight.) Here I am out of my league (I'm a physicist, not a chemist) but I know that many drug tests look not for the banned substance itself, but for the metabolic byproducts thereof. However all I have read about the test for testosterone seems to indicate that the testosterone molecule itself passes unaltered into the urine - can any of you chemists/biochemists/endochrinologists out there confirm or deny this supposition? It seems to me that it would be very difficult to "spike" a urine sample with just the right amounts of say amphetamine metabolic products, but very easy to do so with synthetic testosterone.</p>

<p>It smacks very much of a not-well-thought-out-but-who-cares last minute attempt to discredit one of the greatest athletic performances in history. When it became apparent that Landis would win stage 17 and place himself clearly back in contention, it is not hard to imagine someone who could not abide Yet Another American winning the Tour de France for an 8th consecutive year. It would be sufficient to plant any convenient banned substance in Landis' urine sample - vastly easier than figuring out how to actually get it into his body. Whether or not the substance chosen "made sense" is immaterial. Since the "war on doping" is nothing more than bureacratic histrionics and posing, an athlete is presumed guilty until proven innocent. The anti-doping rules do not require "motive" for a conviction. In fact, conviction is automatic; it is exoneration that takes work.</p>

<p>Landis' only possible defense at this point rests on the dynamics of how testosterone is eliminated from the body. Again, I am out of my league here but I think it might be possible to show that it is IMPOSSIBLE for a human to have ingested as much testosterone as Landis would have to have taken and then 48 hours later have no trace of it left in his system. I hope his lawyers are bright enough to think of this (their "dehydration theory" does not speak well for their knowledge in this realm) and that they can obtain expert testimony from the right sorts of medical authorities. What would really help would be to test the samples he gave 48 hours later, after the time trial, and establish an upper limit on the amount of synthetic testosterone in those samples; if this limit is lower than the calculated amount that would be left in his system had he actually ingested synthetic-T, it would argue powerfully that he never had same in his body, that it was added to the Stage 17 sample after the fact.</p>

<p>Floyd Landis is innocent, and stripping him of his rightfully-won Tour title would be a travesty unmatched in the world of sport.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#132455">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="132592"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#132592">123. </a></span><span style="color:#036">Jim Thorpe </span> on August 12, 2006  3:40 AM writes...</p>
<p>"Floyd Landis is innocent, and stripping him of his rightfully-won Tour title would be a travesty unmatched in the world of sport."</p>

<p>Though I agree with most of what you say -- loose the hyperbole. Let's not forget Jim Thorpe! Hopefully Landis won't have to wait until after his death to be recognised.</p>

<p>Though I'm not convinced 100% that Landis was clean of T on that day, I find it extremely hard to rationalise any justification for him to have used it if what everyone says about its effects is true. Had he tested for EPO, I wouldn't be giving him benefit of the doubt.</p>

<p>It's a shame that the sport makes the athletes play such a ridiculous game w/ performance-enhancing drugs. They don't test athletes randomly throughout the year so they are, more-or-less, requiring athletes (even those athletes who want to be clean) to use in order to be competitive. Then all the athletes have to go through pre-race detox regimes so they can piss clean. They should either legalise non-harmful drugs (EPO etc.) and set physiological guidelines (EPO levels, blood pressure etc.) to insure athlete health and safety, OR they should go full-scale with cleaning the sport, but either way stop this posturing and pretending they care about the athletes using drugs.</p>

<p>Though I suspect he was clean on the ride, I can come up with one theory that might explain a reason for his guilt: Could it be that the riders take T for weeks leading up to and throughout the race and that they supplement the T with epi-T in order to pass the ratio test but on that day his epi-T dose was defective and thus didn't even out the ratio?</p>

<p>Also -- wouldn't cheats use synthetic T made from phytosterol precursors derived from C4 plants in order to pass the isotope test? Though maybe more expensive, Tour teams could afford it. Is there some reason this would be too difficult?</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#132592">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="132711"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#132711">124. </a></span><span style="color:#036">miles </span> on August 13, 2006  6:44 PM writes...</p>
<p>aren't blind numbers assigned to the test samples?</p>

<p>the lab tech wouldn't know whose sample he/she was testing?...</p>

<p>don't attach much credence to the rationality/politics of this.</p>

<p>If Landis tested high for the ratio of testerone/natural by-product of testerone, and, as a further confirmation, can be shown some of that testerone was synthetic..</p>

<p>well, regardless of rather than was a factual benefit or not, he's standing of now he's in violation.</p>

<p>and not sure of what role an athelete participating in a marathonic event would have on degradation rates for the tested substances.<br />
 <br />
these are just questions that hope are factually and scientifically resolved before the final verdict is in.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#132711">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="132959"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#132959">125. </a></span><span style="color:#036">Mac </span> on August 14, 2006  2:11 PM writes...</p>
<p>Yes, of course the world is out to get America.  :-)</p>

<p>And the French newspapers did not rave about Landis's ride.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#132959">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="133003"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#133003">126. </a></span><span style="color:#036">AnAmericanInParis </span> on August 15, 2006  4:17 AM writes...</p>
<p>C'mon guys: why would the French (labs, journals or anybody else for that matter!) want to give cycling such a bad rap ? !</p>

<p>What you seem to ignore, and I surmise that you DON'T READ those french newspapers you're refering to, is the devastating bad-rap that this very sad situation gives to CYCLING !  </p>

<p>The french LOVE this sport, when both Lemonde AND Armstrong won the Tour de France believe me, there was nothing but praise AND respect ... </p>

<p>Please, cut the righteous, xenophobic bullshit and get real ...</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#133003">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="133026"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#133026">127. </a></span><span style="color:#036">Realist </span> on August 15, 2006  7:53 AM writes...</p>
<p>Can someone explain to me why the French tampering with Landis's sample is a far more credible than him taking a banned substance in order to improve his performance?? This coming after his miraculous recovery after stage 16.</p>

<p>From my perspective, the first explanation is completely far fetched, while the second is quite credible considering the turn of events.</p>

<p>How can any objective person think otherwise?  </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#133026">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="133086"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#133086">128. </a></span><span style="color:#036">Jim Thorpe </span> on August 15, 2006 12:48 PM writes...</p>
<p>"Can someone explain to me why the French tampering with Landis's sample is a far more credible than him taking a banned substance in order to improve his performance?? This coming after his miraculous recovery after stage 16.</p>

<p>From my perspective, the first explanation is completely far fetched, while the second is quite credible considering the turn of events.</p>

<p>How can any objective person think otherwise?"</p>

<p><br />
I would agree totally if he tested for EPO. What you're missing, "objectively," is motive. Firstly, I don't know that 'witch hunt' is the prevailing hypothesis, it takes only a little imagination to come up with circumstances other than organised conspiracy to explain Landis' innocence. It could be a disgruntled lab worker, message therapist, simple detection mistake (I've been reading "Omnivore's Dilema" recently and the first chapter delves deep into the effect corn and corn by-products have had on spectra analysis of carbon-isatope ratios in Americans compared to all other people of the world.</p>

<p>The thing that leads some of us to hold out hope that he was clean on the day is the realisation that all of the riders are indirectly forced into using PEDs by the very same directors of the sport who lambast the cyclists when they get caught. Because they all use the crap, they all understand when/how it works, and for that reason it is very hard to imagine why L would have used T that night -- IT WOULDN'T HAVE HELPED HIM WITH A ONE TIME DOSE! He's not too stupid to have known that. Even the French newspaper criticising Landis concedes that fact.</p>

<p>Now, show me a theory that explains how he could have attained a boost from a one-time usage and have thought he'd pass the test and I'll lean more toward the guilt side. I proposed in my last post: Could he have been taking T and epi-T through the race but had a defective dose of epi-T on that day which caused his ratio to go out of wack? I don't know if that's scientifically possible but I acknowledge it's worth looking into.</p>

<p>As for reason why a disgruntled lab tech MIGHT have drugged his pee, fame. Look at the Korean scientist who faked cloning results. He also may have justified it by telling himself: "I know Landis uses just like all the rest of the athletes who were disqualified before the race. It's not fair that Landis wasn't also disqualified."</p>

<p>Do I really believe this senario? No, that is, I have no reason to suspect so but it's certainly possible. Is it less logical to suspect a disgruntled lab tech than to suspect Landis would have chosen to take Testosterone (which would give him no performance boost) full-well knowing he'd be disqualified rather than just blood packing (which he could get away with) or taking EPO which WOULD have given him a performance boost?</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#133086">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="133275"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#133275">129. </a></span><span style="color:#036">Realist </span> on August 16, 2006  4:33 AM writes...</p>
<p>Any scenario, however outlandish is possible. However, as soon as we start arguing motive over scientific fact, then what is the point of drugs testing at all?</p>

<p>Infact, why not forget testing for those who are deemed decent sorts, who wouldn't possibly cheat? We all know that even if they were to fail, it couldn't possibly be true! Woe betide any of those untrustworthy Europeans however, if they fail, then it's just confirming what we already suspected anyway.<br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#133275">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="133343"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#133343">130. </a></span><span style="color:#036">Jim Thorpe </span> on August 16, 2006  9:57 AM writes...</p>
<p>"Any scenario, however outlandish is possible. However, as soon as we start arguing motive over scientific fact, then what is the point of drugs testing at all?"</p>

<p>Common "Realist",</p>

<p>As I said before, were it EPO, we wouldn't be holding out hope of Landis' innocence.</p>

<p>To illustrate the point: Surgical modification is illegal for the Kentucky Derby as well as the Westminster Dog show. If a horse won the derby but it later came out that there had been a cosmetic ear surgery, people would want real answers before taking the horse's title from it.</p>

<p>Sure, cosmetic, ear-reconstructive plastic surgery could help a dog win Westminster, but it does absolutely nothing for a racing horse. That's what seems to be going on here -- by all accounts, a one time dose of testosterone has no benefit for road racing. </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#133343">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="133352"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#133352">131. </a></span><span style="color:#036">Realist </span> on August 16, 2006 10:34 AM writes...</p>
<p>I understand your point, however the suitability of the banned substance in question to cause what was widely considered the greatest feat in tour history cannot itself be proof of innocence.</p>

<p>If resorting to testosterone was deemed beneficial to Landis's cause, would it be that surprising to other substances at his disposal, regardless of whether they were eventually detected or not? <br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#133352">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="133424"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#133424">132. </a></span><span style="color:#036">cbs </span> on August 16, 2006  1:30 PM writes...</p>
<p>Many in the media(and late night comedians)have ridiculed Landis's series of explanations for his failed test.  Most of the explanations (naturally hight T, drank too much alcohol, dehydration, cortisone etc.) would likely not stand up to a confirmed isotope test. And Floyd would have known that such a test was either done or forthcoming.  Therefore, his explanations now sound more like someone truly innocent.  To think otherwise, Floyd would have to be dumb enough to take T during the race when it likely would give him little or no benefit.  Then he would have to be dumb enough to race so hard on 17 that he drops all competitors and wins the stage, thus ensuring that he would be tested.  Then he would have to be dumb enough to trot out a bunch of excuses that he knows would not hold up when the isotope test came back positive. </p>

<p>It does not seem that Floyd knowingly took T between 16 and 17.  His behavior would indicate otherwise.</p>

<p>Admittedly, another possibility is that he blood doped between 16 and 17 with blood that was contaminated with T from an earlier time period and Floyd just did not realize it was contaminated.  This would better explain the performance Floyd exhibited on 17.  Does anyone know whether the process of blood doping (taking out blood, concentrating the red blood cells, then re-injecting later) would remain contaminated w/ high T? </p>

<p>cbs</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#133424">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="133481"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#133481">133. </a></span><span style="color:#036">FFan </span> on August 16, 2006  7:38 PM writes...</p>
<p>Something that no one seems to be commenting on from Floyd’s journal:</p>

<p>“It is widely known that the test in question, given as a urine sample after my victorious ride on stage 17 of the Tour de France, returned an abnormal T/E ratio from the “A” sample. I want to be entirely clear about one point of the test that has not been fairly reported in the press or expressed in any statements made by international or national governing bodies; the T value returned has been determined to be in the normal range. The E value returned was LOW, thus causing the skewed ratio.”</p>

<p>If true, then first off, let’s throw out all the arguments about Floyd taking testosterone to enhance his performance, (as unlikely as that would be given everyone’s acknowledgement that it can’t really do anything over a short period.)</p>

<p>Other questions I have.<br />
How often and when were other urine samples taken and tested?  <br />
Was a urine sample taken on one of the following stages and does it make sense for that sample to read normal?  (Can your T/E ratio normalize that quickly)  <br />
If the E value was LOW, what is the explanation for that?  I have to assume that you don’t make your E value LOW by taking testosterone!  <br />
Why doesn’t anyone other than Floyd comment on the unethical behavior of the labs in breaking their own rules about release results to the press early?</p>

<p>mee<br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#133481">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="134254"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#134254">134. </a></span><span style="color:#036">Jim Thorpe </span> on August 21, 2006  9:04 AM writes...</p>
<p>That is very interesting, FFan. Where did you get his journal from? Are the test-result details still being held under wraps?</p>

<p>As I understand it (though I could be off on this), T is converted to Epi-T in the body and the process is greatly enhanced during aerobic exercise. High levels of T, among other things, lead to hair loss. This is why people who do constant aerobic exercise have fuller heads of hair. (What does Landis' hairline look like? :)</p>

<p>Landis had been riding like a stallion until stage 16 so it may be reasonable to consider this hypothesis:</p>

<p>Could his performance in the start of the race have caused his body to build up a T to E conversion dampening in the way ones body gets "used to" metabolising drastic dietary changes? That is, could he have been cranking out T and converting it like mad at the start of the race then, after a few days, his body got used to the extra aerobic exercise and slowed down the conversion rate to match his increased aerobic exercise. After his body had adjusted to the increase in aerobic exercise, he had a disastrous, comparatively anaerobic, stage 16.</p>

<p>His body, relying on major aerobic exercise to convert T to E, suddenly didn't get the boost to which it had adjusted and his E level dropped drastically as a result. He relied on increased aerobic exercise for the conversion the way a bulimic relies on laxatives to have a bowel movement. Stop taking laxatives and constipation results. Stop the aerobic exercise and stunted conversion of T to E/low E levels results.</p>

<p>In the tests to determine 'normal' hormone levels. I seriously doubt they managed to get any athletes to suddenly find a psychological 'zone' in which they rode 15-stages-worth over several days at a peak of performance -- a level of riding far surpassing the levels they'd ridden at heretofore ti their lives -- and then... suddenly stop the extra aerobic exercise. Any of us who cycle know what it's like to get on a bike one day and find yourself suddenly in a 'zone' -- it feels like you're effortlessly flying and your accomplishments when in such a zone are way beyond your normal riding achievements. Landis had ridden in one of those zones for 15 stages. It's quite possible he went through some minor, short-term physiological compensations. Add to that the cortisone and thyroid and I think we have a situation that has never come close to having been tested in a lab to discover what's "normal."</p>

<p><br />
As for the theory that Landis accidentally blood doped with tainted blood: I considered that, but If I were a pro-cyclist I sure as hell wouldn't be getting my bags of blood mixed up! I really doubt a Tour-level rider with 10 years experience would make such a rookie mistake. All it would take is a simple system -- like two mini-fridges to keep the blood straight. What's more, I doubt you'd bring the fridge full of dirty blood with you to the tour.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#134254">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="134258"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#134258">135. </a></span><span style="color:#036">Jim Thorpe </span> on August 21, 2006  9:17 AM writes...</p>
<p>Realist:</p>

<p>"I understand your point, however the suitability of the banned substance in question to cause what was widely considered the greatest feat in tour history cannot itself be proof of innocence."</p>

<p>Exactly my point. It does not prove his innocence (since when are the accused in a position of needing to 'prove' innocence?). More importantly, though, it does not prove his guilt. The inappropriateness of the accused substance should, at a minimum, demand further testing/investigation before a charge of guilt is levelled .</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#134258">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="134305"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#134305">136. </a></span><span style="color:#036">FFan </span> on August 21, 2006  6:18 PM writes...</p>
<p>Floyd's comments about his T/E ratio are on his website in a blog at:<br />
<a href="http://www.floydlandis.com/blog/2006/08/04/175/" rel="nofollow">http://www.floydlandis.com/blog/2006/08/04/175/</a><br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#134305">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="134334"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#134334">137. </a></span><span style="color:#036">Realist </span> on August 22, 2006  2:53 AM writes...</p>
<p>>Exactly my point. It does not prove his innocence >(since when are the accused in a position of >needing to 'prove' innocence?). </p>

<p>Well yes, it is for him to explain how it came to be in his system. </p>

<p>Anyway, at the end of the day it'll for tribunals with more evidence and with a greater understanding, to eventually decide whether he's guilty or not. I'm sure the correct decision will be reached, whether the posters on this page agree or not. It'll be interesting to see what this decision is.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#134334">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="134355"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#134355">138. </a></span><span style="color:#036">Jim Thorpe </span> on August 22, 2006  6:43 AM writes...</p>
<p>Realist,</p>

<p>"Well yes, it is for him to explain how it came to be in his system."</p>

<p>Actually, on second consideration, I fully agree. He has some explaining/researching to do.</p>

<p>Lets not prematurely convict him though. I too will be interested to see what happens -- and If it turns out that he truly used testosterone during the race, I think a ban from the sport on account of sheer stupidity is well in order.</p>

<p>Many of us are just sceptical/holding out hope that the guy's not a total f'ing moron.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#134355">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="134916"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#134916">139. </a></span><span style="color:#036">Keith </span> on August 24, 2006  9:24 AM writes...</p>
<p>I find it very peculiar why there has not been any mention that the lab found Landis' testosterone levels to be high only his t/e ratio. Every lab would run a testosterone level as well ...yet no mention of this. Am I to assume then that his T levels  were normal. I'm sure the lab would have jumped on the opportunity to leak this as well. His testosterone levels are within normal values. And everyone is reacting to the t/e ratio and assuming he is a doper and using testosterone to enhance his performance. Yet his t levels are normal. As a pharmacist I also find it odd that his ratio was found to be high on only one day.  If Landis did use testost. his labs would have shown it for more than one day even if he used it for that one day. I also find it hard to imagine that an athlete would use testoterone to improve his performance for one day .... the hormone doesnt work that way and i am sure that landis and his doctor know that. I find alot of things about this case to be odd in assuming that Landis used testost. and find more things  that point to his innocence and the lab to be engaging in suspicious activity. </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#134916">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="135359"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#135359">140. </a></span><span style="color:#036">biker </span> on August 26, 2006  8:57 AM writes...</p>
<p>post #139--yup, it's a simple as that! too many odd facts that dont add up; i believe it's called framed, on purpose or because the lab's poor technique***</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#135359">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="135492"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#135492">141. </a></span><span style="color:#036">Kris Houser </span> on August 27, 2006  2:17 AM writes...</p>
<p>Testosterone is very effective as a one-day performance enhancer.  For example, women use it in prescription transdermal creams (very dilute, designed with levels appropriate for women).  Women can apply testosterone cream on a very infrequent or occasional basis, with the purpose being to heighten sexual desire, to increase stamina and to shorten recovery time after strenuous exertion.  <br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#135492">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="135535"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#135535">142. </a></span><span style="color:#036">Trombones Mc Ghee </span> on August 27, 2006 12:11 PM writes...</p>
<p>I think he was somehow dosed surreptitiously. It wouldn't be hard for anyone that handled his food or drink and that also needs more money (who doesn't?). There wouldn't be any shortage of those motivated to NOT see another American win the Tour. I really hope the truth sufaces whatever it is.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#135535">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="135651"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#135651">143. </a></span><span style="color:#036">Keith </span> on August 28, 2006  2:11 PM writes...</p>
<p>re #141  where do you get your info from? Testosterone as a one day performance enhancer ... there are numerous studies and there is no documentation or research that proves that testoterone or other androgen acts to provide athletes any benefit in performance esp in one day<br />
thats a placebo affect (advertising affect) you read about to sell yu </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#135651">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="135968"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#135968">144. </a></span><span style="color:#036">D Lewis </span> on August 29, 2006  2:40 PM writes...</p>
<p>Some observations. </p>

<p>1) Several days before Mr Landis had his day in the alps, there was a 28 minute breakaway. Everybody recognized that to give away 28 minutes was a terrible tactical mistake. Mr Landis's time on the now infomous stage 17 was exactly in line with the times he rode stage 17 in training. The times that the rest of the feild were sustantially slower than their training times. Given this, how does one conclude that Mr Landis "must have cheated?".</p>

<p>2) Several days before the start of the Tour, many riders were excluded and labled as cheats. Subsequently, six riders were exonerated of any wrong doing (without much fanfare). How does one remove that brand?</p>

<p>3) It is my understanding that the introduction to the testing protocol states that the test is "Unreliable". I am also given to understand that the thresholds for the test have been reduced year after year. </p>

<p>4) What financial interest would the lab have in a totally clean sports environment? Seems to me that the lab would financially benefit by keeping a cloud of suspision over all forms of sporting endeavors.</p>

<p>5) I find it totally ironic that the French, renowned for having no balls at all, would object to any athelete having testostorone in his system.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#135968">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="135997"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#135997">145. </a></span><span style="color:#036">Keith </span> on August 29, 2006  8:05 PM writes...</p>
<p>The bottom line to all this is that Floyd has won this race fair and square. The reason being is the fact that even if Floyd tried to use testosterone as an incentive to gain as  advantage it was not from the testoterone that won him the race but his own determination and training and guts ( as well as staying hydrated and drinking plenty of water AND TACTICS) that won him the race. Floyd was in the lead or near the lead throughout the race not just one day and always tested clean. TESTOSTERONE ON A ONE DAY BASIS DOES NOT PROVIDE THAT KIND OF BENEFIT. PERIOD PERIOD PERIOD  THIS WHOLE THING AGAINST FLOYD IS SICK HE WON IT ON HIS OWN ABILITY TRAINING AND DETERMINATION  go FLOYD <br />
 I TRULY HOPE THAT YOU HAVE THE CHANCE TO COME BACK NEXT YEAR AND RACE AND KICK --- BECAUSE THE  ENTIRE SPORT OF CYCLING WOULD BE WOULD BE AT A DISADVANTAGE IF YOU DONT,  THE FRENCH JUST SCREW THEMSELVES IN THIS RACE... JUST AS THEY  DEPRIVED ULRICH BASSO AND ECT..... They try to eliminate  anything that deprives them from the limelight of their national sporting event. That is truly the signal they are sending me!!!!!!</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#135997">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="136027"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#136027">146. </a></span><span style="color:#036">Realist </span> on August 30, 2006  3:05 AM writes...</p>
<p>145. Keith</p>

<p>Head in the sand.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#136027">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="136066"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#136066">147. </a></span><span style="color:#036">Keith </span> on August 30, 2006 11:50 AM writes...</p>
<p>Fact "realist"!!!!!! Your anything but, judging from your comments above  </p>

<p>Guilty <br />
I rest my case</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#136066">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="136178"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#136178">148. </a></span><span style="color:#036">Realist </span> on August 30, 2006  2:51 PM writes...</p>
<p>Looks like someone else has elevated testosterone levels.</p>

<p>At what stage is he not guilty of failing the drugs test? As I said, in the fullness of time, the US doping authorities will decide, at which point you'll probably be still arguing this is an anti-american conspiracy.</p>

<p>Maybe you've got some interesting theories on Tyler Hamilton? Better still, Marion Jones or Tim Montgomery or Justin Gatlin..... </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#136178">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="136314"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#136314">149. </a></span><span style="color:#036">D Lewis </span> on August 30, 2006  9:38 PM writes...</p>
<p>Having read the entire thread I AM CONFUSED!</p>

<p>The test that Floyed failed was the T/E ratio test which checks the ratio of two naturally produced body products. All natural. If the ratio is to high, for what ever reason, it is infered that the donor must have cheated? Yet the test that Floyd failed yeilded no direct evidence of any illigal substance. </p>

<p>Is this a correct understanding?</p>

<p>I also read that alcohol, which is perfectly legal I presume,  may alter the T/E ratio. This seems reasonable given that a lot of common drunks exibit aggressive behavior while intoxicated ( is this a result of increased testostorone?). </p>

<p><br />
Is this also a correct understanding?</p>

<p><br />
So if I have a couple of drinks and alter my natural T/E ratio I am guilty of using banned drugs?</p>

<p><br />
If they cannot find any direct evidence of illigal drugs being present, then it seems to me that there is nothing to talk about. <br />
Innocent until PROVEN guilty.<br />
Thank god I live in the USA!</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#136314">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="136488"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#136488">150. </a></span><span style="color:#036">Keith </span> on August 31, 2006  2:51 PM writes...</p>
<p>The Lab ran a test which compares the amount of tesoterone to epitestosterone in his urine. It is a ratio of two naturally occuring hormones and ussually is around one to one. This the lab said was high in Floyd. Labs also run other tests and one is to determine a persons testoterone level. It looks at testoterone solely and I am sure this lab ran this test everyone would and does. The lab did not make an issue of this and say it was high it only came out and said his t/e ratio was high and as a result everyone has assumed his T levels are high and he uses testoterone.  If his t-levels were high I am sure the Lab would have made this the primary story. They didnt  I assume his t levels are normal .....his testosterone levels are no higher than any other normal male.    there are many reasons why a t/e ratio can vary</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#136488">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="136663"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#136663">151. </a></span><span style="color:#036">RLM </span> on September  1, 2006  3:32 PM writes...</p>
<p>I purused the thread and still am shaking my head.</p>

<p>Will someone answer the following questions:</p>

<p>1) How many times before S-17 was Landis tested?<br />
2) Did any of those show out of bounds ratios?<br />
3) Is it possible to change ratios in one day?<br />
4) How many times after S-17 was Landis tested?<br />
4.5) What were those ratios?<br />
5) Did any of post-S-17 tests show a synthetic form of T?<br />
6) How long is synthetic T detectable after "ingestion"?<br />
7) If synthetic T is detectable for "days" after "ingestion", WHY did it NOT show up in these tests?</p>

<p>If the ANS to 5) is no and ANS to 6) is greater than a day, one can only conclude that Landis sample was mishandled.  Case closed, bash the French lab and sue the crap out of anyone who looks to take away the yellow.  In other words go on the attack; ruthlessly!!  Like Armstrong would have done if in the same position.</p>

<p>I'm an EE for a living and may not understand all the chemistry/biology/physiology/etc but isn't this is a fairly common sense line of questioning.  Please show me where my logic is flawed .</p>

<p>Still shakin my head....</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#136663">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="137025"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#137025">152. </a></span><span style="color:#036">nautiq </span> on September  3, 2006 12:14 AM writes...</p>
<p>(28. Ed Minchau) - you are right on with your comments.</p>

<p>People! wake up and look at the physique of athletes today compared with 20 years ago.</p>

<p>the only way to compete is to take some sort of supplement or steroid.</p>

<p>I don't think floyd outright cheated, but the  truth is if you don't take something, you'll never come close to competing with today's athletes.</p>

<p>they should just do away with all the drug regulations and let people do whatever it takes to win.  The whole point of sports is to entertain us comon folk, so what could be better than watching juiced up athletes performing amazing feats that no natural human being could do.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#137025">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="137422"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#137422">153. </a></span><span style="color:#036">Landis </span> on September  5, 2006  3:05 PM writes...</p>
<p>It would not be too surprising if C4 plant sources of the synthetic precursors to testosterone, diosgenin and stigmasterol, are being used in combination with their C3 sources-soybean and yam oils.  Then the resulting testosterone molecules could be tailored to have 13C/12C isotopic signatures characteristic of European or North American diets, thus circumventing detection.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#137422">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="137534"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#137534">154. </a></span><span style="color:#036">Alan Stempel </span> on September  5, 2006  9:03 PM writes...</p>
<p>You have explained that synthetic testosterone is made from phytosterol percursors, typically derived from wild yams or soy (C3 plants), and that C3 plants have a slightly different C12:C13 ratio than C4 plants, a typical component of the Western diet.  Wouldn't endogenous testosterone from an individual having a diet that is atypically rich in C3 plant matter (such as one who eats lots of tofu) have a C12:C13 ratio that resembles that of synthetic testosterone?</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#137534">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="137643"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#137643">155. </a></span><span style="color:#036">landis doner </span> on September  6, 2006 10:43 AM writes...</p>
<p>Alan is correct, so it seems that Europeans, who consume beet sugar rather than cane sugar (in US both are consumed), starch from sources other than corn, and who consume products from animals fed mainly on C3 plants, would produce endogenous testesterone depleted in 13C and with a 13C/12C ratio similar to that in soy and yam-derived phytosterols.  I don't know what the ratios were for Landis' testosterone, but wouldn't one expect it to largely reflect the European diet, since cyclists spend a couple months there preparing for le Tour de France?  Perhaps the ratio approaches that of synthetic testosterone the longer time one spends there.  But maybe the American cyclists (and all the others) consume enough soft drinks, energy bars etc. (which contain loads of C4 carbon) to retain something close to their "western values".  Then doping with synthetic testosterone would be more easily detected.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#137643">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="137701"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#137701">156. </a></span><span style="color:#036">Keith </span> on September  6, 2006  8:26 PM writes...</p>
<p>Ah RLM !!!!!!!  finally someone with questions that matter. All this concentration on C12 c13 c14 isotope found in Landis. But no where do they say how much was found or to what extent it deviated from what is found to  be normal . All they say is that they have detected testoterone that  has a different istotope from that  produced by the body....c12  and then assume that the only way it could have shown up is through the administration of exogenous testosterone. And I do not Know this  aspect  of the production of testosterone in the body. But as many have stated above, the body uses all the scources of carbon that it receives and some of it is in the form of c12 c13 c14  and the result is that we can have  all three in our bodies depending what we use as a source of carbohydrate.Cyclist seem (understatment) to use quite a large varieties of  of carbohydrate and their bodies go thru quite alot of extreme situations so it seems that C12 would not be the only carbon found and the others may be in higher concentrations from that normally seen.  As a pharmacist i can tell you that   Landis would not have gained any enhancement by taking Testosterone for one day ..for one stage..., at least not physically or physiologically ( maybe thru the placebo affect (psycologically) but that lasts   for only a while until the body reacts to  reality). And the answer to your questions is no  ..... testosterone stays in your body for longer than one day. I know that for A FACT!!!!!and would have shown up in the post s17 tests. Mister "Reality"  yu make me sick with your trash superficial comments that only  create the society that so many of us try to avoid... of being found guilty before having the ability to have our say.   Your Comment </p>

<p>"Guilty ...I rest my case"</p>

<p>The reality is you say nothing!!!! But try to create a very ugly situatiion for an individual "Landis" before he has his say and only thru your ignorance..... sorry to the others for this, but i hate people like this! The lab and who ever else who may be involved in the leak know that the public has a very limited knowledge   of the subject and if they present it in just the right way they can create a very ugly situation for someone !!!!!  And as a professional, labs,  know which (tests) have solid foundation to reveal any significant findings ... and the ones they used just dont have that....  too many variables!!!! But leaked it anyway!!!!</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#137701">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="137728"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#137728">157. </a></span><span style="color:#036">Realist </span> on September  7, 2006  3:04 AM writes...</p>
<p>Whatever your protestations Keith, he's been found guilty of failing both the A and B tests. The only reason he hasn't been stripped of his title yet, is that he doesn't have the dignity to accept he's be caught fair and square. After all the dust has settled and all the hearing have been heard, no doubt he'll be found guilty. </p>

<p>Like Tyler Hamilton before him, he has the opportunity to clean up the sport, by implicating those who abetted him, however he chooses not to do so. This is what makes me sick mate.</p>

<p>I don't think assuming that the glaringly obvious is the most likely truth makes me ignorant, only you. <br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#137728">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="137739"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#137739">158. </a></span><span style="color:#036">Realist </span> on September  7, 2006  4:42 AM writes...</p>
<p>Incidentally, for one who's supposedly championing the right 'to have your say', you seem determined to deny me the right to do so. The reason it seems is that my own take on the situation dares to differ from your own.</p>

<p>America, the land of the free?</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#137739">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="137808"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#137808">159. </a></span><span style="color:#036">Realist </span> on September  7, 2006 12:10 PM writes...</p>
<p>There are a few genuine facts in this whole sorry affair :</p>

<p>1. Landis lost 10 minutes on stage 16 and looked dead and buried.<br />
2. Landis beat the entire field by 8 minutes the following day, following a miraculous solo ride.<br />
3. Landis subsequently tested positive for banned substances on stage 17.<br />
4. The lab was UCI accredited.<br />
5. The tests themselves are UCI sanctioned.</p>

<p>With these facts in mind, the most obvious conclusion that I can come to is that Landis's ride on stage 17 was aided by banned substances and he was caught. Any rational person would come to the same conclusion. </p>

<p>This conclusion is unrelated to his nationality, nor influenced by the press, or am<br />
I a casual observer new to the Tour, having followed it religiously for 15 years.</p>

<p>None of the explanations on this page are based on anything other than opinion or speculation.<br />
If his innocence was so easily explained, why are we even having this argument? If the tests<br />
are so fundamentally flawed, why would he need to put forward the list of excuses that he has so<br />
far?</p>

<p>At the end of the day, it is for Landis to explain how banned substances ended up in his body and<br />
until that day, I have every reason to assume that he has been caught fair and square. If those of<br />
you who refuse to believe that American atheletes ever cheat, then that's your choice. Just don't expect the rest of the world to join you.<br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#137808">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="138316"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#138316">160. </a></span><span style="color:#036">Bikenut </span> on September 10, 2006 10:42 AM writes...</p>
<p>I'm amazed at some of the stupidity here. Sometimes, regardless of what has been shown, and certainly not yet proven, you have to have some common sense based on what facts ARE known. </p>

<p>It is well documented what the effects T has on the body, how long it takes to gain any benefit from using it, how long it stays in the body, the fact that T builds muscle mass (the last thing a cyclist even wants. Why do you think they're skinny as rails?) and that all previous tests and more importantly ALL POST TESTS proved negative. ALL POST TESTS WERE NEGATIVE! The body simply does not clear T this fast (unless a patch was used but then even less of an effect would be obtained from using T). Highly recognized doctors have agree on this.</p>

<p><a href="http://www.cbass.com/FloydLandis.htm" rel="nofollow"><a href="http://www.cbass.com/FloydLandis.htm" rel="nofollow">http://www.cbass.com/FloydLandis.htm</a></a></p>

<p>It is well documented that there is no short term gain from taking T. And even if you were stupid enough to take it thinking you MIGHT have some short term gain, you know you'd be tested and it WOULD BE FOUND. WHY would a professional do this? THIS MAKES NO SENSE!</p>

<p>I don't care what nationality is involved, I'm not placing blame until all facts are known, I also realize that no test is perfect, I know that whoever leaked the news is a schmuck, but more importantly, as we all become more educated in T, isotopes, C13, C4, yams and what not, common sense tells me that Floyd having knowingly taken T during the race MAKES NO SENSE! If you were going to cheat there are better things to take that WOULD HAVE A SHORT TERM EFFECT. But T aint it.</p>

<p>Nothing may ever be proven 100%, but in the end Floyd will forever have a black mark on his name and for that I blame the lab and media for leaking the story....but I guess this is the same old story...guilty until proven innocent.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#138316">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="138465"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#138465">161. </a></span><span style="color:#036">Drifter </span> on September 11, 2006  3:17 PM writes...</p>
<p>What a thoroughly amusing and interesting read on a rainy afternoon! And we don't know yet that Landis is guilty - and in this particular instance, much of the world has given him that space, not treating him as guilty, with the except of a notable Dick Pound, Greg lemond, and "Realist"!  For "Realist", please go over your posting of September 7 - you have yourself wrapped around your axle.  Items 1,3,4 and 5 are correct.  Item 2 is not - Landis' time for this stage was entirely consistent with his training regimin, there was noting miraculous about it.  What made it so devastating on the rest of the peloton was the tactical move made by Landis, and the decision by the peloton to let him go. Now for your axle wrap: "the most obvious conclusion that I can come to is that Landis's ride on stage 17 was aided by banned substances" - the positive test for the banned substance was not for a substance which improves short-term performance.  You have seemed to ingnore this fact thoughout this entire discussion, as have all of those who state the same conclusion, that Landis' performance in Stage 17 was aided by . . . what? an elevated T/E level? When the "T" level itself was normal? So, since there was evidently (based on the evidence) no shot of "T", and the "E" was low, did supressing epitestosterone produce this nonmiraculous tactical breakaway?  "Realist", you've got some critical thinking to do.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#138465">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="138601"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#138601">162. </a></span><span style="color:#036">Realist </span> on September 12, 2006  3:05 AM writes...</p>
<p>That's it you Landis lovers, you win.</p>

<p>Yes, he's clean, it's a set-up, there was nothing remotely strange about his collapse and subsequent recovery and from now until the end of time he will be remembered the in the upper echelons of cycling greats with Mercx and Hinault.</p>

<p>At the end of the day, it doesn't matter what I think though, only the authorities, or he'll forever be known as the bloke how cheated and was stripped of the Tour de France title.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#138601">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="138723"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#138723">163. </a></span><span style="color:#036">Drifter </span> on September 12, 2006  8:36 AM writes...</p>
<p>C'mon, now "Realist", you'd probably better change that name to "Reactionist".  I'm just asking you to clarify your rational process, not declare Landis innocent or explain how the results came to be what were reported.  The point here is that your argument disproves your hypothesis, that's all.  Even if Landis did dope up on "T" after Stage 16, the use of that "banned substance" in this instance did not aid him in Stage 17.  That's a scientific impossibility.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#138723">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="138738"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#138738">164. </a></span><span style="color:#036">Realist </span> on September 12, 2006  9:54 AM writes...</p>
<p>Depending on what you read, that may or may not be the case. Regardless, I don't think this can be used as a basis for declaring his innocence, which seems to be the main argument here.</p>

<p>My own suspicions are that this was only one of a range of substances used to retrieve a hopeless situation after stage 16. As Frankie Andreu's admission of EPO use today shows, avoiding detection isn't difficult given sufficient resources. This however is speculation on my part, even if it does to me seem more probable than the conspiracy theories put forward by the other posters on this page.</p>

<p>At the end of the day, he's failed a drugs test and it is up to him to explain how it came to be in his system. So far we've had a load of half baked excuses about dehydration, alcohol etc. etc. Today it's discrediting the lab and the tests. Only he knows whether it's a huge miscarriage of justice or an expensive exercise in getting away with it. I suspect the latter, however at the end of the day it'll be for the authorities to decide. </p>

<p>Incidentally, let's here someone defend Tyler Hamilton here....</p>

<p> </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#138738">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="138742"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#138742">165. </a></span><span style="color:#036">D Lewis </span> on September 12, 2006 10:04 AM writes...</p>
<p>As have said all along, the real reason that Mr Landis is in so much trouble is that the French object to men with testostorone, i.e BALLS!</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#138742">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="138920"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#138920">166. </a></span><span style="color:#036">Jim Thorpe </span> on September 12, 2006  8:49 PM writes...</p>
<p>"Realist"</p>

<p>All right matey, I followed your rational comments for most of the thread (and even conceded a point to you -- it is for HIM to prove). You've let Keith's uber-patriot use of the exclamation mark and capitalisation draw you into an argument, though. Your comments are ever less coherent, and becoming self contradictory at worst and tenuous at best.</p>

<p>I'll grant you that some Americans have a real stick up the arse about being victimised and bullied (the irony of it). But, we don't help to alleviate their concerns by rushing to judgement in cases that actually do have a cloud of confusion surrounding them.</p>

<p>All I am saying here is that there is so much logical reason to suspect the tests may be in error that we ought to let the process play out.</p>

<p>We know that they all unfairly dope. Yet we are to laud them so long as they don't force us to confront the fact and then suddenly condemn them when they do force us to confront the fact. What are we really upset about -- that they dope, or that they prevent us from turning a blind eye?</p>

<p>Since Landis is clearly good enough at hiding his dope to make it to the Tour's yellow jersey, let's give him the chance to prove that he had it properly hidden on stage 17 as well.</p>

<p>Excuse me for being a cynic but let's not feign surprise or distress on the accusation of dope -- let's instead give the guy a chance to show that he was technically as clean on stage 17 as the Tour requires.</p>

<p>Then, if he can't satisfactorily pull the wool back over our eves and allow us the guilt-free pleasure of pretending we are supporting a 'clean' sport, I'll gladly stand at your side in dragging him through the streets.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#138920">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="139140"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#139140">167. </a></span><span style="color:#036">RLM </span> on September 13, 2006 11:52 AM writes...</p>
<p>Realist,</p>

<p>Would the test results from the post 17 stages help meet your requirement for Landis to prove his innocence?</p>

<p>My premise here is that once T is introduced it will be there for some period of time (>1-day).  If correct, then performing additional (identical) tests may help.  This was done. Where are those results?  Do they show/coraborate the S-17 test results?</p>

<p>If these tests (post S-17) show no out of bounds ratios/T-levels/etc then, my (or Landis') explanation of the S-17 results would be that the sample (both A and B samples) was contaminated/mishandled.</p>

<p>Help me out here to see my the error in my logic.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#139140">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="139340"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#139340">168. </a></span><span style="color:#036">Dr. Jeff </span> on September 13, 2006  8:29 PM writes...</p>
<p>The problem that most of you have is that you are unfamiliar with the reality of science itself.  For those of us that work in this arena we know that the essence of everything is INTERPRETATION of the data.  In most aspects of the scientific community this is judged by "peer review" a system in which other scientists of similar training and stature look at  the data and determine if the data you have collected actually support your conclusions.  </p>

<p>LET TWO facts be known...1) most of us, even those of very high stature, fail to see all of the problems in our own results, and peer review serves as a key check and balance; 2) there is NO peer review in drug testing laboratories.  Being "sanctioned" by another testing or athletic aurthority is meaningless..it is NOT peer review by experts in the field.  It is really sanctioning by another group of people with the "gotcha" mentality.  Look, if you want to prove that an athelete is doping and you are in any position of handling samples in the testing laboratory, it is not hard to do...not hard at all.  </p>

<p>The stated results in this case have many problems.  First and foremost is that NONE of the raw data have been released for analysis.  The ONLY thing that has been released is the laboratories interpretation of the raw data.  </p>

<p>It should NOT be up to the athelete to provie he is innocent, in other words prove that he/she has NOT doped.  Any with scientific training know that is IMPOSSIBLE to prove a negative!!!  Period.  So the fact that these idiots in the athletic testing agencies set it up that way shows their incompetence and ignorance.</p>

<p>Let me give you an example of a very stupid screw up by the laboratory that could have easily yielded the results that have been quoted:</p>

<p>every lab must run standards prior to testing to ensure that their instrument can pick up a synthetic compound.  Yet what they dont tell you is that the doping standard contaminates the plumbing of the instrument, and therefore is present in many subsequent runs.  I cahllenge them to show us all of the runs of the day on that instrument...and show them documented by the clock.  Show is the real data, not the laboratories interpretation of it. </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#139340">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="139542"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#139542">169. </a></span><span style="color:#036">keith </span> on September 14, 2006  7:29 PM writes...</p>
<p> Yes i let you go Realist!!!! And you show your ignorance ON AND ON AND ON. I ask you where are the results of LANDIS' TESTOSTERONE LEVELS ON THAT DAY. EVERY LAB PERFORMS THAT TEST !!!!!!! IT IS A VERY ROUTINE LAB TEST !!!!!!! WHY WAS IT NOT REPORTED????? MR REAlITY ?????? WHY  BECAUSE THE LAB KNEW IT WAS NORMAL .....PERIOD PERIOD PERIOD HIS TESTOTERONE LEVEL WAS NO MORE OUT OF RANGE THAN YOU OR I OR ANY OTHER NORMAL MALE..... HIS T/E RATIO  WAS HIGH MEANING ( IF HIS TESTOSTERONE IS NORMAL THAT HIS EPITEST  IS LOW ) ..... iF HIS TESTOTERONE IS NORMAL MEANING LEVELS EQUAL TO YOU HOW CAN YOU TELL ME HE IS ENHANCING HIMSELF OR TRYING TO PULL ONE OVER EVERYONE ELSE.THE LAB KNOWING THEY CANT STAND ON THAT RESULT ALONE THEY LOOK FOR SOME OTHER RESULT SO THEY LOOK TO SEE IF THERE IS ANY EXOGENOUS TESTOTERONE AROUND IN LANDIS USING ISOTOPES AND FIND TRACE AMOUNTS. AND REPORT IT!!!! DESPITE THE FACT THAT PROBABLY EVERYONE HAS TRACE AMOUNTS OF C13 C14 IN THEM!!!!!  YOU KNOW REALITY, IS THAT THE REAL FALLACY HERE IS YOU, WITH THE NAME YOU GIVE YOURSELF AND THE IMAGE YOU TRY TO CREATE FOR YOURSELF AND YOU TRY TO PUT LANDIS DOWN FOR BEING FAKE.... YOUR A HIPOCRIT THAT IS WHAT IS SO SICK BECAUSE YOU DONT LOOK AT EVERYTHING AND AS A RESULT OF YOUR LACK OF KNOWLEDGE YOU  JUST JUDGE AN MAKE LIFE FOR SOMEONE  WHO MAY BE INNOCENT VERY VERY UGLY </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#139542">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="139545"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#139545">170. </a></span><span style="color:#036">keith </span> on September 14, 2006  7:48 PM writes...</p>
<p>PS  AND YES MR REALITY MR LANDIS DESERVES, BECAUSE OF THE WAY HE RODE ON STAGE 17 !!!! ESPECIALLY ON STAGE 17!!!!   NOT TO FORGET ALL THE OTHER STAGES HE RODE SO WELL AND RODE IN THE LEAD   TO BE CALLED A CHAMPION !!!!!  IT WAS NOT JUST ONE DAY THAT LANDIS PERFORMED AS A CHAMPION !!!!</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#139545">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="139580"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#139580">171. </a></span><span style="color:#036">jim Thorpe </span> on September 15, 2006  1:34 AM writes...</p>
<p>Keith, most of us agree with you. please calm down and let's continue to have a civil discussion.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#139580">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="139589"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#139589">172. </a></span><span style="color:#036">Realist </span> on September 15, 2006  3:04 AM writes...</p>
<p>Let me get this straight...</p>

<p>13 samples tested positive for the tour, the 12 with theraputic exemptions were all successfully picked up by the lab and yet Landis's was lab error. Not only that, but the same lab error for both the A and the B tests, done at separate times. Yet you realistically expect us to believe that the tests themselves produced the positive, not the sample?</p>

<p>Anyway, you lot can go on deluding yourselves.</p>

<p>I'm off to argue with some people who claim the world is flat, the moon landing never happened and Lance Armstrong won 7 tours because he was 'more determined' than everyone else.</p>

<p>BTW - KEITH, YOU NEED TO CALM DOWN, OR YOU'LL GIVE YOURSELF A HEART ATTACK YOU WEIRDO!!!!!</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#139589">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="139644"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#139644">173. </a></span><span style="color:#036">Jim Thorpe </span> on September 15, 2006 10:17 AM writes...</p>
<p>Realist,</p>

<p>Again, it's not that I believe he's 'innocent' -- none of them are.</p>

<p>The point is that the lab's secrecy allows us only to speculate/brainstorm at the moment. Until more info comes out, your gung-ho, die-hard insistence that his piss was dirty on the day is as completely unrealistic and deluded as Keith's certainty of his innocence.</p>

<p>I'm starting to suspect you as a plant from the prosecution trying to 'bait' us so as to help you prepare for all conceivable arguments team Landis may argue in court.</p>

<p>Your example abt Lance winning 7... You think the other guys were any cleaner than him? Believing Lance doped and his competitors were clean must take some real will power in keeping the wool held securely over your eyes. Lance won because of bloody amazing strength of mind/focus which managed to keep the following factors in balance:</p>

<p>1. Amazing training routine<br />
2. Amazing, abnormal physiology<br />
3. amazing performance-enhancing regimen</p>

<p>He didn't beat them because he doped, he won because he doped 'better'.</p>

<p>Damn, I should be changing my handle to 'Realist' :)</p>

<p>Moreover, which is more ethical/fair:</p>

<p>a. a person dominating the sport because he is born w/ abnormal physiology against which nobody can even compete</p>

<p>b. a rich person/team/country that can set up camp for the athletes at high altitude and produce reduced-atmospheric-pressure training gyms -- thus legally giving the athletes a boost of EPO every bit as dangerous as the synthetic stuff</p>

<p>c. a rich athlete/team that can provide designer, undetectable drugs</p>

<p>d. an athlete w/o superior genes or an enormously wealthy country behind him who takes EPO in order to have the chance to compete against the pros</p>

<p>I say legalise it all. This is not Eugenics or dog breeding. It shouldn't be about weeding the common people from the genetically superior in order to create a super race. It's a strategy and technology sport. Even the playing field by allowing everyone the same advantage. Hell, in golf people get a handicap.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#139644">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="139647"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#139647">174. </a></span><span style="color:#036">RLM </span> on September 15, 2006 10:40 AM writes...</p>
<p>Realist,</p>

<p>I would be most interested in your responses to the questions I posed to you in post #167.</p>

<p>If someone tested positive on Day 1, why would they not have also tested positive on Day 2, 3, 4, etc?  We know they have these results.  Seems to me that if they corraborated the S17 results they would have been leaked too.  </p>

<p>There seems to be a lot of emotion on this topic, little RELEVANT facts, and some disturbing omissions by the so-called "officials" of the sport.  It's really a shame.  </p>

<p><br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#139647">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="139656"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#139656">175. </a></span><span style="color:#036">RLM </span> on September 15, 2006 12:35 PM writes...</p>
<p>Realist,</p>

<p>I would be most interested in your responses to the questions I posed to you in post #167.</p>

<p>If someone tested positive on Day 1, why would they not have also tested positive on Day 2, 3, 4, etc?  We know they have these results.  Seems to me that if they corroborated the S17 results they would have been leaked too.  </p>

<p>There seems to be a lot of emotion on this topic, little RELEVANT facts, and some disturbing omissions by the so-called "officials" of the sport.  It's really a shame.  <br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#139656">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="140206"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140206">176. </a></span><span style="color:#036">Realist </span> on September 18, 2006  3:18 AM writes...</p>
<p>Jim,</p>

<p>I agree with you wholeheartedly. </p>

<p>It's subsequently been 'proved' (kind of) that Basso, Ulrich, Mabcebo, Hamilton etc. etc. were all doped up to the eyeballs and yet they couldn't get close to Armstrong. At the end of the day, I don't think it's possible to win a major tour without assistance; he was the best of a bad bunch so to speak. Same goes for Landis, he was unlucky to get caught. </p>

<p>At the end of the day, it's the self righteous deny at all costs attitude of the riders and the fans that gets my goat. David Millar admitted EPO use without ever getting caught, lost his gold medal, served his suspension and this year, won a stage of La Vuelta. What are the chances of Landis doing the same?<br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140206">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="140208"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140208">177. </a></span><span style="color:#036">Realist </span> on September 18, 2006  3:23 AM writes...</p>
<p>Jim,</p>

<p>I agree with you wholeheartedly. </p>

<p>It's subsequently been 'proved' (kind of) that Basso, Ulrich, Mabcebo, Hamilton etc. etc. were all doped up to the eyeballs and yet they couldn't get close to Armstrong. At the end of the day, I don't think it's possible to win a major tour without assistance; he was the best of a bad bunch so to speak. Same goes for Landis, he was unlucky to get caught. </p>

<p>At the end of the day, it's the self righteous deny at all costs attitude of the riders and the fans that gets my goat. David Millar admitted EPO use without ever getting caught, lost his gold medal, served his suspension and this year, won a stage of La Vuelta. What are the chances of Landis doing the same?<br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140208">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="140331"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140331">178. </a></span><span style="color:#036">keith </span> on September 18, 2006  8:06 PM writes...</p>
<p>Calm down to a fake like Realist !!!!! I  call it the way it is!!!! It is  people like him that create the sick world that we have to contend with.  Never do I ever hear from him any kind of scientific, intelligent profound response that supports his reasoning.  All talk talk talk with superficial comments.  Just ignorant name calling and put downs. You dont understand ... there is a person who has been defamed, found guilty before he has had a right to defend himself a major team that has had to fold, many riders who are without a team because of irresponsible comments and leaks similar to his.  Here is just a little more for those to  think on and respond on. And maybe I would love for MR REALITY to comment on it with a scientific explanation other than his typical.  The lab ran tests on a sample , Sample  A. Many tests were run on this sample.  All these tests were the result of the same sample. Two tests were reported and leaked to the public. Those tests that were leaked were the T/E ratio and an isotope test (to determine exogenous testosterone).Both tests look at testosterone but in different ways. The thing that is very mysterious in the findings of these two results is the large discrepancy in the magnitude of each result. The lab reported a T/E ratio of 11:1... normal is 1:1  they allow 4:1 as acceptable and they reported it.  The same lab using the same sample came up with another finding using the isotope test. They found "trace" amounts of C13 and c14 in Landis urine sample and concluded it was exogenous ....and reported it. And because of it the thought of Landis using banned substances and guilt were thrown on him. Their findings  showed a T/E ratio of 11:1 which most would consider a significant deviation from what is normally found in the average person. Using the same sample They also report that they found "trace" amounts of isotope in Landis' urine sample. And I emphasise "trace".  It seems to me if the results of Landis' high (11:1) T/E ratio were the result of exogenous sources then the isotope test would be equally out of proportion from normal and much higher and be more consistant with the high T/E ratio they found other than "trace" especially since it came from the same sample. But it was not !!!! This can only mean and  if you use logic ... since the results of the isotope test were so much lower(trace) than his T/E ratio(11:1)  the  results for the T/E were not the result of exogenous testost. but a result of his own physiology on that day .Also taking into consideration his Testosterone levels were normal.  MR REALITY I look foward to your typical "head in the sand " response.BUT, Maybe you can think this time and would love to hear some scientific meaningful response from you. And, if there are some lab people out there that can shed some light on this ...please respond  because i think that this difference has a very profound significance on this case. </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140331">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="140334"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140334">179. </a></span><span style="color:#036">keith </span> on September 18, 2006  8:31 PM writes...</p>
<p>Realist ...Landis' was the only one that came out positive out of the entire peleton. Your wrong!!! i also love your statement which just justifies your logical way of thinking " I quote It's subsequently been 'proved' (kind of) that Basso, Ulrich, Mabcebo, Hamilton  I have never seen anything that has been proved KIND OF.  Why Do you respond please save us <br />
Jim I am not naive enough to just accept that Mr Landis is innocent  except to think of him as innocent untill I see proof that he is not. And to this day i have not seen it. And I said from the beginning see more that points to his innocence and that the lab was irresponsible.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140334">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="140351"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140351">180. </a></span><span style="color:#036">Realist </span> on September 19, 2006  2:57 AM writes...</p>
<p>Yawn!</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140351">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="140352"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140352">181. </a></span><span style="color:#036">Realist </span> on September 19, 2006  2:59 AM writes...</p>
<p>I'm looking to see that the science of the lab is proved innocent until it is not.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140352">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="140386"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140386">182. </a></span><span style="color:#036">Realist </span> on September 19, 2006  6:06 AM writes...</p>
<p>Look Keith,</p>

<p>If you wern't so bloody rude, then I might be bothered to write a reasoned response, however I've come to the conclusion that it's ultimately pointless.</p>

<p>Neither myself or the press has prematurely judged him, the tests themselves have pointed the finger at him. If it wern't for his appeals, this whole thing would be over by now. If you're so concerned with pre-judging and defamation, then isn't it hypocritical to be calling the lab incompetent, crooked etc. before the appeals have been heard?</p>

<p>Regarding the science, well I've read page after page from overnight experts and their theories on this site. I ask you this - if you are so convinced of your arguments, then why are we having this conversation? Why are we having appeals? Do you not think that Landis and his lawyers might have expored all possible avenues to get him off? The last thing I heard, they were claiming that the sample numbers didn't match, rather than there being anything wrong with the tests themselves.</p>

<p>Sounds like you should give him a call, rather than ranting at me for having my own opinion. </p>

<p></p>

<p><br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140386">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="140458"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140458">183. </a></span><span style="color:#036">RLM </span> on September 19, 2006  2:42 PM writes...</p>
<p>Realist,</p>

<p>Again, I'd appreciate your comment on the lack of reporting/leaking of the Post-S17 results.  Seems to me a solid case could be made for the sample handling, Laboratory procedure, etc. if the Post-S17 results corraborated the those of S17?  I think the sense here with folks like Keith, is that the absence of the Post-S17 results be viewed with some suspicion? </p>

<p><br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140458">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="140491"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140491">184. </a></span><span style="color:#036"><a href="http://trustbut.blogspot.com" rel="nofollow">david brower</a> </span> on September 19, 2006  5:02 PM writes...</p>
<p>Auntie Beeb, at <a>"><a>">http://news.bbc.co.uk/sport2/hi/athletics/5325262.stm></a></a> quotes Michele Verroken, the former head of anti-doping at UK Sport as saying,</p>

<p><i>"The confirmation of a doping offence comes after 'A','B', and then the hearing. We have to suspend our judgement until all the facts have been identified and then been put before the independent hearing."</i></p>

<p>Proving the lab is not innocent is exactly what Landis is trying to do.</p>

<p>-dB <a href="http://trustbut.blogspot.com" rel="nofollow"><a href="http://trustbut.blogspot.com" rel="nofollow">http://trustbut.blogspot.com</a></a> for Landis news research, and comment.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140491">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="140625"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140625">185. </a></span><span style="color:#036">Realist </span> on September 20, 2006  3:05 AM writes...</p>
<p>Well on consideration I was wrong to prematurely judge Landis and should be lambasted for doing so.</p>

<p>I feel great shame too when looking back on how I prematurely judged OJ Simpson, unlike Keith and the rest of the posters on this page. I applaud you for protesting his innocence throughout the trial and it is down to people like you and his high profile lawyers, that he was rightfully cleared and is allowed to continue his life as an innocent man.</p>

<p>I'm sure too you're all working hard to get released those of Guantanamo bay, who are being held without trial. You should be applauded for your high moral standards. </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140625">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="140629"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140629">186. </a></span><span style="color:#036">Realist </span> on September 20, 2006  3:19 AM writes...</p>
<p>RLM,</p>

<p>Sorry for not getting back, as you can see I've been pre-occupied.</p>

<p>I was thinking about this. You do have a point. The only thing I could think of was a blood transfusion, which would answer a lot of questions on this page.</p>

<p>Tyler Hamilton was banned for this very practice while riding for the same team and if Operation Puerto is to be believed, this is a widespread practice.</p>

<p>Is it impossible to believe that as a last desparate throw of the dice after stage 16, that he was administered a blood transfusion? If the blood was taken while training and using testosterone as part of the training regime, could this not explain the positive test, the amazing performance on 17? It might also answer those who question the suitability of testosterone to explain his performance on 17? Perhaps it's a red herring?</p>

<p>Maybe the same procedure explains the clean tests after 17 too? I don't suppose the lab is under any obligation to report anything other than failed tests.</p>

<p>Incidentally, the Phonak team released his name, not the lab.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140629">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="140731"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140731">187. </a></span><span style="color:#036">joe </span> on September 20, 2006  1:10 PM writes...</p>
<p>Realist, the blood transfusion theory probably wouldn't work as during the practice of blood doping the plasma is removed from the blood to be transfused (i.e. to raise the concentration of red blood cells).  Also, even if they had done a sloppy job and not removed all the plasma, it's doubtful that this amount would have been enough to trigger either test, unless they had transfused all of his blood.  That's my understanding.  If I'm incorrect, someone with better information please let me know.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140731">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="140818"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140818">188. </a></span><span style="color:#036">Joe </span> on September 20, 2006  2:46 PM writes...</p>
<p>Realist and RLM,</p>

<p>PS  Testosterone clears at the blood stream at different rates for different individuals.  From what I've found, if he's on the quickest end of the spectrum, it could have been out of his system for the subsequent tests.</p>

<p>Good luck and riding.</p>

<p>Keith, calm down and don't shout.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140818">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="140838"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140838">189. </a></span><span style="color:#036">keith </span> on September 20, 2006  6:19 PM writes...</p>
<p>Realist    A blood transfusion!!! You are a genius you have solved the mystery to this whole thing. I totally applaud you with your amazing ability to reason. How did you come up with such a brilliant idea. I would really love to know what it was that drew you to this conclusion that everyone here seems to have missed. I thought that whatever that may have been in that transfusion would have taken a whole lot longer than 24 hours  to have left Mr Landis' system  and would have been detected on post stage17 tests. But you are the expert on physiology, kinetics hematology and  if you say its a transfusion by god you are right !!!! realist you are truly amazing.   I would really love to hear how you solved this !!!!</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140838">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="140872"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140872">190. </a></span><span style="color:#036">Realist </span> on September 21, 2006  2:54 AM writes...</p>
<p>Apologies everyone, I didn't realise this post was for expert bio-chemists.</p>

<p>Professor Keith, you'd better go through and veto the rest of the posts on this thread too.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140872">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="140873"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140873">191. </a></span><span style="color:#036">Realist </span> on September 21, 2006  2:57 AM writes...</p>
<p>P.S. You'd better have a go at post 16 too.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140873">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="140935"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140935">192. </a></span><span style="color:#036">Anonymous </span> on September 21, 2006  9:51 AM writes...</p>
<p>Realist: "Apologies everyone, I didn't realise this post was for expert bio-chemists"! Are you !@%$#@% kidding me?</p>

<p>Your powers of reason are only exceeded by the shrillness of your posts!</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140935">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="140936"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140936">193. </a></span><span style="color:#036">D.Lewis </span> on September 21, 2006  9:52 AM writes...</p>
<p>Realist: "Apologies everyone, I didn't realise this post was for expert bio-chemists"! Are you !@%$#@% kidding me?</p>

<p>Your powers of reason are only exceeded by the shrillness of your posts!</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#140936">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="141068"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#141068">194. </a></span><span style="color:#036">Jim Thorpe </span> on September 22, 2006  7:27 AM writes...</p>
<p>Realist,</p>

<p>You had me irritated a few weeks ago but now I chuckle w/ every one of your posts. Nobody could possibly hold such a broad range of conflicting 'logics' as you. You are an expert instigator with biting sarcasm. I tip my hat to you.</p>

<p>It amazes me how much keith is playing into your hand (unless you are keith also???)</p>

<p>If keith is actually real:</p>

<p>Mate, he's bating you and you are swallowing it each time. Brother, relax. Funny to say this, since I so vehemently disagree with Realist's *hang 'im then try 'im* stance, but you are the one who looks unreasonable here.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#141068">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="142585"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#142585">195. </a></span><span style="color:#036">Realist </span> on September 27, 2006 12:56 PM writes...</p>
<p></p>

<p><a href="http://sportsillustrated.cnn.com/2006/more/09/27/bc.eu.spt.cyc.doping.landis.clerc.ap/" rel="nofollow">http://sportsillustrated.cnn.com/2006/more/09/27/bc.eu.spt.cyc.doping.landis.clerc.ap/</a></p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#142585">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="142853"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#142853">196. </a></span><span style="color:#036">Keith </span> on September 28, 2006  9:31 AM writes...</p>
<p>Realist   <br />
Mr. Patrice Clerc is as knowledgeable as you about labs, lab tests, and lab testing. And it is just this type of reporting that creats the ugly situations that possibly innocent people have to endure. I have asked you many times to respond to the discrepancies that i see in the lab tests and to this day you have no answer  and only reply with your sarcastic superficial replys that avoid the questions and say nothing !!! Am I realist ....please god  no way</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#142853">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="142874"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#142874">197. </a></span><span style="color:#036">Realist </span> on September 28, 2006 11:11 AM writes...</p>
<p>I don't think you can call the Tour director not knowledgable. He's no doubt got a greater interest and is closer to the story than anyone on this post.</p>

<p>Isn't it time everyone gave up questioning the test's integrity and admit that this killer excuse to get Landis off the hook isn't going to materialise? We've had a huge list so far, from de-hydration to naturally high testosterone levels to lab errors. None of which have been credible enough to prevent the USADA from charging him. The last thing we hear, he's not questioning the science, but is claiming the sample numbers don't match. (Which in itself doesn't add up. How can we have an positive B test without another matching A?)</p>

<p>For 2 months now, Landis has claimed he's going to prove his innocence, however the world is still waiting as him and his highly paid team desparately look for a technicality to get him off. Is it any wonder that people like the Tour director and myself choose the results of the drug test over Landis's word?<br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#142874">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="142887"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#142887">198. </a></span><span style="color:#036">RLM </span> on September 28, 2006 12:46 PM writes...</p>
<p>Realist,</p>

<p>As much as I don't like your style, I'm going to have to agree with you re/ Landis and his bumbling of his public relations.  **However**, you must remember that there is no obligation on Landisâ€™ part to do his damage control in public, I can only imagine they are concentrating on the legal matters which take time and to which we have no insight; after all these are **what count**.  </p>

<p>Those early-on in this list and myself more recently have asked some fairly simple questions but have gotten either no answers or responses that are pretty contentious.  Whatâ€™s going on?  Most have drawn the conclusion that something is amiss (not with Landis).  Clercâ€™s recent outburst, IMO, sheds no new light on any of this and simply reflects his frustration with Landis for not bending over and taking it up the ass like his country did when Hitler over ran over them 66+ years ago.</p>

<p>Granted, Landis is a public figure and if he wants to continue to be one, itâ€™s in his best interest to spin his situation.  Does this absence mean weâ€™ve seen the last of Landis?  Hard to say.  If he is **ever** proven guilty in a court of law, Iâ€™ll be first in line with the rope.  Until then, heâ€™s innocent and still the TDF champion; albeit tainted.  Sadly, in the final analysis how can we look at any world class rider and wonder if theyâ€™re dopingâ€¦â€¦â€¦. <br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#142887">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="142891"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#142891">199. </a></span><span style="color:#036">Realist </span> on September 28, 2006  1:13 PM writes...</p>
<p>I understand your point of view, however I can't help but feel that if there was any substance in any of the questions raised on this page, that Landis's team would surely have raised them by now. The fact that the USADA has decided to proceed with charging him after being presented with whatever facts that he has presented to him, then there are no mitigating circumstances. </p>

<p>No doubt we're set for endless hearings, court cases, appeals, re-trials. A line has to be drawn under this at some point. At what point would anyone here accept he was no longer the 2006 Tour winner? I suspect in a lot of cases, never.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#142891">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="142905"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#142905">200. </a></span><span style="color:#036"><a href="http://trustbut.blogspot.com" rel="nofollow">trust but verify</a> </span> on September 28, 2006  2:24 PM writes...</p>
<p>One rumour floating around is that the ADRB couldn't get the 370 french lab report translated, so they didn't even look at the merits before passing it on.  This moots the question of whether it even really considered the merits of the defense filing.  It also shoots holes in speculation that Landis' case must be bogus because it was reccomended out for hearing.</p>

<p>A second rumour is that the lab report has got more than a few 'corrections' done with whiteout instead of the ISL protocol for strikethroughs and dated, initialled alterations.</p>

<p>There will probably be serious attempts to bury the first if true.   The accuracy of the second will probably be revealed at some point, either by  Landis releasing the report, or by talking about it at the hearing.</p>

<p>TBV <a href="http://trustbut.blogspot.com" rel="nofollow"><a href="http://trustbut.blogspot.com" rel="nofollow">http://trustbut.blogspot.com</a></a> for Landis news, research, and comment</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#142905">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="142913"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#142913">201. </a></span><span style="color:#036">RLM </span> on September 28, 2006  2:48 PM writes...</p>
<p>Realist,</p>

<p>Yup, on the surface the fact that the review board came back saying there was enough evidence to proceed with charges looks like he's cooked.  But what do they do?  They, as Landis' lawyer says are nothing more than a "rubber stamp".  Common sense tells me this review board does not do much beyond validate that the A and B samples came back with the out of bounds levels, verify that the Lab was certified, and offer an opinion that it appears that doping was performed.  They do not try the case; just review what facts are available to them, pretty much a cookbook operation I suspect.</p>

<p>I hope that this goes as Landis wants to a public trial.  Should be a learning experience for us all.  I suspect less wealthy athletes could not afford the attorneys so they get railroaded by the process and we donâ€™t get the occasion to sit on the sidelines as they trade punches.  I am certain these questions will come out, but like you am suspect as to why they have not.  Either, like I said earlier, they are concentrating on the real legal battle and less on the PR battle or this might be opening a can of worms they don't want opened.  But this does not jive with the desire for a public trial.  I suppose there will be subpoenas, expert witnesses, etc.  Should be interesting.</p>

<p>I came across this quote form Landis on a BBC site: <br />
"...I'm very happy that the science is confirming my innocence," </p>

<p>I wonder what "science" he's talking about.  </p>

<p>Stay tuned.<br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#142913">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="142923"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#142923">202. </a></span><span style="color:#036">Realist </span> on September 28, 2006  3:27 PM writes...</p>
<p>I second that.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#142923">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="143113"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#143113">203. </a></span><span style="color:#036">Realist </span> on September 29, 2006  3:02 AM writes...</p>
<p>Incidentally, what are Landis's reasons for wanting a public hearing? Is it that he feels he won't get a proper hearing from the US authorities, or does he feel he can intimidate them with the weight of public opinion on his side?</p>

<p>It's a stange American thing I guess, but it seems for a lot a people, the failed drugs test has made him a national hero rather than a national disgrace.  I find it slightly weird too, that for a lot of posters here, the continued domination of the Tour by American atheletes is seen as a case for the defence rather than something that should be treated with suspicion. As the East Germans proved in track and field in the 70s and 80s, domination of a sport by one country over a prolonged period of time should not necessarily be treated as something universally good.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#143113">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="143459"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#143459">204. </a></span><span style="color:#036">RLM </span> on September 29, 2006  2:10 PM writes...</p>
<p>T-but-V,</p>

<p>Thanks for reposting your link; comprehensive site.  I think I'll rely  on this especially as the trial commences.  Seems like you're doing a decent job in the objectivity department even though you do voice your support for Landis.  Care must be taken to not turn it into a "Landis-lover" forum lest it lose its credibility.  Thanks for the effort.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#143459">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="143738"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#143738">205. </a></span><span style="color:#036">PRM </span> on September 30, 2006  1:44 AM writes...</p>
<p>Hmm, it's interesting that here we are on a pharma blog... perhaps we should all spend a little more time with our Bioassay Development groups. You know, CVs, Z's, robustness, outliers, repeat measurements... </p>

<p>I admit it, I got sucked in to the thread and read to the bottom looking in vain for some real basis to form an opinion on. </p>

<p>On the bright side I did click on the ad and learn about the new HPV test, which it says I should get because of the notorious unreliability of pap smears. Pap smears would be a good example of a validated clinical lab test.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#143738">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="144443"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#144443">206. </a></span><span style="color:#036">Keith </span> on October  2, 2006  2:27 PM writes...</p>
<p>Realist <br />
The statement was Mr. Patrice Clerc is unknowledgeable about Labs and lab testing and lab results. You twist everything to suit yourself. Mr Patrice Clerc should be fired from his post for making such comments before a trial has taken place. Declaring someone guilty before all the facts are presented and a person has the right to defend themselves is totally irresponsible especially for someone in his position.  He shows no regard for due process and fairness  for making premature judgment especially when it involves subjects he has no expertise on. He shows no regards for someones right to be viewed as innnocent untill proven quilty. Landis' lawyers know exactly what they are doing in trying to provide him the fairest trial and to protect him from people like you and Mr. Patrice Clerc.   Mr. Patrice Clerc should resign from his post!!!!!  </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#144443">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="144514"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#144514">207. </a></span><span style="color:#036">Keith </span> on October  3, 2006 12:31 AM writes...</p>
<p>Realist<br />
Also ,as you have stated, no one is denying the labs tests or the science that is there. As you say "what science?". What we are questioning, (which you on countless occasions ignore because in your mind you read High T/E ratio and automatically assume High testoterone, drug user, cheat, guilt, hang,) are what the results are saying. You read High T/E ratio .The reality is that you ignore all the other results given by the lab because if you did it would minimize your desire to convict and sentence. I ask you Mr Reality to look at the results and respond. But you never do!!!! The lab reported a High t/e ratio. They reported it to be 11:1 which is substantially higher than the 1:1 and as you say is due to Mr landis taking exogenous testosterone. Seems like he would have had to take a pretty good dose to get it that high. I also accept the next test a very sophisticated highly accurate highly sensitive instrument that detects and measures this exogenous test. However out of all this exogenous testoterone that Mr Landis supposedly has taken to get a very high T/E ratio the result of this highly accurate highly sensitive test shows "trace " amounts. Meaning it can only detect trace amounts from this high dose exogenous substance.  How is this so Mr. Reality? The science is there (which you totaly ignore in your attempt to convict and hang) Have you thought of this? Seems most people here have.I would love to hear your explanation for the differences found in the tests. also mr landis t levels were never reported to be high by the lab and as you say they are only responsible for reporting those results that show suspicion meaning his Testoterone levels were normal!!! Would love to hear your explanation for all this ... no one is denying the tests integrity as you state  Its just that most people look at all the information and question while others focus only on that which will serve their purpose. And as you have on many occasions made  pretty clear. Convict and hang !!!!  </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#144514">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="144531"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#144531">208. </a></span><span style="color:#036">Realist </span> on October  3, 2006  2:59 AM writes...</p>
<p>I doubt any of the would be scientists on this page have the answers to the questions posed. I doubt few people worldwide could tell you with certainty. I know one thing though, Landis's team do and they haven't put forward any of them as proof of his innocence. I think that's all that needs to be said.</p>

<p>This isn't a vendetta against Landis by the way. I'm equally appalled that it looks like Basso and Ulrich are going to get off, when it's clear that they cheated. As with Landis, they don't have the dignity to say it's a fair cop. </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#144531">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="144584"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#144584">209. </a></span><span style="color:#036">Keith </span> on October  3, 2006  9:57 AM writes...</p>
<p>Realist  Your a farce!!!!!</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#144584">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="144607"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#144607">210. </a></span><span style="color:#036">Realist </span> on October  3, 2006 10:38 AM writes...</p>
<p>I can't win really can I?</p>

<p>P.S. It's you're.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#144607">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="144642"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#144642">211. </a></span><span style="color:#036">Keith </span> on October  3, 2006 12:33 PM writes...</p>
<p>Awhhhh Poor Realist  . your quick to judge and hang and what goes around will come around for you</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#144642">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="144832"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#144832">212. </a></span><span style="color:#036">Jim Thorpe </span> on October  3, 2006  9:02 PM writes...</p>
<p>Realist,</p>

<p>"I doubt few people worldwide could tell you with certainty."</p>

<p>I'll take it as red that what you mean here is that you doubt MANY people have the answers. I'll go along with you on that an reserve judgement until after those enlightened few have had their moment to talk.</p>

<p>As sad as people who worship heroes are, so to are the people who spitefully need to bring heroes down. Either way displays an alarming level of individual insecurity.</p>

<p>You have libelled nearly all of the top tour cyclists. You are probably right in your assertions that they all dope, but don't be so quick to judge their character. Do you think lack of dope is the only thing that robbed you of the chance at a pro-cyclist career?</p>

<p>Almost all these guys have humble origins. Top-level endurance sport will always require a balance of natural ability, hard work, and supplementation. Because of the grey area surrounding appropriate supplementation, it will always require athletes to push it as far as they can get away with.</p>

<p>Faced with a choice of not using performance enhancers and driving a delivery truck or using them and becoming a world-famous athlete, it's a no brainer. Talk about the negative health side effects of dope all you like, then compare them to the negative side effects of eating bacon for breakfast and sitting on your lard arse behind the wheel of a delivery truck all day. Again, no brainer.</p>

<p>If I had the natural ability and therefore choice to be a top cyclist and spend my life doing something I love day in and day out until retirement at the ripe old age of 35, I'd sure as hell take the dope. My guess is, you would too. Moreover, we the fans, want to see super-humans competing -- people much better at it than us amateurs -- we are as much at fault as are they.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#144832">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="144931"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#144931">213. </a></span><span style="color:#036">Realist </span> on October  4, 2006  2:57 AM writes...</p>
<p>Well you've got a different outlook to me.</p>

<p>I think Bradley Wiggins sums it up best :</p>

<p><a href="http://observer.guardian.co.uk/sport/story/0,,1879637,00.html" rel="nofollow">http://observer.guardian.co.uk/sport/story/0,,1879637,00.html</a></p>

<p>Keith, YOU'RE an idiot.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#144931">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="145009"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#145009">214. </a></span><span style="color:#036">Jim Thorpe </span> on October  4, 2006  8:18 AM writes...</p>
<p>Mr. Wiggins Is likely lying through his teeth, but even if not:</p>

<p>It is hardly fair for one to be judgmental when competing against guys riding their way up from the working class when he is financially able to train when/how he likes (with low-atmospheric-pressure-gyms to give him a dangerous, yet legal, EPO boost, and having top coaches, sports-medicine specialists and nutritionists/dieticians preparing his meals etc.)</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#145009">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="145012"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#145012">215. </a></span><span style="color:#036">Realist </span> on October  4, 2006  8:43 AM writes...</p>
<p>Granted, yet it is defined what is legal and what isn't. I'm sure too that it's possible to make it to the professional ranks from humble beginnings if you've got the talent, as the significant number of Columbians etc. will testify. </p>

<p>If there is inequality in the pro ranks, this seems to be the quality of the doping available if you have the cash. As Filippo Simeoni once said, 'if there's a European riding against an American, the American will win'.</p>

<p>Call me an idealist, however I'd like to see the best rider rather than the rider with the best medical team win the tour for once. </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#145012">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="145359"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#145359">216. </a></span><span style="color:#036">Jim Thorpe </span> on October  5, 2006  3:00 AM writes...</p>
<p>"If there is inequality in the pro ranks, this seems to be the quality of the doping available if you have the cash."</p>

<p>This just supports my point... As long as there is a prohibition, the dope will come from nefarious sources and the richest will always out perform.</p>

<p>Legalise it and the rich will no longer have an advantage -- they won't need to buy designer, undetectable stuff that the poor can't afford because there will be no need to hide.</p>

<p>With the playing field levelled, the best rider will win, rather than the richest.</p>

<p>Continue to test, though, and make the results of all blood tests and urine tests openly available and the sport will clean itself -- public opinion directs sponsorship deals and money is the bottom line for the guys at the top. </p>

<p>As for Americans dominating, they don't. Three have won, two of them just happened to be particularly good and the jury is still out on the third. The Americans on the whole hardly follow the sport and spend much less money on it than Europeans.</p>

<p>I don't think we (I assume that you are a Brit) should be fighting to bring the yellow jersey back to Europe by prematurely stripping it from someone across the pond (who *might* yet prove his innocence). It just makes us look like poor losers. We'd be better to let him keep the jersey enveloped in a cloud of suspicion and take it from him next year through sheer cycling prowess.</p>

<p>I'd rather come in 2nd than take 1st by default. Moreover, none of us actually rode the race so all this nationalistic twaddle is really pathetic. None has the right to feel proud (or otherwise) of race results than those who were directly involved. One doesn't win by national association, so it doesn't matter where the winner's from.</p>

<p>I live/race in Japan. When it comes down to one of my Japanese friends and a Westerner in a race, I support my friend, the guy I know, the one I am associated with -- not the one who shares my passport.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#145359">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="145360"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#145360">217. </a></span><span style="color:#036">Realist </span> on October  5, 2006  3:19 AM writes...</p>
<p>I'm not really worried about whether an American wins or not. I was delighted when Lemond won, less so when Riis did. </p>

<p>The best way I can sum it up I suppose is this. The outcome of all sports are to varying degrees dependant on training, tactics, natural ability and luck. It's these very things that for me make cycle racing so exciting. There will always be someone who's better than the rest, take Tiger Woods. However Tiger doesn't win every time. As soon as we introduce drugs, there is no uncertainty. In seven years, Armstrong never had a bad day. From the first prologue, the result was never in doubt. It was the same in this years Giro.</p>

<p>At the end of the day, what's the fun in watching that?</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#145360">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="145667"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#145667">218. </a></span><span style="color:#036">Jim Thorpe </span> on October  6, 2006  7:07 AM writes...</p>
<p>"As soon as we introduce drugs, there is no uncertainty."</p>

<p>This is true only if you believe that it's just the winner who is doping (which we all know is bunk). As I said before, legalise, regulate it and the playing field will be level. Drugs will be irrelevant.</p>

<p>As I said, the jury's still out as far as I'm concerned but this article is quite informative and has me swaying back toward the side of the fence on which Landis was clean on the day:</p>

<p><a href="http://rant-your-head-off.com/WordPress/?p=53" rel="nofollow">http://rant-your-head-off.com/WordPress/?p=53</a></p>

<p>"Now here’s where it gets tricky for the Landis case. The reference hormones used in the WADA protocols are materials created by the breakdown of cortisone in the body. If you recall, Floyd Landis had a therapeutic use exemption (TUE) for cortisone due to his hip condition."</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#145667">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="145694"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#145694">219. </a></span><span style="color:#036">Realist </span> on October  6, 2006 11:58 AM writes...</p>
<p>Well no doubt they'll find something to get him off, I'm sure of that. </p>

<p>It still doesn't explain why he tested on this stage only and never in his career. You'd think if this was a viable reason, he'd be testing positive all the time.<br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#145694">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="145769"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#145769">220. </a></span><span style="color:#036">Jim Thorpe </span> on October  6, 2006  8:50 PM writes...</p>
<p>Realist,</p>

<p>Sometimes your pigheadedness is mind-bending. You might choose a career as one of Douglas Adams' electric monks considering your credulity and insistent faith in your beliefs -- even when the evidence suggests otherwise.  Such fatal lack of scepticism is also in high demand in the clergy. It takes a certain conscious effort that most can not muster to be able to stare into a room full of fossil evidence and say: "No, not true. Earth is 5,000 years old, and woman is made of a rib. Now stop asking questions, The lab works in ways too complicated and mysterious for us to comprehend. It is infallible!"</p>

<p>Though slightly higher up the social, evolutionary scale, you clearly share a lot in common with Keith. It is really sad, the dearth of scientific open-mindedness in this day and age.</p>

<p>"Well no doubt they'll find something to get him off, I'm sure of that.</p>

<p>It still doesn't explain why he tested on this stage only and never in his career. You'd think if this was a viable reason, he'd be testing positive all the time."</p>

<p>You pooh-poohed others who asked: *If he was using the substance, why did it show up only on that day?* now you're advancing their same argument. What I say is that we ought keep an open mind to all logical/plausable possibilities -- and human error is certainly one (imagine lab techs as pig-headed as you and it's not much of a stretch they would try to cover up their mistake). Any top rider would have to be paradoxically stupid to use T as a one-off fix during the race (ineffectiveness and detect-ability:knowing he'd be tested). Yet you think it is more likely than a simple mistake/mixup? So much for giving people the benefit of the doubt. Clinging fervently to the belief that a top rider would be so phenomenally stupid surely elevates one's self esteem though it is a selfish, ugly indulgence.</p>

<p>Again, we aren't talking about EPO, of which guilt is a foregone conclusion to any rider testing positive.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#145769">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="145770"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#145770">221. </a></span><span style="color:#036">Jim Thorpe </span> on October  6, 2006  8:58 PM writes...</p>
<p>We, the fans should organise a non-profit organisation that lets riders voluntarily deposit a sample of their urine and/or blood after each stage -- to be stored as an impartial backup which can be independently and openly verified incase of future disputes.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#145770">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="145829"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#145829">222. </a></span><span style="color:#036">Realist </span> on October  7, 2006  4:44 AM writes...</p>
<p>Well I'm sorry I don't agree with you, but none of the 'evidence' which you or anyone else on this page is particularly convincing. You can't just repeat what you've read somewhere about cortisone and expect me to magically proclaim that he's innocent.</p>

<p>It's not being pigheaded that I don't agree with you when that's the best you can come up with!?</p>

<p>So let's say this cortisone thing is real. You've now got to explain how this produces his failed test by the large margin he failed by. If too, that is the reason, well it's his or his teams fault. 'I screwed up, so you can discount that test', isn't valid is it?</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#145829">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="145836"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#145836">223. </a></span><span style="color:#036">Realist </span> on October  7, 2006  5:56 AM writes...</p>
<p>At the end of the day, the only fact here is that he's failed the test. There were testosterone levels outside of the permitted range. I've read the article, most of it is based on rumor and as I've said many times, none of this has yet been put forward by Landis himself as proof of innocence. </p>

<p>There are two ways to look at this. One requiring 20 paragraphs of explanation based on what might have been, the other is two words. He cheated. If in the absence of any proof to the contrary believing the second makes me pigheaded, then I'm pigheaded. If and when Landis himself presents this as an argument and I dismiss it, then I can be called pigheaded. </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#145836">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="145907"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#145907">224. </a></span><span style="color:#036">Realist </span> on October  7, 2006  4:27 PM writes...</p>
<p>I'd like to keep this civil, but I think the Keith analogys are a bit rich from someone who's taken to some sort of character assasination as I don't agree with them. It's slightly more eloquently put, but essentially it's the same.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#145907">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="145976"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#145976">225. </a></span><span style="color:#036">Jim Thorpe </span> on October  8, 2006  4:44 AM writes...</p>
<p>"but none of the 'evidence' which you or anyone else on this page is particularly convincing. You can't just repeat what you've read somewhere about cortisone and expect me to magically proclaim that he's innocent."</p>

<p>I don't expect you to accept that he's innocent -- I don't. The *correct* response when reading something like that is: *Wow, if that's true it explains a lot. Let's wait and see if it is true.*</p>

<p>"If and when Landis himself presents this as an argument and I dismiss it, then I can be called pigheaded."</p>

<p>That's all I expect of you, to reserve your judgement until all the data has been collected and analysed by *real* experts.</p>

<p>"You've now got to explain how this produces his failed test by the large margin he failed by. If too, that is the reason, well it's his or his teams fault. "</p>

<p>You seem to think of it as a literal test, it is not, it is a collection and analysis of data representing urine contents. The substances present can be made naturally or artificially. Probabilities are then considered to make a determination as to weather the athlete likely used a banned substance. The hearing then gives the athlete a chance to explain how abnormal situations could have caused abnormal proportions and or levels. It is not an exact science but a judgement as to probabilities. Landis didn't "fail" anything the way one fails a narcotics test -- and it certainly was NOT by a large margin (though the 11/1 thing might look enormous to the uninformed).</p>

<p>As I've stated numerous times, I'm not at all convinced that any of them are innocent of illegal performance enhancing -- but we ought wait until the hearing to draw conclusions. A sceptic says "let's look at the evidence." A cynic says "Well no doubt they'll find something to get him off, I'm sure of that."</p>

<p>As you see, I am a sceptic, and you are a cynic.</p>

<p>"...from someone who's taken to some sort of character assasination as I don't agree with them."</p>

<p>I enjoy a witty banter as, I can see, do you. If you'd like, I can copy/paste many of the things you've previously posted to support this point. If you enjoy targeting others but are offended when it is directed at you, then I think you should evaluate that behaviour pattern. You seem to bea person who enjoys winding people up by discounting their points off of hand and then belittling them. However maybe you only like banter with people like Keith against whom you can clearly win rather than those who can give the snide remarks back equally well. You seem to feel I've crossed some sort of line though, so I apologise for hurting your feelings. </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#145976">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="146038"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146038">226. </a></span><span style="color:#036">Realist </span> on October  8, 2006  1:38 PM writes...</p>
<p>You've got quite an ego.</p>

<p>The *correct* response when reading something like that is: *Wow, if that's true it explains a lot. Let's wait and see if it is true.*</p>

<p>Eventually, it'll be decided whether I was wrong in thinking the most logical explanation for Landis's failed test was doping. It won't be by anyone on this page though. In the meantime, I think I wasted enough time on this.</p>

<p>BTW, this isn't about winding people up or winning Sigmund.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146038">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="146069"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146069">227. </a></span><span style="color:#036">keith </span> on October  8, 2006  3:58 PM writes...</p>
<p>Please J Thorpe  You are so wishy washy  you apologise for what you say!!! Mister realist calls me an idiot because he has no answers to the questions that I have asked him. Not because there are none but because of his  inability to do so !!!!Yet he makes judgent ......  based on What ??????  I have asked him this many many times and he has no answer..... WHO IS THE IDIOT!!!!!!!!!!! If there are no answers how can you judge !!!!!!!Please save me the remarks.....you yourselve feel there are questions and doubt to accuse. YOU seem  to feel a dislike to those who do yet you apologise to those people who try to Judge   Please have a back bone!!!!!!</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146069">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="146191"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146191">228. </a></span><span style="color:#036">Jim Thorpe </span> on October  8, 2006  8:08 PM writes...</p>
<p>Keith,</p>

<p>I apologised for hurting his feelings. I had thought that while we strongly disagreed, we were intellectual equals. It seems however that he preferred to dish it out but was threatened and offended to take it in. I actually didn't wish to hurt his fragile feelings, however.</p>

<p>Now as for you, I think you are either a teenager or you have serious anger-management issues. The "!" should be removed from your keyboard. Nobody listens to a person who is screaming. It detracts from your, otherwise valid, questions and points.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146191">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="146214"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146214">229. </a></span><span style="color:#036">Jim Thorpe </span> on October  8, 2006 10:27 PM writes...</p>
<p>Realist,</p>

<p>It's "Dr. Sigmund" to you.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146214">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="146226"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146226">230. </a></span><span style="color:#036">Jim Thorpe </span> on October  9, 2006 12:09 AM writes...</p>
<p>Realist,</p>

<p>"Eventually, it'll be decided whether I was wrong in thinking the most logical explanation for Landis's failed test was doping."</p>

<p>You wouldn't be wrong to think that is the simplest -- and most likely -- explanation. To that I agree. You would, however be premature to draw the conclusion that it is, in fact, what happened. Whereas you may require simple explanations, I require the truth. That is why I will reserve judgement and wait for the unaffiliated experts to weigh in -- that is what an empirically-minded person does. The original analysis is not yet public and an English translation of the analysis is not even finished.</p>

<p>"It won't be by anyone on this page though. In the meantime, I think I wasted enough time on this."</p>

<p>Yes, I too think you have wasted enough time. I suggest it return to a discussion of the results: understanding, analysing, and hypothetically explaining the cause.</p>

<p>Do not think this board is going unnoticed. Theories posted here are being read and considered by those involved.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146226">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="146258"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146258">231. </a></span><span style="color:#036">Realist </span> on October  9, 2006  3:02 AM writes...</p>
<p>Spare me.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146258">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="146319"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146319">232. </a></span><span style="color:#036">MK </span> on October  9, 2006  5:10 AM writes...</p>
<p>'Sir Realist',</p>

<p>Spare you?</p>

<p>Nothing forces you to visit this forum. You haven't made a constructive contribution but you attack people who do.</p>

<p>At least twice you said you're finished with this board but you just keep coming back to get the last word. Do you expect us to stop posting once you've said you're done, like you can decide for us that the discussion's over, Landis is guilty because you say so, and we all have to stop posting?</p>

<p>Cute.</p>

<p>You, Jim and Keith are the only ones still posting because everyone got sick of you insulting them. Keith is too enraged to stop and Jim fancies himself to be some kind of vigilante.</p>

<p>Jim, back off. You're just feeding his need for attention. Keith, take a pill. Realist, make good on your promise and skedaddle. shoo, shoo.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146319">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="146326"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146326">233. </a></span><span style="color:#036">Realist </span> on October  9, 2006  6:30 AM writes...</p>
<p>I quote :</p>

<p>As one of the key points of his defense, Landis will argue that the analysis work performed by French Anti-Doping laboratory in Châtenay-Malabry was sloppy. While he did not contest that the positive sample was indeed his own, Landis will emphasize that officials made mistakes in filling out the testing forms with his urine sample number. The incorrect number was covered over with correction fluid, and Landis' number was overwritten, while WADA testing protocol actually requires that any corrections should be done "with a single line through and the change should be initialed and dated by the individual making the change." That was not done on Landis' test form.</p>

<p>Landis will also argue that his positive results from the carbon isotope test are incorrect, because the data indicated that he was out of acceptable range in only one of four testosterone breakdown products examined. All four must be abnormal for a test to be considered positive for an illegal testosterone-to-epitestosterone ratio, he asserted. </p>

<p>No mention of isotopes, cortisone or amounts of time in his system here. No it's the 'yes, it's my sample, but they used liquid paper rather than biro' approach. </p>

<p>Desperate....</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146326">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="146328"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146328">234. </a></span><span style="color:#036">Realist </span> on October  9, 2006  6:41 AM writes...</p>
<p>MK, it'd genuinely be my pleasure. </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146328">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="146348"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146348">235. </a></span><span style="color:#036">Jim Thorpe </span> on October  9, 2006  7:12 AM writes...</p>
<p>Realist,</p>

<p>Oh, you back so soon? I figured you were man enough to stay away for at least a day this time (let me pre-emptively apologise to your fragile feelings). </p>

<p>Generally when quoting, it is appropriate to cite from where the quote comes (such as with a link) and to use quotation marks to let the reader know where the quote starts and stops.</p>

<p>I take it the "Desperate..." part is yours as is "No it's the 'yes, it's my sample, but they used liquid paper rather than biro' approach."</p>

<p>funny you don't comment on the second, much stronger argument that you posted. Rather than actually trying to find out more details about it and whether or not it is an accurate point, you ignore it completely and let us all know how "desperate" his defence is. Typical for you.</p>

<p>Your opinions on the matter are as meaningless as everyone else's, so how about laying off and just bringing substance to the board if you've decided to stick around.</p>

<p><a href="http://trustbut.blogspot.com/index.html" rel="nofollow"><a href="http://trustbut.blogspot.com/index.html" rel="nofollow">http://trustbut.blogspot.com/index.html</a></a> has a lot more info re the Landis strategy. Landis sent them copies of the official FAX from the UC about the B sample results.</p>

<p>It is clear to see why Landis might feel they are out to get him. They punctuate like Keith on the fax as if to be ecstatic to have determined his test failed.</p>

<p>Landis' defence strategy is actually quite brilliant. He is releasing publicly (via the web) all of the documents he received (currently awaiting the completion of a translation of the unnecessarily long, intentionally cryptic, document they finally presented to him). They will then send us investigative bloggers to work and we will help the team filter through it all and figure out 1. if the "positive" conclusion was correct given the tested levels in his samples, and 2. (if so) why that would have occurred.</p>

<p>Sounds to me that he's pretty confident he has nothing to hide (else he wouldn't post it all on the web) and wants to enlist the cross-diciplanary help of all the sport-enthusiast cycling fans in the world.</p>

<p>Make no mistake, some very smart scientists are reading these boards as is the Landis defence team so lets all do our part in reading through the documents and posting questions/explanations/theories.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146348">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="146370"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146370">236. </a></span><span style="color:#036">MK </span> on October  9, 2006  7:56 AM writes...</p>
<p>Then, by all means Realist, go "pleasure" yourself.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146370">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="146553"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146553">237. </a></span><span style="color:#036">Jim Thorpe </span> on October  9, 2006  6:26 PM writes...</p>
<p>Whiteout isn't really part of his defence -- just one example of many where they believe lab cut corners and/or didn't follow the rules.</p>

<p>Landis:</p>

<p>"...please don't focus too much on the white out (although we have been provided copies and cannot rub it off). The real issues are much more substantial and yes I do regret saying anything at all in the begining of this. In my defense, I did not come up with the alcohol argument, I was telling everyone what I had done the night before for no other reason than to give an interview so they would leave my friends and family alone. It's hard for anyone, who didn't see it, to understand the magnitude of what went on but most certainly the alcohol defence was created later by someone else."</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146553">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="146558"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146558">238. </a></span><span style="color:#036">keith </span> on October  9, 2006  7:00 PM writes...</p>
<p>Jim  "Eventually, it'll be decided whether I was wrong in thinking the most logical explanation for Landis's failed test was doping."You wouldn't be wrong to think that is the simplest -- and most likely -- explanation. To that I agree. You would, however be premature to draw the conclusion that it is, in fact, what happened."  You wouldnt be wrong to think he doped but lets not say it prematurly.?????? Otherwise the people on the other side of the pond will think we are sore losers. "I don't think we (I assume that you are a Brit) should be fighting to bring the yellow jersey back to Europe by prematurely stripping it from someone across the pond (who *might* yet prove his innocence). It just makes us look like poor losers." All the riders are dopers but lets not judge them..." I'm not at all convinced that any of them are innocent of illegal performance enhancing -- but we ought wait until the hearing to draw conclusions." Just what is it that you beleive. Intellectually the same as realist perhaps . Intellectual wannabe ..yes. You try to create this impartial image of yourself but  repeatedly you show your narrow mindedness only to mix it with  your  wishy washy attempt to be fair. you and Mr reality say this has nothing to do with an american winning yet you are the only two  to bring it up. Lets not appear to judge to the people accross the pond by calling everyone in bicycling dopers or we'll appear to be sore losers. You have done both judged and  appear to be sore losers. Referring to the quote again  the intellect ( as you seem to refer to yourself) would never have thought that the only logical explanation to the tests would have been to think  that he was a doper as you agree with.  Save your condescending  remarks... I will show my emotion as i wish.   The lab tests are there with the results make your own decision. But you will ride that fence  as the pretentious intellect only to fall off on the side that favors the  courts desicion .              </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146558">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="146575"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146575">239. </a></span><span style="color:#036">Jim Thorpe </span> on October  9, 2006  8:45 PM writes...</p>
<p>"You wouldnt be wrong to think he doped but lets not say it prematurly.??????"</p>

<p>Reread what I wrote. I agree that it is the *simplest* explanation. I then go on to say that Mr. Realist needs simple answers, I do not. I want the truth. For the truth I am willing to wait.</p>

<p>"But you will ride that fence as the pretentious intellect only to fall off on the side that favors the courts desicion ."</p>

<p>And, yes, once the truth is reasonably well determined, I will go along with it. The truth is not for me to decide based on what I wish to be. I will not later claim to have believed the outcome all along. Rather, I will be proud of myself for reserving judgement and keeping my emotions from overpowering reason.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146575">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="146717"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146717">240. </a></span><span style="color:#036">Anonymous </span> on October 10, 2006  1:34 PM writes...</p>
<p>As an explanation for Landis's failed test was doping "You wouldn't be wrong to think that is the simplest -- and most likely -- explanation." "We know that they all unfairly dope"You are probably right in your assertions that they all dope, but don't be so quick to judge their character" the best yet  "Again, it's not that I believe he's 'innocent' -- none of them are" <br />
Not judgemental   what ever Jim   </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146717">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="146718"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146718">241. </a></span><span style="color:#036">Anonymous </span> on October 10, 2006  1:48 PM writes...</p>
<p>Jim those are your quotes ...</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146718">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="146784"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146784">242. </a></span><span style="color:#036">Jim Thorpe </span> on October 10, 2006  9:35 PM writes...</p>
<p>Keith,</p>

<p>You're right that I am judgemental. I suspect the sport is swimming in drugs (and most other sports). That said, I don't think you can fault the individual athlete for conforming to the standards of the game.</p>

<p>I also suspect that the athletes go through detox regiments before major races in order to pee clean. Then during the race I think the most they do is blood dope (which can't be tested for).</p>

<p>So, as to whether or not Landis was using drugs during the race I will reserve judgement. Like everyone else here, I am very disturbed to believe he would have chosen to take testosterone as a one-off fix during the race knowing he'd be tested. Because of that illogical contradiction, it seems equally likely that the lab was in error and Landis was clean on the day.</p>

<p>What I suspect of Landis' chances of innocence is unimportant, however. Let's wait till Thursday (when the documents become available) and sift through them with a fine-tooth comb. Then let's use the forum to discuss the actual pharmacology of what we find and see if we can get to the bottom of it.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146784">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="146790"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146790">243. </a></span><span style="color:#036">Anonymous </span> on October 10, 2006 10:07 PM writes...</p>
<p>Personally, you have contradicted yourself so many times that it is hard to believe much of what you say. One day one thing and something else the next and something else when talking to your fellow Brit.  You are quite the talker.And after reading  your responses it often seems that you yourself dont know what you beleive in. I also find it pretty sad that you allow someone else or something else to tell you  what the truth is. Am I suppose to accept what some French lab reports or what  Mr Patice Clerc says<br />
or ect ect as being the truth.  The lab results are there the information for each is readily available as well as informatin about the drug make your own desicion on what the truth is.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146790">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="146864"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146864">244. </a></span><span style="color:#036">Jim Thorpe </span> on October 11, 2006  9:30 AM writes...</p>
<p>"Anonymous," "Realist," "Keith," whatever your handle is.</p>

<p>I'm sorry  if my points seem to be contradictory. To some degree they may be. There is a lot about this case that is contradictory -- and yet appears to be fact.</p>

<p>1. Landis maintains his innocence.<br />
2. The sport commissioners maintain his guilt.<br />
3. There is little logical reason for Landis to have done what he is accused of.<br />
4. Landis' test results came back abnormal, though by no means a slam dunk or smoking bullet.<br />
5. Many, many pro athletes dope and officials and the public largely turn a blind eye.<br />
6. This case is in regards to whether Landis doped on that day during the tour -- not whether he or any other cyclists dope in general (which I suspect they do)<br />
7. Unless certain currently-banned substances are legalised and regulated, we will continue to face athletes having to defend themselves every time their urine contents fall outside certain levels deemed to be normal for all people under all situations.<br />
8. It is unscientific to assume all people will display the same levels in their urine. There are numerous medical conditions as well as physiological differences which effect those levels. (my father had an illness which caused his body to suddenly shut off production of certain hormones and he must now use certain hormone creams to treat it)<br />
9. Landis had at least two complicated hormonal imbalances which the tour officials knew of and authorised exemptions for. It is not unrealistic to expect Cortisone mixed with thyroid, mixed with weeks of race-paced, day-long rides, mixed with sleep deprivation, mixed with alcohol, that his urine-content levels might have been slightly abnormal -- and his tests were just slightly abnormal.<br />
10. Conspiracies in sport are not common, BUT<br />
11. Conspiracies in sport DO happen. (Look at olympic judging, Jim Thorpe, those baseball players "Say it ain't so, Joe." etc.)</p>

<p>I do think it is the *simplest* explanation that he used dope. That doesn't mean it's what happened -- or even that it's what I believe happened. What I *believe* is irrelevant, though. I do hope, however, that he is given a fair shake and is allowed to defend himself to the extent of his abilities before people decide he is guilty.</p>

<p>I also said I will wait until the truth has been reasonably well determined by experts. That is not to say I will accept the verdict. It most likely means I will believe what the millions of chemists, biologists, doctors, and pharmacists scrutinising the case and sharing information over the net decide.</p>

<p>Though OJ was judged innocent, it is generally considered by law enforcement and the lawyers involved (I heard that even Johnny Cochran rolled over on OJ before he died) that he is guilty. I suspect that he is.</p>

<p>Likewise, should Landis be found guilty, but the vast majority of scientists in the world determine he is innocent, I will not consider him guilty. I will believe that, like Jim Thorpe (the man who I modelled my user name on), he got shafted by the officials. </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#146864">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="147092"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#147092">245. </a></span><span style="color:#036">Curious </span> on October 12, 2006  7:02 AM writes...</p>
<p>Often this site seems to have some quality posts by people who seem to know the chemistry behind these tests. Now that the data has been released (or at least some of it) I am looking forward to some quality opinions about it by some dispassionate observers. I don't have the chemistry background so I'd like some genuine help and not the "noise" of emotional posters. </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#147092">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="147093"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#147093">246. </a></span><span style="color:#036">Curious </span> on October 12, 2006  7:04 AM writes...</p>
<p>Often this site seems to have some quality posts by people who seem to know the chemistry behind these tests. Now that the data has been released (or at least some of it) I am looking forward to some quality opinions about it by some dispassionate observers. I don't have the chemistry background so I'd like some genuine help and not the "noise" of emotional posters. </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#147093">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="147982"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#147982">247. </a></span><span style="color:#036">Realist </span> on October 17, 2006  2:50 AM writes...</p>
<p>Now I know it makes me less of a man for posting here, but just to say a big well done to those of you who were so precious about this blog that you attempted to police it. It looks like you've killed it off all together. Good work.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#147982">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="148057"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#148057">248. </a></span><span style="color:#036"><a href="http://trustbut.blogspot.com" rel="nofollow">trust but verify</a> </span> on October 17, 2006  2:42 PM writes...</p>
<p>The useful discussion of chemistry and test results is on the daily peloton forum, at </p>

<p><a href="http://www.dailypelotonforums.com/main/index.php?showforum=19" rel="nofollow"><a href="http://www.dailypelotonforums.com/main/index.php?showforum=19" rel="nofollow">http://www.dailypelotonforums.com/main/index.php?showforum=19</a></a></p>

<p>This is where Landis was personally posting and answering questions for about a week, which crystalized the formation of a useful community.</p>

<p>There are plenty of people there who are skeptical of his claims, but they are looking at the data rationally rather then foaming at the mouth about it.</p>

<p>I continue to maintain my news roundup and link farm at</p>

<p><a href="http://trustbut.blogspot.com" rel="nofollow"><a href="http://trustbut.blogspot.com" rel="nofollow">http://trustbut.blogspot.com</a></a></p>

<p>If anyone killed this discussion, it was Mr. Rational.</p>

<p>TBV</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#148057">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="148110"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#148110">249. </a></span><span style="color:#036">Jim Thorpe </span> on October 17, 2006  9:51 PM writes...</p>
<p>Nope, not dead. We were just taking a breather to read through and digest the documents and then wait for the analysis to begin to trickle in.</p>

<p>I've read several articles now from scientists who have sorted through the data.</p>

<p>The prevailing opinion so far seems to be that Landis *should* get off (regardless of our hunches as to whether or not he -- or any other athlete -- sometimes cheats).</p>

<p>This article, quite fairly, gives a detailed explanation.</p>

<p><a href="http://now-thats-amateur.blogspot.com/2006/10/floyd-landis-evidence.html" rel="nofollow"><a href="http://now-thats-amateur.blogspot.com/2006/10/floyd-landis-evidence.html" rel="nofollow">http://now-thats-amateur.blogspot.com/2006/10/floyd-landis-evidence.html</a></a></p>

<p>The main points have nothing to do with whiteout, but rather with the fact that the B sample exceeds the contamination threshold and therefore can not legally be used as verification (the contaminants can alter hormone levels -- and in this case had 10 days to do so)</p>

<p>As for the positive result -- several vials were tested, several tests were run, and only one test came back positive outside of the margin of error. Moreover, Landis' T level WAS in fact low, not high. That is indeed very important if he is suspected of taking T.</p>

<p>Since there is no documented benefit of a one-off dose of T for a cyclist (and presumably a cycling champion would know this) and because his tests on all other days was clean -- Occam's razor dictates the most logical conclusion here is that the one test suggesting positive was in error and the several confirming negative were the accurate ones.</p>

<p>It is a totally irrational stretch to believe several tests confirming negative would all have been in error and that the one test suggesting positive would be the only test that was accurate. If that were indeed the case it would speak very poorly as to the validity of these sorts of tests.</p>

<p>Given the current available data, the test was negative according to their own rules -- rules set up to protect the athletes from undeserved allegations in these very situations. It is a travesty that this false positive was ever released.</p>

<p>I'm sure that if it were not implicating a winning athlete, it never would have been released. The most logical explanation given the newly available information may well be that this was all just a ploy to get free publicity for the tour -- never mind that it slanders a champion's reputation. But, hey, any publicity is good publicity, right?</p>

<p>Disclaimer: This conclusion is based on the data that has thus far been released. It is certainly possible they are keeping some secret ace in the hole -- though it's hard to imagine why they would not have released it yet.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#148110">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="148322"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#148322">250. </a></span><span style="color:#036">Jim Thorpe </span> on October 18, 2006  6:12 PM writes...</p>
<p>Trust But,</p>

<p>I love your site. I check in daily. You're doing a fantastic job and keeping it very fair.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#148322">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="148538"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#148538">251. </a></span><span style="color:#036">Mr Rational </span> on October 19, 2006  3:03 AM writes...</p>
<p>Well it's not exactly unbiased is it?</p>

<p>Anyway, enough dissent!</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#148538">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="148674"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#148674">252. </a></span><span style="color:#036">Jim Thorpe </span> on October 19, 2006  8:25 AM writes...</p>
<p>"251. Mr Rational on October 19, 2006 03:03 AM writes...<br />
Well it's not exactly unbiased is it?</p>

<p>Anyway, enough dissent!"</p>

<p>What's not unbiased? the trustbut blog?<br />
<a href="http://trustbut.blogspot.com/" rel="nofollow">http://trustbut.blogspot.com/</a></p>

<p>One needn't be *unbiased* in order to be fair.  One need only identify and own up to ones bias. In that regard, the trustbut blog is very fair. It says upfront that it hopes Landis is innocent (as I suspect all people but Realist do) and then it does a good job of compiling both pro and anti Landis links in the news.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#148674">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="148816"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#148816">253. </a></span><span style="color:#036">Mr Rational </span> on October 19, 2006  4:18 PM writes...</p>
<p>It's a load of pro Landis bullsh*t, masquerading as scientific fact.</p>

<p>If you want to be spoon fed a load of propaganda that's up to you, but I'll make up my own mind. </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#148816">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="148867"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#148867">254. </a></span><span style="color:#036">Dr. Sigmund </span> on October 19, 2006  6:18 PM writes...</p>
<p>"It's a load of pro Landis bullsh*t, masquerading as scientific fact."</p>

<p>What is, the trusbut blog?</p>

<p>You are a very lonely man to need to argue with people so badly. You obviously didn't read through the site.</p>

<p>It simply isn't as you say. It links over to all of the anti Landis articles as well. Thing is, the science is supporting Landis at the moment so there are more pro Landis articles to link to than anti ones. If you'll remember, the tables were turned a few weeks ago.</p>

<p>You are obviously a conservative -- you respect science only when it supports what you want -- truth is of no concern to you. I'm sure you're on other boards arguing that global warming is not real. If new data proves that Landis is guilty, I will accept that. That's what it means to be a realist -- to be rational. You, my friend, are living in some sort of spite-fuelled delusion.</p>

<p>While most are relieved that Landis seems to be innocent of the allegations, you are disappointed. Mum not hug you enough? Dad hug you too much? In order to want a  top athlete to fail, you must really have inferiority issues. I hope you can learn to deal with them and stop trying to bring everyone down to your level.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#148867">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="148895"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#148895">255. </a></span><span style="color:#036">Realist </span> on October 19, 2006  9:02 PM writes...</p>
<p>Nope, just telling it like it is buddy.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#148895">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="149050"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#149050">256. </a></span><span style="color:#036">Jim Thorpe </span> on October 20, 2006  6:54 AM writes...</p>
<p>"telling it like it is" is something others are meant to say of you (e.g. what Howard Stern and Rush Limbaugh FANS say about them) -- pretty pathetic if you have to say it about yourself!</p>

<p>I'll do you the charity because I feel sorry for you [clears throat]:</p>

<p>You're just telling it like it is Realist!</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#149050">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="149128"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#149128">257. </a></span><span style="color:#036">Realist </span> on October 20, 2006  1:34 PM writes...</p>
<p>Ah, the tedious amateur psychology again!</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#149128">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="149186"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#149186">258. </a></span><span style="color:#036">Jim Thorpe </span> on October 20, 2006  5:20 PM writes...</p>
<p>Ah, the comical last word.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#149186">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="151604"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#151604">259. </a></span><span style="color:#036">Anonymous </span> on October 24, 2006  2:30 PM writes...</p>
<p>Dr Sigmund;</p>

<p>"You are obviously a conservative -- you respect science only when it supports what you want -- truth is of no concern to you"</p>

<p>Uneccasary & Counterproductive.</p>

<p>In short, beneith you.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#151604">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="152029"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#152029">260. </a></span><span style="color:#036">Realist </span> on October 25, 2006 11:47 AM writes...</p>
<p>Not really, just the usual pompous, hypocritical drivel. </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#152029">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="156802"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#156802">261. </a></span><span style="color:#036">Realist </span> on November  4, 2006 10:09 AM writes...</p>
<p>I think the lack of posts on the page speaks volumes.</p>

<p>I've trawled the internet for explanations of how the information released proves Landis's innocence, but the best I can find is one inconclusive argument on the validity of the B sample.</p>

<p>Regardless of whether this is valid or not, it's clear this isn't a gross mistake, a miscarraige of justice, the wrongful accusation of a clean athelete. We've dealing in fine details and interpretations of two failed tests. So let's stop using phrases such as travesty and see it for what it really is. This is just another case of an athelete who cheated, got caught and is desparately looking for a technicality to get himself off.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#156802">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="157389"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#157389">262. </a></span><span style="color:#036">Jim Thorpe </span> on November 11, 2006 11:48 AM writes...</p>
<p>The lack of posts is because we are now at DPF where we can ask Mr. Landis questions directly, and getting links to Landis related articles from trustbutverify. Regardless what you think of the fact that the site creator openly admits he hopes Landis is clean, it is a fantastic site because it links each day to all the new Landis-related articles: pro, con, and neutral. Until, and unless more documents are released by the lab there will be many hypothetical questions to discuss and the discussion over at DPF goes on.</p>

<p>Very interesting how lawyers and judges completely removed from this case keep coming forward with words of condemnation for the process playing out -- keeping the evidence from Floyd. In every first-world country, withholding evidence that may prove innocence is strictly illegal. Obviously they don't care about the truth, but just want a conviction. Luckily they have their own 'court' that can set its own rules.</p>

<p>Anyhow, I probably won't be checking back to this site again unless pharmacology again becomes an issue in the case so, for now Realist, you may have the last word.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#157389">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="158290"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#158290">263. </a></span><span style="color:#036">Realist </span> on November 14, 2006  4:04 AM writes...</p>
<p>That's all well and good, but no-one including Landis himself has attempted to explain the testosterone ratio of 11:1 or the presence of synthetic testosterone. For me that's the key question. The defence were originally 'going to explain to the world how this was a natural occurence', however it's now an exercise in discrediting the tests, which is a completely different thing. That's the point I'm trying to make. </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#158290">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="158475"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#158475">264. </a></span><span style="color:#036">Neon </span> on November 14, 2006  6:14 PM writes...</p>
<p>I just found this site today and scanned most of the posts and didn't see any discussion about C-13.  I don't understand the article's statement about C-13.  </p>

<p>My understanding is that 1.11% of carbon atoms are C-13 (that's talking about actual atoms and not one percent of T molecules).</p>

<p>Thus, in 100 T molecules, there should be 21 C-13 atoms, which, if evenly distributed, should be in 21% of those T molecules (each having one C-13).</p>

<p>So, in 10,000 T, there should be 2,109 C-13 atoms.  445 T molecules (21%x21%) should randomly have two C-13 and the balance of 1219 T (2109-445x2) should have one C-13.</p>

<p>And in one million T, there should be 9,381 T (21%x21%x21%) with 3 C-13 atoms, 40,610 (20.15%x20.15%) with 2 C-13 and the balance of 160,909 T having 1 C-13.</p>

<p>Am I right?  Did I royally screw up my math?</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#158475">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="158507"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#158507">265. </a></span><span style="color:#036"><a href="http://pipeline.corante.com" rel="nofollow">Derek Lowe</a> </span> on November 14, 2006  9:21 PM writes...</p>
<p>Neon, the original post that started this comment-fest (which broke all my site's records a long time ago) goes into this a bit. You're on the right track with the math, but you're a bit off in the details.</p>

<p>There are 19 carbon atoms in each molecule of testosterone (not 21). The odds of a given testosterone molecule having at least one C-13 in it is thus 1-(0.9889 to the 19th), or 19.1%. The chances of having two are 0.191 * (1-(0.9889 to the 18th)), or 3.47%. It's not a straight 19.1% squared, because you've only got 18 other carbon atoms to have another C-13 show up in.</p>

<p>Likewise, the chances of having three are 0.0347 * (0.9889 to the 17th), or 0.6%.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#158507">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="158646"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#158646">266. </a></span><span style="color:#036">neon </span> on November 15, 2006  8:48 AM writes...</p>
<p>Derek</p>

<p>The 21 came from the fact that there are 1900 atoms in 100 T molecules.  At 1.11% natural occurence rate, that's 21 atoms of C13.</p>

<p>Anyway, thanks for the clarification.</p>

<p>Cheers</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#158646">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="159429"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#159429">267. </a></span><span style="color:#036">Jim Thorpe </span> on November 17, 2006 10:14 AM writes...</p>
<p>I just read this article and wondered what the technicians here feel about whether or not the lab being rushed to meet a deadline (along with generally lax procedures) could have a detrimental effect on the quality of the test being performed. I understand that making a determination has a lot has to do with interpretation of the data (and they won't release it all to him). But speaking strictly procedurally, is this test quite straight forward or is there significant room for error?</p>

<p><a href="http://www.cyclingfans.com/" rel="nofollow"><a href="http://www.cyclingfans.com/" rel="nofollow">http://www.cyclingfans.com/</a></a> (the Thursday, November 16, 2006 article)</p>

<p>-----</p>

<p>Realist,</p>

<p>Many here have addressed that point. I believe I even gave you a link describing how the presence of certain organisms contaminating the sample can alter the result (I think your response was something like, *Pro-Landis BS*). I believe it said that the particular test that came back 11:1 was from a sample contaminated beyond the lab's maximum level. Keep in mind those standards are in place to prevent false positives -- funny they would make an exception to their own rule in this high-profile, publicity-drawing case.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#159429">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="159499"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#159499">268. </a></span><span style="color:#036">Realist </span> on November 17, 2006  2:46 PM writes...</p>
<p>I thought you were no longer looking on here?</p>

<p>You're still having your mind made up for you by the sounds of it. How do you know the lab has lax procedures? Was is based on the administrative error? How can you possibly conclude that the test itself was badly performed because of a typing error by a person who's role in the testing you haven't got the faintest idea about?? And what this 'rushed to meet a deadline' all about? Do you know how long the test takes or whether it took any more or less time in this case? No is the answer.</p>

<p>In answer to your point, we've had two samples giving the same result. No-one appears to be questioning the validity of the A test, so what relevance has your contamination argument got? Surely both would have to be contaminated?<br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#159499">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="160131"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#160131">269. </a></span><span style="color:#036">Jim Thorpe </span> on November 19, 2006  4:40 AM writes...</p>
<p>"I thought you were no longer looking on here?"</p>

<p>Found a relevant topic.</p>

<p>"How do you know the lab has lax procedures?"</p>

<p>Numerous reports of mistakes in other cases and an inability or unwillingness to meet the required measure of sample anonymity.</p>

<p>"How can you possibly conclude that the test itself was badly performed because of a typing error by a person who's role in the testing you haven't got the faintest idea about?? And what this 'rushed to meet a deadline' all about?"</p>

<p>Funny, do you have cognitive issues? Please re-read what I wrote. I asked those here who work in labs and are familiar with these sorts of tests IF it would be an issue -- or if the procedures are straight forward. Read the article to see why they were rushed (to finish before going on holiday)</p>

<p>"In answer to your point, we've had two samples giving the same result."</p>

<p>Both were contaminated to an extent but the 11:1, I believe, came from only the B sample  (please correct me if I'm wrong). I believe the A sample showed a level much closer to possible, natural deviation. AGAIN, the T level AND E level were low. The T was not high, just high by comparison.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#160131">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="160132"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#160132">270. </a></span><span style="color:#036">Realist </span> on November 19, 2006  4:49 AM writes...</p>
<p>The original sample was 11:1. They say the B samples degrade with time and if I remember, was dragged out till the last possible minute by Landis's team. Maybe this is a better explanation of the B test's variability. </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#160132">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="160276"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#160276">271. </a></span><span style="color:#036">Realist </span> on November 19, 2006  2:42 PM writes...</p>
<p>By the way, you mention natural deviation, but there's nothing remotely natural about the results. From my understanding the average person has a ratio of 2:1, the limit is double this 4:1 however Landis was measuring 11:1. That's over 5 times your average person and almost 3 times the limit. There was evidence of synthetic testosterone too. Both in the A sample which hasn't been questioned.</p>

<p>From my perspective the B sample provides the means to escape the ban only.  </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#160276">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="160536"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#160536">272. </a></span><span style="color:#036">Jim Thorpe </span> on November 20, 2006 10:35 AM writes...</p>
<p>You're right, myy mistake about the B sample yielding 11:1.</p>

<p>It was in fact the A sample. The troubling part, though, is that the lab's results were wildly inconsistent. The A sample was tested twice and yielded 11.4 on one test and 5.1 on the other. Those two radically different results both came from the A sample. Looks like an un-calibrated machine considering they refuse to release machine calibration records.</p>

<p>As for your outrage at the 11:1</p>

<p>"A T/E screening ratio over 4 should not create the presumption of doping. <br />
For most results, itâ€™s just the opposite of what is the popular impression. <br />
In 2005, 25 out of 33 WADA-accredited labs reported their T/E ratio test <br />
results. <br />
A total of 955 T/E ratio tests results were between 4 and 6. <br />
Of those, just three tests were confirmed as doping positives. <br />
A T/E screening value between 4 and 6 could be interpreted as a 99.5+% <br />
proof of innocence. <br />
It is only when T/E ratios are above 15 that more tests than notare <br />
confirmed positive. " ( <a href="http://ia331343.us.archive.org/3/items/Floyd_Landis_2006_Case_Documents_10/Floyd_Landis_SS-2.1.pdf" rel="nofollow"><a href="http://ia331343.us.archive.org/3/items/Floyd_Landis_2006_Case_Documents_10/Floyd_Landis_SS-2.1.pdf" rel="nofollow">http://ia331343.us.archive.org/3/items/Floyd_Landis_2006_Case_Documents_10/Floyd_Landis_SS-2.1.pdf</a></a> )</p>

<p>As for the C13 presence:</p>

<p>Your body will use C13 if no C12 is available at the precise moment the molecule is formed (remember T is readily formed from broken down cortisone).</p>

<p>Of the 4 metabolites, only one tested even arguably above the normal. A 'positive' result requires "all" to test above according to the rules. Even if you interpret the one metabolite as showing slightly elevated C13, that would not be unexpected and would likely be found in other, obviously negative, samples. If you prematurely 'conclude' a person is guilty, it is easy to find ambiguous facts to use as 'evidence' to support the conclusion. No sample is 100% 'normal' in all areas. 'Normal' is just averages. I'm sure they could test your pee and find one or two 'abnormalities' that I could use to support a case against you. It is actually abnormal for a person to be 100% 'normal' in every area.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#160536">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="160594"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#160594">273. </a></span><span style="color:#036">Realist </span> on November 20, 2006  3:02 PM writes...</p>
<p>Looking at your link, I see the phrases 'could be interpreted' and 'more tests than not'. This is scientific opinion, not scientific fact. The argument about 'all' metabolites is spin again, it's just a question of interpretation. Depending on which expert you quote, you can support any argument. </p>

<p>All I can say is that in the absence of dozens of atheletes failing testosterone tests and presuming WADA employ people who know what they're talking about to set the levels for the tests; I'm as convinced that this wasn't a natural occurence as I ever was. In the context of what happened on the Tour, when the violation took place, this seems even more likely. </p>

<p>As much as Landis and his followers would like to re-write the rules to suit, things don't work that way. </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#160594">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="160793"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#160793">274. </a></span><span style="color:#036">Jim Thorpe </span> on November 21, 2006  2:45 AM writes...</p>
<p>Realist,</p>

<p>99.5+% of T/E screening values are proven innocent.</p>

<p>A lot of people naturally go over 4:1 from time to time -- especially those athletes who are stressing their systems to the point of Carbon cannibalisation (something that is very hard to produce in lab tests -- remember, Landis would have been cannibalising from synthetic cortisone).</p>

<p>Moreover, EVERYONE has a level of C13 present, especially corn-syrup-consuming Americans.</p>

<p>2:1 is the average ratio for fat couch potatoes, not lean athletes amid exercise. Think of your average heart rate, ~75 bpm. Now think of your heart rate sprinting up a mountain, ~190 bpm. It is very normal for people to go way above the 'norm' for short periods during exercise. Landis passed EVERY other test w/o ambiguity. The only test that even hints at a potential of a foreign substance is just following a day of cycling at max power.</p>

<p>"It is only when T/E ratios are above 15 that more tests than not are confirmed positive. " (see above link)</p>

<p>(By the way, Landis did not prevent them from testing the B sample. I don't know where you got that from.)</p>

<p>The long and short of it, I don't care what you think on the matter and you don't care what I think. I understand you get some pathetic thrill off playing devil's advocate but that's not the point of this board, science is. Stop dragging me into slugging matches when I try to talk about the science and the validity/lack of validity of particular theories. Not all posts are aimed at you and you don't need to respond to them all.</p>

<p>Now my question (NOT TO YOU, Realist) is with regard to the actual tests performed. I keep reading statements from techs at top labs saying their labs would never permit the things that have come out about this lab.</p>

<p>Are the tests so straight forward that even a lab with a record as sloppy as this one is accused of being would have been able to carry them out with a very high probability of accuracy, or could team Landis' argument regarding sloppy lab work actually hold any substance?</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#160793">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="160816"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#160816">275. </a></span><span style="color:#036">Realist </span> on November 21, 2006  4:59 AM writes...</p>
<p>Honestly, why do you get so abusive because I don't care to agree with your point of view? I think you're trying to find some scenario, no matter how unrealistic, to prove your point, while discounting the most obvious. I'm of the second school of thought.</p>

<p>>Realist,</p>

<p>>Many here have addressed that point. I believe I >even gave you a link describing how the presence >of certain organisms contaminating the sample can >alter the result (I think your response was >something like, *Pro-Landis BS*). I believe it >said that the particular test that came back 11:1 >was from a sample contaminated beyond the lab's >maximum level. Keep in mind those standards are >in place to prevent false positives -- funny they >would make an exception to their own rule in this >high-profile, publicity-drawing case.</p>

<p>Looks like I was minding my own business.</p>

<p>P.S. Your mentioning statistics without any context as usual. </p>

<p>99.5+% of T/E screening values are proven innocent. - Why? Why not this one?</p>

<p>Moreover, EVERYONE has a level of C13 present, especially corn-syrup-consuming Americans. - How much? Enough to fail a drugs test?<br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#160816">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="160891"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#160891">276. </a></span><span style="color:#036">Jim Thorpe </span> on November 21, 2006  9:54 AM writes...</p>
<p>The point of this site is to discuss science. Nobody cares your baseless opinion as to guilt/innocence, nor mine. Moreover, why should you care if someone were trying to prove landis innocent!? I'm sure you agree that everyone has the right to have people try to exonerate them when they are being acused.</p>

<p>Beyond that, nobody has failed a drug test. There is ambiguous, suggestive evidence. Not the kind of test failure that get people banned. And it says a lot that 99.5+% of T/E screening values above 4:1 are proven innocent. It says that, if they made the data all available and allowed further investigation, Landis would have a damned good chance of being proved innocent, too.</p>

<p>You may want to come on here and cheer a lynch mob nut I want to talk about possible scenarios that could explain the results and their scientific validity.</p>

<p>Anyhow, your terrorist, troll tactics seem to work. You deadened the potential usefulness of the discussion. Pathetic, though I'm sure you feel big.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#160891">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="161232"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#161232">277. </a></span><span style="color:#036">Realist </span> on November 22, 2006  3:54 AM writes...</p>
<p>Oh shut up you sanctimonious twerp. You see fit to tell the whole world in mind numbing detail quite how you have decided Landis is not guilty, see post 244. I'm sure Landis and the rest of the world were relieved to hear it.</p>

<p>Honestly, if they were developing a test for having your head up your own arse, they'd do well to use you as the reference.<br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#161232">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="161589"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#161589">278. </a></span><span style="color:#036">Jim Thorpe </span> on November 23, 2006 12:11 AM writes...</p>
<p>Oh, sad Realist whose fragile feelings I've once again damaged.</p>

<p>By all means, if you want to actually put down facts supporting Landis' guilt, I am in favour. Post links to articles and questions all you like.</p>

<p>It's the flat cynical twaddle that is pointless and counterproductive. Post links to actual, scientific arguments claiming Landis' guilt, please. That will certainly advance the quest to make sense of what has transpired. On the flip side, it is not productive when you say *It's simple. He's guilty and immoral. All you who are sceptical are just dumb*<br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#161589">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="176321"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#176321">279. </a></span><span style="color:#036">robert/elley matthews </span> on December 31, 2006  3:57 PM writes...</p>
<p>the point made re: millar and virenque is a good one,, except that richard virenque is still credited with winning all those KOM jerseys....my question is: how many KOM jerseys did virenque win 'clean'?  given that he confessed to using enhancing substances while with festina, should any of his KOM wins be taken away? is he entitled to them any more or less than landis is entitled to the tour win?</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#176321">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="176743"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#176743">280. </a></span><span style="color:#036">Realist </span> on January  3, 2007  4:09 AM writes...</p>
<p>Millar was stripped of his title, Heras too, so if Landis was to lose his, it would be consistent I suppose. Virenque is a strange one though, perhaps King of the Mountains jerseys are seen as less prestigious?</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#176743">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="177115"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#177115">281. </a></span><span style="color:#036">David Lewis </span> on January  4, 2007  1:53 PM writes...</p>
<p>If Virenque played by the rules, and the rules did not prohibit what he did then he gets a pass and keeps his KOM jerseys. No moving the goal posts!</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#177115">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="183421"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#183421">282. </a></span><span style="color:#036">riley </span> on February  2, 2007  2:53 AM writes...</p>
<p>Virenque is French, no?</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#183421">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="215296"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#215296">283. </a></span><span style="color:#036">Realist </span> on April 24, 2007  2:39 AM writes...</p>
<p>L.A. Times - Evidence of synthetic testosterone has been found in "several" of the other urine samples Floyd Landis gave while winning the 2006 Tour de France, the French newspaper L'Equipe reported on its website today.</p>

<p>Now there's a surprise!</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#215296">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="222425"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#222425">284. </a></span><span style="color:#036"><a href="http://www.yandex.ru" rel="nofollow">LolitochkaBC</a> </span> on May 10, 2007  2:22 AM writes...</p>
<p>Ааану-ак ребятки голосуем!!!<br />
 <br />
Прмзнавайтесь проказники и власдельцы сайта pipeline.corante.com )))) <br />
 <br />
ЧТО вы будете делать этим летом?! <br />
 <br />
 <br />
 <br />
 <br />
 <br />
 <br />
 <br />
 <br />
 <br />
 <br />
 <br />
 <br />
 <br />
 <br />
 <br />
 <br />
 <br />
 <br />
</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#222425">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="229378"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#229378">285. </a></span><span style="color:#036">Suz </span> on May 19, 2007  5:42 PM writes...</p>
<p>In my humble opinion, as a physician and as a close friend of a former pro-cyclist, Landis is a cheater.  And most pro-cyclists at that level must cheat to compete.  Sad?  I don't think so.  Cheaters should be held accountable.  Don't blame the French.  Blame the cheater.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#229378">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="232772"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#232772">286. </a></span><span style="color:#036">Realist </span> on May 24, 2007  3:10 AM writes...</p>
<p>So all the evidence has been heard and nearly a year after Landis vowed to prove how his failed test was a natural occurrence, he's done nothing of the sort. <br />
We've found out too, that Mr Nice Guy is not quite as nice as he'd like us to believe.</p>

<p>Keith, Jim Thorpe etal, looks like you backed the wrong horse.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#232772">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="289219"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#289219">287. </a></span><span style="color:#036">Jim Thorpe </span> on September  8, 2007  5:41 AM writes...</p>
<p>"So all the evidence has been heard and nearly a year after Landis vowed to prove how his failed test was a natural occurrence, he's done nothing of the sort.<br />
We've found out too, that Mr Nice Guy is not quite as nice as he'd like us to believe.</p>

<p>Keith, Jim Thorpe etal, looks like you backed the wrong horse."</p>

<p>Landis has done a damned fine job considering he was not permitted to see the evidence against him and, thus could not "explain" it.</p>

<p>More over, as for the other urine samples being tested and showing synthetic testosterone. Seems fishy that the lab performed those tests -- thus destroying all remaining evidence that could have cleared Landis' name. Landis was not opposed, mind you, to having the samples sent to UCLA labs to be tested. Funny that the lab which is under so much suspicion did not want to allow another lab to test Floyd's remaining samples. Why not? Surely UCLA (the finest lab in the world) would have found the same result (that Landis is a cheater), right? Then, instantly, the French lab would have erased any doubt as to flaws in its methodology.</p>

<p>Seems to me that if I were trying to maintain the reputation of my lab I would send samples to be tested by a third party which would validate my findings -- that is, unless I had identified some flaws in my lab's methodology. In that case I'd want to destroy any remaining samples (by testing them in the same flawed method) before another lab could get its hands on them.</p>

<p>By the way, "Realist;" what is "etal" supposed to mean? I'm pretty sure you were going for "et al." But seriously, that's a pretty lame mistake to make in a scientific discussion -- and don't even pretend that it's just a typo (that you just didn't press the space key hard enough) you forgot the "." too!</p>

<p>Just own up to being wrong about it, and realise that you brought the same special intellect ("special needs," that is) to your in-depth analysis of Landis' case and drew conclusions as to his guilt fully in line with a person who would write "etal."</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#289219">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="294050"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#294050">288. </a></span><span style="color:#036">Realist </span> on September 21, 2007  5:27 AM writes...</p>
<p>So it's gone from a discussion about Landis to one of my grammar? You must be desperate.</p>

<p>Seems he lost by the way. Looks like I called it right and you called it wrong.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#294050">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="295326"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#295326">289. </a></span><span style="color:#036">Jim Thorpe </span> on September 25, 2007  2:53 AM writes...</p>
<p>"288. Realist  on September 21, 2007 5:27 AM writes...</p>

<p>So it's gone from a discussion about Landis to one of my grammar? You must be desperate.</p>

<p>Seems he lost by the way. Looks like I called it right and you called it wrong."</p>

<p>Wow, you don't even know the difference between grammar and spelling -- shocking but not surprising.</p>

<p>Yes, he lost the arbitration that everyone has said all along he would loose; the very same arbitration that no athlete has ever won. Only this time (unlike in previous cases) it was a split decision with a very strong dissenting voice. If you want to throw your weight behind an obviously rigged system -- a lynchmob -- then good on you. You sure won.</p>

<p>I on the other hand will take the word of every notable chemist who has weighed in -- this result should be thrown in the bin and Landis' name cleared.</p>

<p>Simple fact is: there are contamination guidelines because too much contamination in a sample messes with the results. A and B were beyond contamination limits and the lab didn't follow testing protocol. The results were all over the map and inconsistent with each other as one would expect given these conditions. Whether or not Landis is a doper, he certainly wasn't caught doping during the Tour -- end of story.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#295326">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="295327"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#295327">290. </a></span><span style="color:#036">Realist </span> on September 25, 2007  3:09 AM writes...</p>
<p>Yes, he lost the arbitration that everyone has said all along he would loose;</p>

<p>Loose??!? Ho ho.</p>

<p>The dissenting voice was the most predictable thing about the case. This is the man who dissented at the Tyler Hamilton arbitration for crying out loud.</p>

<p>The case has been heard, the verdict has been reached and that's good enough for me. Don Catlin, the worlds foremost authority on the subject said "No question about it, my opinion is that doping was going on.". "It's just inescapable."</p>

<p>What more is there to say?</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#295327">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="295980"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#295980">291. </a></span><span style="color:#036">Jim Thorpe </span> on September 26, 2007  6:26 PM writes...</p>
<p>"The case has been heard, the verdict has been reached and that's good enough for me."</p>

<p>Why does that not surprise me? You are a simple man needing simple answers. I know that shades of grey get you uneasy. You 'shoot from the hip' and clear a lot of brush, right?</p>

<p> "Don Catlin, the worlds foremost authority on the subject said 'No question about it, my opinion is that doping was going on.". "It's just inescapable.'"</p>

<p>Don't cherry pick. Like me, Catlin acknowledged doping is rampant in the sport and Landis could very well be a doper but as for Landis' specific case:</p>

<p>"Catlin pointed out the French lab results while positive for WADA doping criteria, would not be positive for UCLA doping criteria."</p>

<p>I am not saying that Landis is or is not a doper -- just that you shouldn't ruin a person's career until you get tight evidence -- tainted samples and lax procedures do not constitute such evidence. The authorities owe it to the few clean athletes to follow procedure and make sure they don't get false positives. Whether or not Landis doped, convicting him based on this 'evidence' has pretty much screwed the clean athletes who will eventually find themselves in similar situations where a tainted sample turns up a false positive. We don't send a man to jail when there is still reasonable doubt -- why is it any less objectionable to strip a man of his livelihood?</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#295980">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="296123"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#296123">292. </a></span><span style="color:#036">Realist </span> on September 27, 2007  3:38 AM writes...</p>
<p>Drop the simple man stuff, it's unnecessary.</p>

<p>There are two ways of looking at this whole thing. If the question is 'was there sufficient evidence to  suggest Landis doped', then the answer is yes. If the question is 'was the testing perfect' then the answer is no. Obviously the majority of the arbitrators viewed 1 as more important. </p>

<p>As for the false positives, I can't think of any examples to back up your argument? Who are these atheletes who's been wrongly accused of taking testosterone? Both Sinkevitz and Moreni were both caught during this years tour and admitted to it.<br />
It suggests that the tests are more robust than Landis's lawyers would have us believe. You're never going to get textbook results from these tests and if this is the criteria then you might as well forget drug testing in sport all together. </p>

<p>Whether you approve or not, since the utterly predictable positive test after stage 17, there has been nothing to change my view that Landis cheated during the tour. If this decision prevents Vinokourov mounting another 18 month campaign to prove how lab incompetence has resulted in having someone else's blood in his system, after his equally miraculous recovery in this years tour, then all the better.</p>

<p>Isn't it funny how there's less uproar when a non US athelete is involved?  <br />
 </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#296123">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="340729"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#340729">293. </a></span><span style="color:#036">JB </span> on January  5, 2008 11:47 AM writes...</p>
<p>Update:  Here's a link to an Anal. Chem. piece found on acs.org</p>

<p><br />
<a href="http://pubs.acs.org/subscribe/journals/ancham/79/i23/pdf/1207gov.pdf" rel="nofollow">http://pubs.acs.org/subscribe/journals/ancham/79/i23/pdf/1207gov.pdf</a></p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#340729">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="354740"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#354740">294. </a></span><span style="color:#036">paul </span> on July  1, 2008  7:28 AM writes...</p>
<p>End of the day , Landis is a convicted Drug Cheat. He has had more opportunity to prove himself innocent and at every opportunity he has failed. I would hazard a guess that it is because he is guilty. All you people rambling on with content from the insert of you home chemistry set please give it a rest.<br />
I really do hope he takes this to some other court where ALL of the bodies he has insulted and lied about can extract their pound of flesh from this convicted drug cheat.</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#354740">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="354858"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#354858">295. </a></span><span style="color:#036">Realist </span> on July  1, 2008  3:03 PM writes...</p>
<p>Here's hoping Floyd will take it on the chin and fess up. Somehow I doubt it...</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#354858">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="428118"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#428118">296. </a></span><span style="color:#036"><a href="http://www.elitetikibars.com" rel="nofollow">Joe Tiki</a> </span> on March  7, 2010  8:25 PM writes...</p>
<p>I definitely agree with the realist!</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#428118">Permalink to Comment</a> 
</p>
</div>
<div id="commentflip">
<p class="commentsbody"><a name="437346"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#437346">297. </a></span><span style="color:#036">fungus </span> on May 24, 2010  3:11 AM writes...</p>
<p>Realist, in the end, you won the day. </p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#437346">Permalink to Comment</a> 
</p>
</div>
<div id="commentflop">
<p class="commentsbody"><a name="437610"></a><span class="commentnumber"><a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#437610">298. </a></span><span style="color:#036">Realist </span> on May 26, 2010  5:17 AM writes...</p>
<p>Who saw that coming?</p>
<a href="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php#437610">Permalink to Comment</a> 
</p>
</div>

</div>



<!-- TRACKBACKS DISPLAY -->





<!-- POST A COMMENT -->


<b>POST A COMMENT</b>

 



<form method="post" action="http://www.corante.com/cgi-bin/mt/terioria.fcgi" name="comments_form" onsubmit="if (this.bakecookie[0].checked) rememberMe(this)">
<input type="hidden" name="static" value="1" />
<input type="hidden" name="entry_id" value="62964" />

<div id="name_email">
<p><label for="author">Name:</label><br />
<input tabindex="1" id="author" name="author" /></p>

<p><label for="email">Email Address:</label><br />
<input tabindex="2" id="email" name="email" /></p>
</div>



<p><label for="url">URL:</label><br />
<input tabindex="3" type="text" name="url" id="url" />
Remember Me?
<input type="radio" id="remember" onclick="rememberMe(this.form)" name="bakecookie" /><label for="remember">Yes</label><input type="radio" id="forget" name="bakecookie" onclick="forgetMe(this.form)" value="Forget Info" style="margin-left: 15px;" /><label for="forget">No</label><br style="clear: both;" />
</p>

<div class="quicktags"><p><label for="text">Comments:</label> </p>

<script src="http://www.movalog.com/mt/quicktags.js" type="text/javascript"></script><script type="text/javascript">edToolbar();</script>

<p><br style="clear: both;" />
<textarea tabindex="4" id="text" name="text" rows="10" cols="50"></textarea><script type="text/javascript">var edCanvas = document.getElementById('text');</script></p></div>


<div align="center">
<input type="submit" name="preview" tabindex="5" 
    value=" Preview " />
<input style="font-weight: bold;" type="submit" name="post" 
    tabindex="6" value=" Post " />
</div>
</form>




<script language="javascript" type="text/javascript" src="http://www.corante.com/js/comment_form.js"></script>






<!-- EMAIL THIS ENTRY -->

<a name="send"></a>
<form method="post" action="http://www.corante.com/cgi-bin/mt/mt-send-entry.cgi">
<input type="hidden" name="entry_id" value="62964" />
<input type="hidden" name="_redirect" value="http://pipeline.corante.com/archives/2006/08/01/testosterone_carbon_isotopes_and_floyd_landis.php" />
<br />

<p><b>EMAIL THIS ENTRY TO A FRIEND</b></p>
<a name="zemail"></a>
Email this entry to:<br />
<input name="to" size="25" /><br />
Your email address:<br />
<input name="from" size="25" /><br />
Message (optional):<br />
<textarea name="message" rows="5" cols="30" wrap="virtual"></textarea>
<br />
<input type="submit" value="Send" />
</form>
<br />
<br />
<br />


<!-- RELATED ENTRIES -->

<dl>
<dt><b>RELATED ENTRIES</b></dt>

 
<dd>&#155; <a href="http://pipeline.corante.com/archives/2010/07/08/why_close_one_research_site_over_another.php">Why Close One Research Site Over Another?</a></dd>
 
<dd>&#155; <a href="http://pipeline.corante.com/archives/2010/07/07/merck_site_announcements_closures_and_otherwise.php">Merck Site Announcements - Closures and Otherwise</a></dd>
 
<dd>&#155; <a href="http://pipeline.corante.com/archives/2010/07/07/xmrv_and_chronic_fatigue_you_thought_you_were_confused_before.php">XMRV and Chronic Fatigue: You Thought You Were Confused Before</a></dd>
 
<dd>&#155; <a href="http://pipeline.corante.com/archives/2010/07/07/drug_prices_in_the_us_not_so_high_after_all.php">Drug Prices in the US: Not So High After All?</a></dd>
 
<dd>&#155; <a href="http://pipeline.corante.com/archives/2010/07/06/commenting_on_scientific_papers_how_come_no_one_does_it.php">Commenting On Scientific Papers: How Come No One Does It?</a></dd>
 
<dd>&#155; <a href="http://pipeline.corante.com/archives/2010/07/05/more_from_the_fourth.php">More From the Fourth</a></dd>
 
<dd>&#155; <a href="http://pipeline.corante.com/archives/2010/07/05/holiday.php">Holiday</a></dd>
 
<dd>&#155; <a href="http://pipeline.corante.com/archives/2010/07/02/sanofiaventis_acquires_somebody.php">Sanofi-Aventis Acquires. . .Somebody?</a></dd>
 
</MTRelatedEntries>
</dl>


</div>
</div>
</td>


<td id="rlinks" valign="top">
<table cellspacing="0" cellpadding="0" border="0" width="190">
<tr>
<td>

<div class="tablead" style="background:#fff;font-size:100%;text-align:left">

<br /><br />
<div id="recent_entries">
<div class="sidetitle">RECENT ENTRIES</div>
<div class="rside">
<b>&#8250;</b> <a href="http://pipeline.corante.com/archives/2010/07/13/midsummer.php">Midsummer</a><br /><br />
<b>&#8250;</b> <a href="http://pipeline.corante.com/archives/2010/07/13/avandia_was_the_evidence_buried.php">Avandia: Was the Evidence Buried?</a><br /><br />
<b>&#8250;</b> <a href="http://pipeline.corante.com/archives/2010/07/13/hmmm_the_gates_foundation_bails.php">Hmmm: The Gates Foundation Bails</a><br /><br />
<b>&#8250;</b> <a href="http://pipeline.corante.com/archives/2010/07/12/natural_products_not_the_best_fit_for_drugs.php">Natural Products: Not the Best Fit for Drugs?</a><br /><br />
<b>&#8250;</b> <a href="http://pipeline.corante.com/archives/2010/07/09/lechleiters_prescription_for_science.php">Lechleiter's Prescription for Science</a><br /><br />
<b>&#8250;</b> <a href="http://pipeline.corante.com/archives/2010/07/09/the_horror_of_asking_for_data.php">The Horror Of Asking For Data</a><br /><br />
<b>&#8250;</b> <a href="http://pipeline.corante.com/archives/2010/07/08/why_close_one_research_site_over_another.php">Why Close One Research Site Over Another?</a><br /><br />
<b>&#8250;</b> <a href="http://pipeline.corante.com/archives/2010/07/07/merck_site_announcements_closures_and_otherwise.php">Merck Site Announcements - Closures and Otherwise</a><br /><br />
<b>&#8250;</b> <a href="http://pipeline.corante.com/archives/2010/07/07/xmrv_and_chronic_fatigue_you_thought_you_were_confused_before.php">XMRV and Chronic Fatigue: You Thought You Were Confused Before</a><br /><br />
<b>&#8250;</b> <a href="http://pipeline.corante.com/archives/2010/07/07/drug_prices_in_the_us_not_so_high_after_all.php">Drug Prices in the US: Not So High After All?</a><br /><br />

</div> 
</div>

<div class="sidetitle">RECENT COMMENTS <a href="http://pipeline.corante.com/25comments.xml"><span class="catxml">[xml]</span></a></div>
<div class="rside">
&#8250; srp on <br /><a href="http://pipeline.corante.com/archives/2010/07/09/the_horror_of_asking_for_data.php#443992">The Horror Of Asking For Data</a><br /><br />
&#8250; oldeurope on <br /><a href="http://pipeline.corante.com/archives/2010/07/13/avandia_was_the_evidence_buried.php#443976">Avandia: Was the Evidence Buried?</a><br /><br />
&#8250; Mary on <br /><a href="http://pipeline.corante.com/archives/2010/07/08/why_close_one_research_site_over_another.php#443975">Why Close One Research Site Over Another?</a><br /><br />
&#8250;  on <br /><a href="http://pipeline.corante.com/archives/2010/07/08/why_close_one_research_site_over_another.php#443971">Why Close One Research Site Over Another?</a><br /><br />
&#8250; Dr Van Nostrand on <br /><a href="http://pipeline.corante.com/archives/2010/07/13/midsummer.php#443970">Midsummer</a><br /><br />
&#8250; Hap on <br /><a href="http://pipeline.corante.com/archives/2010/07/13/avandia_was_the_evidence_buried.php#443967">Avandia: Was the Evidence Buried?</a><br /><br />

</div>

<div id="archives">
<div class="sidetitle">&#8250; <a href="http://pipeline.corante.com/archives/cat_index.php">CATEGORIES</a></div>
<div id="category">
<div class="rside">
&#8250; <a href="http://pipeline.corante.com/archives/me_too_drugs/">"Me Too" Drugs (22)</a> <a href="http://pipeline.corante.com/archives/me_too_drugs.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/academia_vs_industry/">Academia (vs. Industry) (52)</a> <a href="http://pipeline.corante.com/archives/academia_vs_industry.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/aging_and_lifespan/">Aging and Lifespan (29)</a> <a href="http://pipeline.corante.com/archives/aging_and_lifespan.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/alzheimers_disease/">Alzheimer's Disease (39)</a> <a href="http://pipeline.corante.com/archives/alzheimers_disease.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/analytical_chemistry/">Analytical Chemistry (24)</a> <a href="http://pipeline.corante.com/archives/analytical_chemistry.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/animal_testing/">Animal Testing (20)</a> <a href="http://pipeline.corante.com/archives/animal_testing.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/autism/">Autism (20)</a> <a href="http://pipeline.corante.com/archives/autism.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/biological_news/">Biological News (90)</a> <a href="http://pipeline.corante.com/archives/biological_news.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/birth_of_an_idea/">Birth of an Idea (43)</a> <a href="http://pipeline.corante.com/archives/birth_of_an_idea.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/blink_8250/">Blink &#8250 (5)</a> <a href="http://pipeline.corante.com/archives/blink_8250.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/blog_housekeeping/">Blog Housekeeping (129)</a> <a href="http://pipeline.corante.com/archives/blog_housekeeping.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/book_recommenda/">Book Recommendations (8)</a> <a href="http://pipeline.corante.com/archives/book_recommendations.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/business_and_markets/">Business and Markets (345)</a> <a href="http://pipeline.corante.com/archives/business_and_markets.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/cancer/">Cancer (125)</a> <a href="http://pipeline.corante.com/archives/cancer.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/cardiovascular_disease/">Cardiovascular Disease (97)</a> <a href="http://pipeline.corante.com/archives/cardiovascular_disease.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/chembio_warfare/">Chem/Bio Warfare (14)</a> <a href="http://pipeline.corante.com/archives/chembio_warfare.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/chemical_news/">Chemical News (63)</a> <a href="http://pipeline.corante.com/archives/chemical_news.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/clinical_trials/">Clinical Trials (138)</a> <a href="http://pipeline.corante.com/archives/clinical_trials.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/closing_time/">Closing Time (17)</a> <a href="http://pipeline.corante.com/archives/closing_time.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/current_events/">Current Events (105)</a> <a href="http://pipeline.corante.com/archives/current_events.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/diabetes_and_obesity/">Diabetes and Obesity (83)</a> <a href="http://pipeline.corante.com/archives/diabetes_and_obesity.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/drug_assays/">Drug Assays (83)</a> <a href="http://pipeline.corante.com/archives/drug_assays.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/drug_development/">Drug Development (214)</a> <a href="http://pipeline.corante.com/archives/drug_development.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/drug_industry_history/">Drug Industry History (158)</a> <a href="http://pipeline.corante.com/archives/drug_industry_history.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/drug_prices/">Drug Prices (61)</a> <a href="http://pipeline.corante.com/archives/drug_prices.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/general_scientific_news/">General Scientific News (88)</a> <a href="http://pipeline.corante.com/archives/general_scientific_news.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/graduate_school/">Graduate School (34)</a> <a href="http://pipeline.corante.com/archives/graduate_school.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/how_not_to_do_it/">How Not to Do It (30)</a> <a href="http://pipeline.corante.com/archives/how_not_to_do_it.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/how_to_get_a_pharma_job/">How To Get a Pharma Job (23)</a> <a href="http://pipeline.corante.com/archives/how_to_get_a_pharma_job.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/in_silico/">In Silico (42)</a> <a href="http://pipeline.corante.com/archives/in_silico.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/infectious_diseases/">Infectious Diseases (72)</a> <a href="http://pipeline.corante.com/archives/infectious_diseases.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/inorganic_chemi/">Inorganic Chemistry (4)</a> <a href="http://pipeline.corante.com/archives/inorganic_chemistry.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/intelligent_design/">Intelligent Design (9)</a> <a href="http://pipeline.corante.com/archives/intelligent_design.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/life_as_we_dont_know_it/">Life As We (Don't) Know It (8)</a> <a href="http://pipeline.corante.com/archives/life_as_we_dont_know_it.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/life_in_the_drug_labs/">Life in the Drug Labs (211)</a> <a href="http://pipeline.corante.com/archives/life_in_the_drug_labs.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/lowes_laws_of_the_lab/">Lowe's Laws of the Lab (7)</a> <a href="http://pipeline.corante.com/archives/lowes_laws_of_the_lab.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/metaphors_good/">Metaphors, Good and Bad (1)</a> <a href="http://pipeline.corante.com/archives/metaphors_good_and_bad.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/odd_elements_in_drugs/">Odd Elements in Drugs (7)</a> <a href="http://pipeline.corante.com/archives/odd_elements_in_drugs.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/patents_and_ip/">Patents and IP (99)</a> <a href="http://pipeline.corante.com/archives/patents_and_ip.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/pharma_101/">Pharma 101 (8)</a> <a href="http://pipeline.corante.com/archives/pharma_101.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/pharmacokinetics/">Pharmacokinetics (25)</a> <a href="http://pipeline.corante.com/archives/pharmacokinetics.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/press_coverage/">Press Coverage (54)</a> <a href="http://pipeline.corante.com/archives/press_coverage.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/regulatory_affa/">Regulatory Affairs (46)</a> <a href="http://pipeline.corante.com/archives/regulatory_affairs.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/safety_warnings/">Safety Warnings (6)</a> <a href="http://pipeline.corante.com/archives/safety_warnings.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/snake_oil/">Snake Oil (32)</a> <a href="http://pipeline.corante.com/archives/snake_oil.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/the_central_nervous_system/">The Central Nervous System (60)</a> <a href="http://pipeline.corante.com/archives/the_central_nervous_system.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/the_dark_side/">The Dark Side (57)</a> <a href="http://pipeline.corante.com/archives/the_dark_side.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/the_scientific_literature/">The Scientific Literature (126)</a> <a href="http://pipeline.corante.com/archives/the_scientific_literature.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/things_i_wont_work_with/">Things I Won't Work With (18)</a> <a href="http://pipeline.corante.com/archives/things_i_wont_work_with.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/things_im_glad_i_dont_do/">Things I'm Glad I Don't Do (3)</a> <a href="http://pipeline.corante.com/archives/things_im_glad_i_dont_do.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/toxicology/">Toxicology (96)</a> <a href="http://pipeline.corante.com/archives/toxicology.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/who_discovers_and_why/">Who Discovers and Why (83)</a> <a href="http://pipeline.corante.com/archives/who_discovers_and_why.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>
&#8250; <a href="http://pipeline.corante.com/archives/why_everyone_loves_us/">Why  Everyone Loves Us (46)</a> <a href="http://pipeline.corante.com/archives/why_everyone_loves_us.xml"><span class="catxml">[xml]</span></a><br />
</MTCategories>

</div>
</div>

<div class="sidetitle">
&#8250; <a href="http://pipeline.corante.com/archives/date_index.php">ARCHIVES</a></div>
<div id="monthly">
<div class="rside">
&#8250; <a href="http://pipeline.corante.com/archives/2010/07/">July 2010 (16)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2010/06/">June 2010 (42)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2010/05/">May 2010 (44)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2010/04/">April 2010 (48)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2010/03/">March 2010 (63)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2010/02/">February 2010 (36)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2010/01/">January 2010 (38)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2009/12/">December 2009 (25)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2009/11/">November 2009 (35)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2009/10/">October 2009 (30)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2009/09/">September 2009 (32)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2009/08/">August 2009 (27)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2009/07/">July 2009 (24)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2009/06/">June 2009 (40)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2009/05/">May 2009 (36)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2009/04/">April 2009 (24)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2009/03/">March 2009 (35)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2009/02/">February 2009 (33)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2009/01/">January 2009 (32)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2008/12/">December 2008 (17)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2008/11/">November 2008 (18)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2008/10/">October 2008 (24)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2008/09/">September 2008 (22)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2008/08/">August 2008 (15)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2008/07/">July 2008 (23)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2008/06/">June 2008 (20)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2008/05/">May 2008 (20)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2008/04/">April 2008 (22)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2008/03/">March 2008 (21)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2008/02/">February 2008 (20)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2008/01/">January 2008 (21)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2007/12/">December 2007 (15)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2007/11/">November 2007 (23)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2007/10/">October 2007 (23)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2007/09/">September 2007 (19)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2007/08/">August 2007 (21)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2007/07/">July 2007 (17)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2007/06/">June 2007 (12)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2007/05/">May 2007 (19)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2007/04/">April 2007 (23)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2007/03/">March 2007 (19)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2007/02/">February 2007 (27)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2007/01/">January 2007 (23)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2006/12/">December 2006 (16)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2006/11/">November 2006 (20)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2006/10/">October 2006 (24)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2006/09/">September 2006 (21)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2006/08/">August 2006 (19)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2006/07/">July 2006 (21)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2006/06/">June 2006 (24)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2006/05/">May 2006 (27)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2006/04/">April 2006 (20)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2006/03/">March 2006 (27)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2006/02/">February 2006 (21)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2006/01/">January 2006 (24)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2005/12/">December 2005 (21)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2005/11/">November 2005 (25)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2005/10/">October 2005 (26)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2005/09/">September 2005 (21)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2005/08/">August 2005 (29)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2005/07/">July 2005 (18)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2005/06/">June 2005 (24)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2005/05/">May 2005 (22)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2005/04/">April 2005 (18)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2005/03/">March 2005 (21)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2005/02/">February 2005 (21)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2005/01/">January 2005 (24)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2004/12/">December 2004 (24)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2004/11/">November 2004 (20)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2004/10/">October 2004 (23)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2004/09/">September 2004 (18)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2004/08/">August 2004 (21)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2004/07/">July 2004 (15)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2004/06/">June 2004 (19)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2004/05/">May 2004 (20)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2004/04/">April 2004 (20)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2004/03/">March 2004 (20)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2004/02/">February 2004 (23)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2004/01/">January 2004 (18)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2003/12/">December 2003 (1)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2003/11/">November 2003 (1)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2003/08/">August 2003 (1)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2003/01/">January 2003 (9)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2002/12/">December 2002 (24)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2002/11/">November 2002 (19)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2002/10/">October 2002 (26)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2002/09/">September 2002 (18)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2002/08/">August 2002 (18)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2002/07/">July 2002 (21)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2002/06/">June 2002 (12)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2002/05/">May 2002 (18)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2002/04/">April 2002 (9)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2002/03/">March 2002 (7)</a><br />
&#8250; <a href="http://pipeline.corante.com/archives/2002/02/">February 2002 (14)</a><br />

</div>
</div>
</div>


<div style="visibility: hidden">
<!--WEBBOT bot="HTMLMarkup" startspan ALT="Site Meter" -->
<script type="text/javascript" language="JavaScript">var site="s11corante"</script>
<script type="text/javascript" language="JavaScript1.2" src="http://s11.sitemeter.com/js/counter.js?site=s11corante">
</script>
<noscript>
<a href="http://s11.sitemeter.com/stats.asp?site=s11corante" target="_top">
<img src="http://s11.sitemeter.com/meter.asp?site=s11corante" alt="Site Meter" border="0" /></a>
</noscript>
<!-- Copyright (c)2002 Site Meter -->

<!--WEBBOT bot="HTMLMarkup" startspan ALT="Site Meter" -->
<script type="text/javascript" language="JavaScript">var site="sm8pipeline"</script>
<script type="text/javascript" language="JavaScript1.2" src="http://sm8.sitemeter.com/js/counter.js?site=sm8pipeline">
</script>
<noscript>
<a href="http://sm8.sitemeter.com/stats.asp?site=sm8pipeline" target="_top">
<img src="http://sm8.sitemeter.com/meter.asp?site=sm8pipeline" alt="Site Meter" border=0></a>
</noscript>
<!-- Copyright (c)2002 Site Meter -->
<!--WEBBOT bot="HTMLMarkup" Endspan -->

</div>
<br />
<br />
<a href="http://feeds.feedburner.com/InThePipeline"><img src="http://www.corante.com/frontpage/xml2.gif" border=0 /></a> 
<br />
<a href="http://feeds.feedburner.com/InThePipeline">
<img src="http://www.bloglines.com/images/sub_modern5.gif" border="0" alt="Subscribe with Bloglines" />
</a>
</div>
</div></td>
</tr>
</table>
</td>
</tr>
<tr>
<td colspan="3">
<table width="100%" cellpadding="0" cellspacing="0" border="0" id="footerbend">
<tr>
<td height="9"><img style="float:right;margin-right:-3px" src="http://www.corante.com/img/structural/footer_bottom_blue_t.gif" border="0" alt="" /></td>
</tr>
<tr>
<td height="140" id="footer" colspan="2">
<p>
<a href="http://www.corante.com/about.php">About Us</a> | 
<a href="http://www.corante.com/adinfo.php">Advertise</a> | 
<a href="http://www.corante.com/contact.php">Contact Us</a> | 
</p>
<p>
<a href="http://www.corante.com/privacy.php">Privacy Policy</a> | 
<a href="http://www.corante.com/terms.php">Terms of Use</a>
</p>
<p>&#169; Copyright 2006 Corante. All rights reserved.</p>
</td>
</tr>
</table>
</td>
</tr>
</table>
<!-- Resonance code resxclsa.js v2.x Copyright 2004-2006 Certona Corporation www.certona.com -->
<script language="JavaScript">
<!--
var resx = new Object();
resx.appid="corante01";
resx.top1=100000;
resx.top2=100000;
resx.lkmatch=/\/archives\/\d+\/\S+/i;
resx.rrec=false;
//-->
</script>
<script language="JavaScript" src="/YOURFOLDER/resxclsa.js"></script>
<!-- Resonance -->
</body>
</html>

