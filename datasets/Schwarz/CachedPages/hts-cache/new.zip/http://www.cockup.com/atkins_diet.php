<html><!-- #BeginTemplate "/Templates/cockup.dwt" -->
<head>
<script src="AREP.js"></script>
<!-- #BeginEditable "doctitle" --> 
<title>Atkins Diet</title>
<meta name="Description" content="cockup">
<meta name="Keywords" content="cockup">
<!-- #EndEditable --> 
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0" bottommargin="0">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="13%" height="54" valign="top" align="left"><a href="index.php"><img src="images/index_sub_r1_c1.jpg" width="210" height="80" align="top" alt="medical information,mens health,loss of sex drive,viagra,viagara,infertility,male infertility,impotence,diseases,sexually transmitted diseases,blood pressure,aids,prostate cancer,hair loss" border="0"></a> 
    </td>
    <td height="54" valign="top" align="left" width="25%"> 
      <div align="left"><img src="images/index_sub_r1_c5.jpg" width="440" height="80" align="top" alt="mens health,viagra,penis,impotence,infertility"></div>
    </td>
    <td height="54" valign="top" align="left" width="62%" background="images/BACK2.JPG">&nbsp;</td>
  </tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="179" height="40"><img src="images/index_sub_r2_c1.jpg" width="210" height="64" align="top"> 
    </td>
    <td height="40" width="1406"><!-- #BeginEditable "Header" --><img src="images/atkins_diet.gif" width="400" height="45"><!-- #EndEditable --> 
      <div align="right"> </div>
    </td>
  </tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="127" height="265" valign="top" background="images/Back.jpg" align="left"> 
      <p><img src="images/menu.jpg" usemap="#Map" border="0"> 
        <!-- fwtable fwsrc="index_sub_r3_c1.png" fwbase="index_sub_r3_c1.jpg" fwstyle="Dreamweaver" fwdocid = "742308039" fwnested="0" -->
        <!-- fwtable fwsrc="index_sub_r3_c1.png" fwbase="index_sub_r3_c1.jpg" fwstyle="Dreamweaver" fwdocid = "742308039" fwnested="0" -->
      </p>
      <p align="center">&nbsp;</p>
    </td>
    <td width="1452" height="265" valign="top"><script language="javascript">
<!--
document.write("<img width=1 height=1 border=0 src=/home2/cockup/www/statit/normal/statitjs.php?1,"+screen.width+","+screen.colorDepth+">");
//-->
</script> <!-- #BeginEditable "content" --> 
      <p>&quot;<b><i> I recently lost 30lbs eating the most scrumptious food that 
        I have EVER eaten!</i></b>&quot;</p>
      <p>That is a typical testimonial from someone who has tried the Atkins 
        diet.</p>
      <table width="100%" border="0" cellspacing="0" cellpadding="5">
        <tr> 
          <td><img src="images/atkins.jpg" width="86" height="140" alt="The Atkins Diet"></td>
          <td>The Atkins diet is one of the most incredible weight loss diets 
            that we have ever encountered. Allowing you to eat as much as you 
            want, whenever you want, this unabashed feel-good diet will propel 
            your body into a state of fat melt down - pumping you full of energy 
            and greatly improving your overall health.</td>
        </tr>
      </table>
      <p><font color="#CC3333"><b>EAT AS MUCH AS YOU LIKE</b></font></p>
      <p>Just imagine a diet that:-<br>
        &middot; Sets no limits on the amount of food you can eat <br>
        &middot; Bans hunger from the dieting experience <br>
        &middot; Includes rich and tempting foods you've never seen in any other 
        diet before <br>
        &middot; Reduces your appetite using a perfectly natural function of the 
        body <br>
        &middot; Adjusts your body automatically to a NEW way of burning fat <br>
        &middot; Produces steady weight loss, even if you have experienced dramatic 
        failures or weight regain on previous inadequate diets <br>
        &middot; Is so perfectly adapted to use as a lifetime diet that, unlike 
        most diets, the lost weight will never come back <br>
        &middot; Consistently produces improvements in many of the health problems 
        that accompany overweight</p>
      <p>Too good to be true? Not at all. These are the results for the many, 
        many millions of people around the globe who have subscribed to the Dr. 
        Atkins Diet Revolution.</p>
      <p>So what sets this diet apart from the hundreds of other health plans 
        you've heard about in the past? </p>
      <p><b>You do not have to suffer to be slim and healthy!</b></p>
      <p><b><font color="#CC3333">THE TRADITIONAL APPROACH</font></b></p>
      <p> For several decades now, health authorities in the western world have been 
        promoting the idea that the best diet for good health and weight loss 
        is one that is low in fat and high in carbohydrates. But this type of 
        one-size-fits-all nutritional regime has caused concern amongst many leading 
        health practitioners and problems for a large number of dieters.</p>
      <p>A diet that is high in carbohydrates can increase the body's production 
        of insulin. And when insulin is at high levels in the body, the food you 
        eat can get readily converted into body fat, in the form of triglycerides, 
        and stored. That's why so many dieters discover their bodies pile back 
        on the pounds the second they stop dieting.</p>
      <p>But what choice have you got? At every turn it's low fat this or low 
        fat that. Supermarket shelves are stacked high with fat free biscuits 
        and slim line margarine. Whole aisles are stuffed full of synthetic, processed, 
        sugar laden foods. And has this blinkered pursuit of low fat living made 
        you healthier? Of course not.</p>
      <p>We're fatter now than we used to be. Diabetes has increased dramatically, 
        tripling in the last 30 years. Heart disease is still the number one killer 
        in the western world and new health problems have appeared out of nowhere.</p>
      <p><b><font color="#CC3333">HIGH PROTEIN AND LOW CARBOHYDRATES</font></b></p>
      <p>Incredibly all these health problems can be prevented - or successfully 
        cured. You don't have to board the insulin generating roller coaster ride 
        of the low fat diet in order to lose weight and you don't need to suffer 
        to be slim and healthy. </p>
      <p>We've tried the Atkins diet and it really does work. But does it work 
        for everyone? Well the jury is probably still out on that. Latest research 
        indicates that perhaps your blood type determines which sorts of food 
        are best for you and for the oldest blood type a high protein diet (stone 
        age diet) is said to be the best. </p>
      <p>On the negative side, we felt initially that a lot of will power is required 
        because there is such a shortage of low carbohydrate foods on the supermarket 
        shelves and you start to crave variety as there is only so much meat, 
        eggs and fish that you can take!</p>
      <p>Some people have also expressed a concern on the strain the kidneys are 
        put under due to the large amount of protein ingested but the Atkins clinic 
        claims to have treated over 50,000 without any problems!</p>
      <p>Dr. Atkins rejects the endorsement of low fat, sugar-laden foods, recommending 
        instead a diet high in protein and low in carbohydrates. He claims his 
        diet is a dream diet, which is delicious, simple, healthy and varied.</p>
      <p>The diet makes you feel good and is a quick and lasting solution to annoyances 
        such as fatigue, depression, poor concentration, headaches, insomnia, 
        heartburn, dizziness, colitis, water retention, many forms of joint and 
        muscle aches and even tobacco addiction!</p>
      <p>Why not try it for yourself? </p>
      
      </table>
      
      <!-- #EndEditable --></td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td background="images/index_sub_r6_c3.jpg" width="11%" height="87" valign="top"><img src="images/index_sub_r6_c1.jpg" width="163" height="103"></td>
    <td background="images/index_sub_r6_c3.jpg" width="89%" valign="bottom" height="87"> 
      <div align="center">
        <p>&nbsp;</p>
        <p><font size="1" color="#666666" face="Arial, Helvetica, sans-serif">Viagra 
          is a trademark of Pfizer.<br>
          Cockup.com does not make any claims as to the effectiveness of any<br>
          products or treatments discussed on this web site.<br>
          </font></p>
      </div>
    </td>
  </tr>
  <tr> 
    <td width="11%" height="104" valign="top">&nbsp;</td>
    <td width="89%" valign="top" height="104"> 
      <div align="center"><font size="1" color="#666666" face="Arial, Helvetica, sans-serif">&copy; 
        2001 CockUp.com <a href="mailto:info@cockup.com"><br>
        info@cockup.com</a></font></div>
    </td>
  </tr>
</table>
<p>&nbsp;</p>
<map name="Map"> 
  <area shape="rect" coords="79,37,136,58" href="viagra.php">
  <area shape="rect" coords="48,67,137,86" href="impotence.php">
  <area shape="rect" coords="4,93,137,115" href="sexual_problems.php">
  <area shape="rect" coords="11,118,135,138" href="sexual_diseases.php">
  <area shape="rect" coords="54,143,136,163" href="infertility.php">
  <area shape="rect" coords="64,170,137,188" href="prostate.php">
  <area shape="rect" coords="70,194,135,215" href="hair_loss.php">
  <area shape="rect" coords="5,224,140,241" href="weight_problems.php">
  <area shape="rect" coords="69,249,136,267" href="cancer.php">
  <area shape="rect" coords="13,277,137,294" href="heart_disease.php">
  <area shape="rect" coords="27,300,136,319" href="osteoporosis.php">
  <area shape="rect" coords="34,329,133,344" href="antioxidants.php">
  <area shape="rect" coords="64,351,136,371" href="arthritis.php">
  <area shape="rect" coords="34,379,136,398" href="aphrodisiacs.php">
  <area shape="rect" coords="76,405,136,422" href="ageing.php">
  <area shape="rect" coords="65,431,135,450" href="diabetes.php">
  <area shape="rect" coords="7,457,138,476" href="stress_anxiety.php">
  <area shape="rect" coords="4,484,135,501" href="human_growth_hormone.php">
  <area shape="rect" coords="4,509,138,529" href="herbal.php">
  <area shape="rect" coords="85,588,136,605" href="index.php">
  <area shape="rect" coords="31,534,136,553" href="herbal_highs.php">
  <area shape="rect" coords="89,559,137,582" href="links.php">
</map>
</body>
<!-- #EndTemplate --></html>
